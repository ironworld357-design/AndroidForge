package com.example

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import com.example.audio.AudioEffectsEngine
import com.example.audio.VybeDspAudioProcessor
import com.example.guitar.ChordLibraryData
import com.example.model.AccentPreset
import com.example.model.ArtworkStyle
import com.example.model.CrossfadeCurve
import com.example.model.CrossfadeMath
import com.example.model.NavDockStyle
import com.example.model.PlayerBackgroundStyle
import com.example.model.PlayerLayoutStyle
import com.example.model.VybeThemeMode
import com.example.util.AudioTagLyricsExtractor
import com.example.util.LyricsParser
import com.example.util.TimeFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

class VybeCoreUnitTests {

    @Test
    fun `lyrics parser distinguishes synchronized lrc from plain static lyrics`() {
        val lrcRaw = """
            [ti:Test]
            [00:02.00]Line one
            [00:05.50]Line two
        """.trimIndent()
        val synced = LyricsParser.parse(1L, lrcRaw, "Local")
        assertTrue(synced.isSynchronized)
        assertEquals(2, synced.lines.size)
        assertEquals(0, LyricsParser.activeLineIndex(synced.lines, 2500L, true))
        assertEquals(1, LyricsParser.activeLineIndex(synced.lines, 6000L, true))

        val plainRaw = "Plain line one\nPlain line two"
        val plain = LyricsParser.parse(2L, plainRaw, "Manual")
        assertFalse(plain.isSynchronized)
        assertEquals(-1, LyricsParser.activeLineIndex(plain.lines, 3000L, plain.isSynchronized))
    }

    @Test
    fun `guitar pitch math maps 440hz to A4 and 82_41hz to E2`() {
        val a4 = ChordLibraryData.frequencyToNoteInfo(440.0, 0.99f)
        assertNotNull(a4)
        assertEquals("A", a4!!.noteName)
        assertEquals(4, a4.octave)
        assertTrue(kotlin.math.abs(a4.centsOffset) < 1.0)

        val e2 = ChordLibraryData.frequencyToNoteInfo(82.41, 0.95f)
        assertNotNull(e2)
        assertEquals("E", e2!!.noteName)
        assertEquals(2, e2.octave)
    }

    @Test
    fun `dsp audio processor applies stereo balance detects clipping and fills fft spectrum`() {
        val dsp = VybeDspAudioProcessor()
        val configured = dsp.configure(AudioProcessor.AudioFormat(44100, 2, C.ENCODING_PCM_16BIT))
        assertEquals(2, configured.channelCount)
        dsp.flush()

        dsp.channelBalance = 1.0f // Full Right: Left channel attenuated to 0
        val buffer = ByteBuffer.allocateDirect(512).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until 128) {
            buffer.putShort(20000) // L
            buffer.putShort(32700) // R (near clipping)
        }
        buffer.flip()

        dsp.queueInput(buffer)
        val out = dsp.getOutput()
        val leftSample = out.short
        val rightSample = out.short

        assertEquals(0, leftSample.toInt())
        assertTrue(rightSample > 25000)
        assertTrue(dsp.isClippingActive())

        val spectrum = FloatArray(32)
        dsp.copySpectrumInto(spectrum)
        assertTrue(spectrum.any { it > 0f })
    }

    @Test
    fun `audio effects engine provides all 10 built in presets`() {
        val engine = AudioEffectsEngine()
        assertEquals(10, engine.builtInPresets.size)
        assertTrue(engine.builtInPresets.all { it.bandLevelsDb.size == 10 })
    }

    @Test
    fun `time formatter formats durations cleanly`() {
        assertEquals("0:00", TimeFormatter.formatDuration(0L))
        assertEquals("3:05", TimeFormatter.formatDuration(185_000L))
        assertEquals("1:02:03", TimeFormatter.formatDuration(3_723_000L))
    }

    @Test
    fun `additive theme and customization presets preserve originals and add studio modes`() {
        assertEquals(
            setOf(
                VybeThemeMode.MODERN,
                VybeThemeMode.RETRO,
                VybeThemeMode.AURORA_GLASS,
                VybeThemeMode.LIQUID_SMOKE,
                VybeThemeMode.HALO_ORCHID
            ),
            VybeThemeMode.entries.toSet()
        )
        assertEquals(8, AccentPreset.entries.size)
        assertEquals(7, ArtworkStyle.entries.size)
        assertEquals(5, PlayerBackgroundStyle.entries.size)
        assertEquals(5, PlayerLayoutStyle.entries.size)
        assertEquals(2, NavDockStyle.entries.size)
    }

    @Test
    fun `10 band biquad equalizer boosts and cuts target frequencies accurately in media3 processor`() {
        fun measureToneRms(freqHz: Double, enabled: Boolean, bandsDb: List<Float>): Float {
            val dsp = VybeDspAudioProcessor()
            dsp.configure(AudioProcessor.AudioFormat(44100, 2, C.ENCODING_PCM_16BIT))
            dsp.flush()
            dsp.setEqBands(enabled, bandsDb)

            val numFrames = 2048
            val buf = ByteBuffer.allocateDirect(numFrames * 4).order(ByteOrder.LITTLE_ENDIAN)
            for (n in 0 until numFrames) {
                val sample = (kotlin.math.sin(2.0 * kotlin.math.PI * freqHz * n / 44100.0) * 8000.0).toInt().toShort()
                buf.putShort(sample)
                buf.putShort(sample)
            }
            buf.flip()
            dsp.queueInput(buf)
            val out = dsp.getOutput()

            // Measure steady-state RMS on the second half of the buffer
            var sumSq = 0.0
            var count = 0
            val totalShorts = out.remaining() / 2
            for (i in 0 until totalShorts) {
                val s = out.short / 32768.0
                if (i >= totalShorts / 2) {
                    sumSq += s * s
                    count++
                }
            }
            return kotlin.math.sqrt(sumSq / count.coerceAtLeast(1)).toFloat()
        }

        val flat = List(10) { 0f }
        val flatRms1k = measureToneRms(1000.0, true, flat)

        val boost1k = List(10) { if (it == 5) 9f else 0f } // 1KHz band
        val boostRms1k = measureToneRms(1000.0, true, boost1k)
        assertTrue("Expected 1kHz +9dB boost ($boostRms1k) > 2x flat ($flatRms1k)", boostRms1k > flatRms1k * 2.1f)

        val cut1k = List(10) { if (it == 5) -9f else 0f }
        val cutRms1k = measureToneRms(1000.0, true, cut1k)
        assertTrue("Expected 1kHz -9dB cut ($cutRms1k) < 0.5x flat ($flatRms1k)", cutRms1k < flatRms1k * 0.5f)

        val bypassRms1k = measureToneRms(1000.0, false, boost1k)
        assertEquals(flatRms1k, bypassRms1k, 0.002f)

        // Sub-bass stability check at 62Hz (index 1)
        val flatRms62 = measureToneRms(62.0, true, flat)
        val boostRms62 = measureToneRms(62.0, true, List(10) { if (it == 1) 9f else 0f })
        assertTrue("Expected 62Hz +9dB boost ($boostRms62) > 1.8x flat ($flatRms62)", boostRms62 > flatRms62 * 1.8f)
    }

    @Test
    fun `lyrics parser handles offset tag metadata tags and enhanced inline timestamps`() {
        val raw = """
            [ti:Midnight Pulse]
            [ar:VYBE Lab]
            [offset:500]
            [00:02.00]<00:02.00>First <00:02.40>line
            [00:06.00]Second line
        """.trimIndent()
        val parsed = LyricsParser.parse(10L, raw, "Local .lrc file")
        assertTrue(parsed.isSynchronized)
        assertEquals("Midnight Pulse", parsed.metadataTitle)
        assertEquals("VYBE Lab", parsed.metadataArtist)
        assertEquals(500L, parsed.offsetMs)
        assertEquals(1500L, parsed.lines[0].timestampMs)
        assertEquals("First line", parsed.lines[0].text)
        assertEquals(5500L, parsed.lines[1].timestampMs)
        assertEquals(0, LyricsParser.activeLineIndex(parsed.lines, 2000L, true))
        val progress = LyricsParser.activeLineProgress(parsed.lines, 0, 3500L, 12000L)
        assertEquals(0.5f, progress, 0.01f)
    }

    @Test
    fun `audio tag extractor parses embedded id3v2 sylt uslt flac and mp4 lyrics tags`() {
        // 1. Synthetic ID3v2.3 SYLT frame
        val syltPayload = ByteArrayOutputStream().apply {
            write(3) // UTF-8
            write("eng".toByteArray(StandardCharsets.ISO_8859_1))
            write(2) // Milliseconds timestamp format
            write(1) // Lyrics content type
            write(0) // Empty content descriptor + null
            write("Hello sync world".toByteArray(StandardCharsets.UTF_8))
            write(0)
            write(byteArrayOf(0x00, 0x00, 0x0B, 0xB8.toByte())) // 3000 ms
            write("Second verse".toByteArray(StandardCharsets.UTF_8))
            write(0)
            write(byteArrayOf(0x00, 0x00, 0x1F, 0x40.toByte())) // 8000 ms
        }.toByteArray()

        val id3Body = ByteArrayOutputStream().apply {
            write("SYLT".toByteArray(StandardCharsets.ISO_8859_1))
            write(byteArrayOf(
                ((syltPayload.size ushr 24) and 0xFF).toByte(),
                ((syltPayload.size ushr 16) and 0xFF).toByte(),
                ((syltPayload.size ushr 8) and 0xFF).toByte(),
                (syltPayload.size and 0xFF).toByte()
            ))
            write(byteArrayOf(0, 0))
            write(syltPayload)
        }.toByteArray()

        val id3Tag = ByteArrayOutputStream().apply {
            write("ID3".toByteArray(StandardCharsets.ISO_8859_1))
            write(byteArrayOf(3, 0, 0))
            val sz = id3Body.size
            write(byteArrayOf(
                ((sz ushr 21) and 0x7F).toByte(),
                ((sz ushr 14) and 0x7F).toByte(),
                ((sz ushr 7) and 0x7F).toByte(),
                (sz and 0x7F).toByte()
            ))
            write(id3Body)
        }.toByteArray()

        val extractedId3 = AudioTagLyricsExtractor.parseId3v2(id3Tag)
        assertNotNull(extractedId3)
        assertTrue(extractedId3!!.isSynchronizedHint)
        val parsedId3 = LyricsParser.parse(99L, extractedId3.rawText, extractedId3.sourceLabel)
        assertTrue(parsedId3.isSynchronized)
        assertEquals(2, parsedId3.lines.size)
        assertEquals(3000L, parsedId3.lines[0].timestampMs)
        assertEquals("Hello sync world", parsedId3.lines[0].text)

        // 2. Synthetic FLAC VORBIS_COMMENT block with LRC inside LYRICS
        val commentText = "LYRICS=[00:01.00]Flac line one\n[00:05.00]Flac line two"
        val commentBytes = commentText.toByteArray(StandardCharsets.UTF_8)
        val vendor = "VYBE".toByteArray(StandardCharsets.UTF_8)
        val vorbisBlock = ByteArrayOutputStream().apply {
            fun writeIntLE(v: Int) {
                write(v and 0xFF); write((v ushr 8) and 0xFF)
                write((v ushr 16) and 0xFF); write((v ushr 24) and 0xFF)
            }
            writeIntLE(vendor.size)
            write(vendor)
            writeIntLE(1)
            writeIntLE(commentBytes.size)
            write(commentBytes)
        }.toByteArray()

        val flacBytes = ByteArrayOutputStream().apply {
            write("fLaC".toByteArray(StandardCharsets.ISO_8859_1))
            write(0x84) // last block = true, type = 4 (VORBIS_COMMENT)
            write((vorbisBlock.size ushr 16) and 0xFF)
            write((vorbisBlock.size ushr 8) and 0xFF)
            write(vorbisBlock.size and 0xFF)
            write(vorbisBlock)
        }.toByteArray()

        val extractedFlac = AudioTagLyricsExtractor.parseFlac(flacBytes)
        assertNotNull(extractedFlac)
        val parsedFlac = LyricsParser.parse(100L, extractedFlac!!.rawText, extractedFlac.sourceLabel)
        assertTrue(parsedFlac.isSynchronized)
        assertEquals("Flac line one", parsedFlac.lines[0].text)
    }

    @Test
    fun `crossfade curve math computes smooth equal power, s-curve, and linear transitions`() {
        assertEquals(3, CrossfadeCurve.entries.size)

        // Equal power: out^2 + in^2 == 1.0 across the entire transition
        listOf(0f, 0.25f, 0.5f, 0.75f, 1f).forEach { p ->
            val (outGain, inGain) = CrossfadeMath.computeGains(p, CrossfadeCurve.EQUAL_POWER)
            assertEquals(1f, outGain * outGain + inGain * inGain, 0.002f)
        }

        // Smooth S-curve endpoints and midpoint
        val (sOut0, sIn0) = CrossfadeMath.computeGains(0f, CrossfadeCurve.SMOOTH_S_CURVE)
        assertEquals(1f, sOut0, 0.001f)
        assertEquals(0f, sIn0, 0.001f)
        val (sOutHalf, sInHalf) = CrossfadeMath.computeGains(0.5f, CrossfadeCurve.SMOOTH_S_CURVE)
        assertEquals(0.5f, sOutHalf, 0.001f)
        assertEquals(0.5f, sInHalf, 0.001f)
        val (sOut1, sIn1) = CrossfadeMath.computeGains(1f, CrossfadeCurve.SMOOTH_S_CURVE)
        assertEquals(0f, sOut1, 0.001f)
        assertEquals(1f, sIn1, 0.001f)

        // Linear midpoint and clamping out-of-range inputs
        val (lOut, lIn) = CrossfadeMath.computeGains(0.3f, CrossfadeCurve.LINEAR)
        assertEquals(0.7f, lOut, 0.001f)
        assertEquals(0.3f, lIn, 0.001f)
        val (clampedOut, clampedIn) = CrossfadeMath.computeGains(1.8f, CrossfadeCurve.LINEAR)
        assertEquals(0f, clampedOut, 0.001f)
        assertEquals(1f, clampedIn, 0.001f)
    }
}
