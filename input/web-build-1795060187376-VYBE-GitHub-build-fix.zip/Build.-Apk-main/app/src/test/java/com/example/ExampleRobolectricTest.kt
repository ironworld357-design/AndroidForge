package com.example

import android.content.Context
import android.content.Intent
import androidx.media3.session.MediaSessionService
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.audio.VybeMediaService
import com.example.data.local.SongEntity
import com.example.data.local.VybeDatabase
import com.example.data.scanner.MediaStoreScanner
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context returns VYBE`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("VYBE", appName)
    }

    @Test
    fun `room database persists songs favorites and playlists offline`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, VybeDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val song = SongEntity(
            id = 42L,
            title = "Midnight Riff",
            artist = "VYBE Trio",
            album = "Analog Sessions",
            albumId = 7L,
            durationMs = 180_000L,
            contentUri = "file:///music/midnight.flac",
            filePath = "/music/midnight.flac",
            folderName = "Music",
            folderPath = "/music",
            genre = "Rock",
            dateAddedSec = 1_700_000_000L,
            sizeBytes = 24_000_000L,
            mimeType = "audio/flac"
        )
        db.songDao().upsertSong(song)
        db.songDao().setFavorite(42L, true)

        val active = db.songDao().observeActiveSongs().first()
        assertEquals(1, active.size)
        assertTrue(active.first().isFavorite)

        db.songDao().softDeleteSong(42L, 123456L)
        assertEquals(0, db.songDao().observeActiveSongs().first().size)
        assertEquals(1, db.songDao().observeDeletedSongs().first().size)

        db.songDao().restoreSong(42L)
        assertEquals(1, db.songDao().observeActiveSongs().first().size)
        db.close()
    }

    @Test
    fun `offline wav sample generator creates valid wav files and sidecar lrc`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val scanner = MediaStoreScanner(context)
        val created = scanner.generateLocalTestWavTracks()
        assertEquals(3, created)

        val scanned = scanner.scanDeviceAudio(emptySet(), emptyMap())
        assertTrue(scanned.size >= 3)
        assertTrue(scanned.any { it.title.contains("Neon Horizon") && it.mimeType == "audio/wav" })
    }

    @Test
    fun `vybe media service initializes exoplayer and media3 session cleanly`() {
        val bindIntent = Intent(MediaSessionService.SERVICE_INTERFACE)
        val controller = Robolectric.buildService(VybeMediaService::class.java, bindIntent)
        val service = controller.create().get()
        val binder = service.onBind(bindIntent)
        assertNotNull(binder)
        controller.destroy()
    }

    @Test
    fun `player controller cycles A-B loop markers cleanly`() {
        val app = ApplicationProvider.getApplicationContext<VybeApplication>()
        val pc = app.playerController
        pc.clearAbLoop()
        assertNull(pc.playbackState.value.abLoopStartMs)
        assertNull(pc.playbackState.value.abLoopEndMs)

        pc.toggleAbLoopMarker() // Sets A
        assertNotNull(pc.playbackState.value.abLoopStartMs)
        assertNull(pc.playbackState.value.abLoopEndMs)

        pc.toggleAbLoopMarker() // Sets B
        assertNotNull(pc.playbackState.value.abLoopStartMs)
        assertNotNull(pc.playbackState.value.abLoopEndMs)

        pc.toggleAbLoopMarker() // Clears A-B loop
        assertNull(pc.playbackState.value.abLoopStartMs)
        assertNull(pc.playbackState.value.abLoopEndMs)
    }
}
