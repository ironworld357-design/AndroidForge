package com.example.audio

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Custom Media3 AudioProcessor delivering:
 * 1. Real-time 10-Band Cascaded Biquad Peaking Equalizer (31Hz..16kHz, -12dB..+12dB, 64-bit accumulators)
 * 2. Preamp Gain (-12dB..+12dB)
 * 3. True Stereo Left/Right Channel Balance
 * 4. Adaptive Volume Normalization with C1-continuous soft-knee limiter
 * 5. Real-time Clipping Detection
 * 6. Lock-free Post-EQ 64-sample Waveform + 32-band FFT Spectrum snapshots for 60/90/120Hz visualizers
 */
@OptIn(UnstableApi::class)
class VybeDspAudioProcessor : BaseAudioProcessor() {

    private class BiquadCoeffs(
        val active: Boolean,
        val b0: Double,
        val b1: Double,
        val b2: Double,
        val a1: Double,
        val a2: Double
    )

    @Volatile var preampDb: Float = 0f
    @Volatile var channelBalance: Float = 0f // -1.0 Left .. +1.0 Right
    @Volatile var normalizationEnabled: Boolean = false
    @Volatile var eqEnabled: Boolean = true
        private set
    @Volatile var activeSampleRateHz: Int = 44100
        private set

    private var eqBandsDbCache: FloatArray = FloatArray(BAND_COUNT)
    @Volatile private var eqBank: Array<BiquadCoeffs> = buildBiquadBank(44100, true, FloatArray(BAND_COUNT))

    // Direct Form II Transposed filter memory: [channel][band]
    private var z1: Array<DoubleArray> = Array(2) { DoubleArray(BAND_COUNT) }
    private var z2: Array<DoubleArray> = Array(2) { DoubleArray(BAND_COUNT) }

    private val clippingFlag = AtomicBoolean(false)
    private val lastClipTimeMs = AtomicLong(0L)

    // Lock-free double-buffered visualization arrays (Post-EQ so visualizer reflects EQ adjustments)
    private val waveformSnapshot = FloatArray(64)
    private val spectrumSnapshot = FloatArray(32)
    private val fftBuffer = FloatArray(FFT_SIZE)
    private var fftWriteIdx = 0
    private val fftRe = FloatArray(FFT_SIZE)
    private val fftIm = FloatArray(FFT_SIZE)
    private var runningRms = 0.2f

    fun setEqBands(enabled: Boolean, bandsDb: List<Float>) {
        val next = FloatArray(BAND_COUNT) { idx ->
            bandsDb.getOrElse(idx) { 0f }.coerceIn(-12f, 12f)
        }
        eqEnabled = enabled
        eqBandsDbCache = next
        eqBank = buildBiquadBank(activeSampleRateHz, enabled, next)
    }

    fun getEqBandsSnapshot(): FloatArray = eqBandsDbCache.copyOf()

    fun isClippingActive(): Boolean {
        val recent = System.currentTimeMillis() - lastClipTimeMs.get() < 450L
        if (!recent) clippingFlag.set(false)
        return clippingFlag.get() || recent
    }

    fun copySpectrumInto(dest: FloatArray) {
        val len = minOf(dest.size, spectrumSnapshot.size)
        for (i in 0 until len) {
            dest[i] = spectrumSnapshot[i]
        }
    }

    fun copyWaveformInto(dest: FloatArray) {
        val len = minOf(dest.size, waveformSnapshot.size)
        for (i in 0 until len) {
            dest[i] = waveformSnapshot[i]
        }
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        val sr = inputAudioFormat.sampleRate.coerceAtLeast(8000)
        val ch = inputAudioFormat.channelCount.coerceAtLeast(1)
        activeSampleRateHz = sr
        eqBank = buildBiquadBank(sr, eqEnabled, eqBandsDbCache)
        if (z1.size != ch) {
            z1 = Array(ch) { DoubleArray(BAND_COUNT) }
            z2 = Array(ch) { DoubleArray(BAND_COUNT) }
        } else {
            resetFilterStates()
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        val channels = inputAudioFormat.channelCount.coerceAtLeast(1)
        val out = replaceOutputBuffer(remaining)

        val preampLinear = 10.0.pow(preampDb / 20.0).toFloat()
        val bal = channelBalance.coerceIn(-1f, 1f)
        val leftGain = if (bal > 0f) 1f - bal else 1f
        val rightGain = if (bal < 0f) 1f + bal else 1f

        val bank = eqBank
        val anyBandActive = eqEnabled && bank.any { it.active }
        val stateZ1 = z1
        val stateZ2 = z2

        var sumSq = 0.0
        var sampleCount = 0

        val normGain = if (normalizationEnabled) {
            val targetRms = 0.24f
            (targetRms / runningRms.coerceAtLeast(0.04f)).coerceIn(0.45f, 2.2f)
        } else 1f

        while (inputBuffer.remaining() >= 2 * channels) {
            var monoSum = 0f
            for (ch in 0 until channels) {
                val rawShort = inputBuffer.short
                var sample = rawShort / 32768f

                // 1. Apply 10-band Peaking Biquad EQ per channel
                if (anyBandActive && ch < stateZ1.size) {
                    var x = sample.toDouble()
                    val chZ1 = stateZ1[ch]
                    val chZ2 = stateZ2[ch]
                    for (b in 0 until BAND_COUNT) {
                        val c = bank[b]
                        if (c.active) {
                            val y = c.b0 * x + chZ1[b]
                            chZ1[b] = c.b1 * x - c.a1 * y + chZ2[b]
                            chZ2[b] = c.b2 * x - c.a2 * y
                            x = y
                        }
                    }
                    sample = x.toFloat()
                }

                // 2. Preamp, Channel Balance & Normalization
                val chGain = when {
                    channels >= 2 && ch == 0 -> leftGain
                    channels >= 2 && ch == 1 -> rightGain
                    else -> 1f
                }
                sample *= preampLinear * chGain * normGain

                // 3. Clipping detection + C1-continuous soft-knee limiter above 0.85f
                val mag = abs(sample)
                if (mag >= 0.985f) {
                    clippingFlag.set(true)
                    lastClipTimeMs.set(System.currentTimeMillis())
                }

                val threshold = 0.85f
                val outFloat = if (mag > threshold) {
                    val excess = (mag - threshold) / (1f - threshold)
                    sign(sample) * (threshold + (1f - threshold) * tanh(excess.toDouble()).toFloat())
                } else {
                    sample
                }.coerceIn(-1f, 1f)

                sumSq += (outFloat * outFloat)
                sampleCount++
                monoSum += outFloat

                val outShort = (outFloat * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                out.putShort(outShort)
            }

            // 4. Feed Post-EQ audio into lock-free FFT / Waveform buffer
            val mono = monoSum / channels
            fftBuffer[fftWriteIdx] = mono
            fftWriteIdx++
            if (fftWriteIdx >= FFT_SIZE) {
                fftWriteIdx = 0
                computeSpectrumAndWaveform()
            }
        }

        while (inputBuffer.hasRemaining()) {
            out.put(inputBuffer.get())
        }

        if (sampleCount > 0) {
            val frameRms = sqrt(sumSq / sampleCount).toFloat()
            runningRms = runningRms * 0.92f + frameRms * 0.08f
        }

        out.flip()
    }

    private fun computeSpectrumAndWaveform() {
        for (i in 0 until 64) {
            waveformSnapshot[i] = (fftBuffer[i * 2] + fftBuffer[i * 2 + 1]) * 0.5f
        }

        for (i in 0 until FFT_SIZE) {
            val window = 0.5f * (1f - cos((2.0 * PI * i / (FFT_SIZE - 1)).toFloat()))
            fftRe[i] = fftBuffer[i] * window
            fftIm[i] = 0f
        }
        fft(fftRe, fftIm)

        val half = FFT_SIZE / 2
        for (band in 0 until 32) {
            val binStart = (band * half) / 32
            val binEnd = (((band + 1) * half) / 32).coerceAtLeast(binStart + 1)
            var magSum = 0f
            for (b in binStart until binEnd) {
                magSum += hypot(fftRe[b], fftIm[b])
            }
            val avgMag = (magSum / (binEnd - binStart)) / (FFT_SIZE / 4f)
            val tilt = 1f + band * 0.045f
            val normalized = (avgMag * tilt).coerceIn(0f, 1f)
            spectrumSnapshot[band] = spectrumSnapshot[band] * 0.35f + normalized * 0.65f
        }
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wLenRe = cos(ang).toFloat()
            val wLenIm = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var wRe = 1f
                var wIm = 0f
                val halfLen = len / 2
                for (k in 0 until halfLen) {
                    val uRe = re[i + k]
                    val uIm = im[i + k]
                    val vRe = re[i + k + halfLen] * wRe - im[i + k + halfLen] * wIm
                    val vIm = re[i + k + halfLen] * wIm + im[i + k + halfLen] * wRe
                    re[i + k] = uRe + vRe
                    im[i + k] = uIm + vIm
                    re[i + k + halfLen] = uRe - vRe
                    im[i + k + halfLen] = uIm - vIm
                    val nextWRe = wRe * wLenRe - wIm * wLenIm
                    wIm = wRe * wLenIm + wIm * wLenRe
                    wRe = nextWRe
                }
                i += len
            }
            len = len shl 1
        }
    }

    override fun onFlush() {
        resetFilterStates()
        fftWriteIdx = 0
    }

    override fun onReset() {
        resetFilterStates()
        waveformSnapshot.fill(0f)
        spectrumSnapshot.fill(0f)
        fftWriteIdx = 0
    }

    private fun resetFilterStates() {
        for (ch in z1.indices) {
            z1[ch].fill(0.0)
            z2[ch].fill(0.0)
        }
    }

    companion object {
        private const val FFT_SIZE = 128
        const val BAND_COUNT = 10
        val BAND_CENTERS_HZ = floatArrayOf(31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
        private const val PEAKING_Q = 1.41421356

        private fun buildBiquadBank(
            sampleRateHz: Int,
            enabled: Boolean,
            bandsDb: FloatArray
        ): Array<BiquadCoeffs> {
            val sr = sampleRateHz.coerceAtLeast(8000).toDouble()
            return Array(BAND_COUNT) { idx ->
                val gainDb = bandsDb.getOrElse(idx) { 0f }.toDouble()
                if (!enabled || abs(gainDb) < 0.05) {
                    BiquadCoeffs(active = false, b0 = 1.0, b1 = 0.0, b2 = 0.0, a1 = 0.0, a2 = 0.0)
                } else {
                    val f0 = BAND_CENTERS_HZ[idx].toDouble().coerceIn(10.0, sr * 0.44)
                    val a = 10.0.pow(gainDb / 40.0)
                    val w0 = 2.0 * PI * f0 / sr
                    val cosW0 = cos(w0)
                    val sinW0 = sin(w0)
                    val alpha = sinW0 / (2.0 * PEAKING_Q)

                    val b0 = 1.0 + alpha * a
                    val b1 = -2.0 * cosW0
                    val b2 = 1.0 - alpha * a
                    val a0 = 1.0 + alpha / a
                    val a1 = -2.0 * cosW0
                    val a2 = 1.0 - alpha / a

                    BiquadCoeffs(
                        active = true,
                        b0 = b0 / a0,
                        b1 = b1 / a0,
                        b2 = b2 / a0,
                        a1 = a1 / a0,
                        a2 = a2 / a0
                    )
                }
            }
        }
    }
}
