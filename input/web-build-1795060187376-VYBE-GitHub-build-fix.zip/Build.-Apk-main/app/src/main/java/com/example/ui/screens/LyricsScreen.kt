package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.PlaybackUiState
import com.example.model.LyricsData
import com.example.model.Song
import com.example.ui.components.SynchronizedLyricsView
import com.example.ui.components.VybeArtwork
import com.example.ui.theme.LocalVybeStyle
import com.example.util.TimeFormatter
import com.example.util.rememberVybeHaptics

@Composable
fun LyricsScreen(
    playbackState: PlaybackUiState,
    lyricsData: LyricsData?,
    onBack: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSaveLyrics: (Long, String) -> Unit,
    onImportLrc: (Long, Uri) -> Unit,
    onWebSearchLyrics: (Song) -> Unit,
    onPlayPause: () -> Unit = {},
    onNext: () -> Unit = {},
    onPrevious: () -> Unit = {},
    onReloadFromFile: () -> Unit = {},
    hapticsEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val haptics = rememberVybeHaptics(hapticsEnabled)
    val song = playbackState.currentSong
    var showEditor by remember { mutableStateOf(false) }
    var manualSyncOffsetMs by remember(song?.id) { mutableLongStateOf(0L) }

    val lrcPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null && song != null) {
            onImportLrc(song.id, uri)
        }
    }

    val duration = playbackState.durationMs.coerceAtLeast(1L)
    val position = playbackState.positionMs.coerceIn(0L, duration)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Header with compact artwork & actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("lyrics_back_btn")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = vybe.textPrimary)
                }
                if (song != null) {
                    VybeArtwork(
                        model = song.artworkModel,
                        contentDescription = song.title,
                        cornerRadius = 10.dp,
                        modifier = Modifier.size(40.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = lyricsData?.metadataTitle ?: song?.title ?: "Lyrics",
                        style = MaterialTheme.typography.titleMedium,
                        color = vybe.textPrimary,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = lyricsData?.metadataArtist ?: song?.artist ?: "No track playing",
                        style = MaterialTheme.typography.bodySmall,
                        color = vybe.textMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (song != null) {
                Row {
                    IconButton(
                        onClick = onReloadFromFile,
                        modifier = Modifier.testTag("reload_lyrics_btn")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Rescan LRC or audio tags", tint = vybe.textMuted)
                    }
                    IconButton(
                        onClick = { lrcPicker.launch(arrayOf("*/*")) },
                        modifier = Modifier.testTag("import_lrc_btn")
                    ) {
                        Icon(Icons.Filled.FileUpload, contentDescription = "Import LRC", tint = vybe.accentSecondary)
                    }
                    IconButton(onClick = { showEditor = true }, modifier = Modifier.testTag("edit_lyrics_btn")) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit lyrics", tint = vybe.textPrimary)
                    }
                    IconButton(onClick = { onWebSearchLyrics(song) }) {
                        Icon(Icons.Filled.Search, contentDescription = "Search lyrics", tint = vybe.textPrimary)
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Sync Truth Badge + Live Timestamp Offset Tuner
        if (lyricsData != null && lyricsData.lines.isNotEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (lyricsData.isSynchronized) vybe.accentSecondary.copy(alpha = 0.14f) else vybe.surfaceElevated,
                border = BorderStroke(0.8.dp, vybe.cardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (lyricsData.isSynchronized) {
                                "SYNCED LYRICS • Tap any line to seek"
                            } else {
                                "STATIC LYRICS • Timing unavailable"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = if (lyricsData.isSynchronized) vybe.accentSecondary else vybe.textMuted,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = lyricsData.sourceLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = vybe.textMuted,
                            fontSize = 10.sp
                        )
                    }

                    if (lyricsData.isSynchronized) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OffsetChip("-0.25s") { haptics.toggle(); manualSyncOffsetMs -= 250L }
                            OffsetChip(
                                label = if (manualSyncOffsetMs == 0L) "Sync 0s" else "%+.2fs".format(manualSyncOffsetMs / 1000f),
                                highlighted = manualSyncOffsetMs != 0L
                            ) { haptics.toggle(); manualSyncOffsetMs = 0L }
                            OffsetChip("+0.25s") { haptics.toggle(); manualSyncOffsetMs += 250L }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(6.dp))

        // Main Centered Real-Time Synchronized Lyrics Viewport
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (song == null || lyricsData == null || lyricsData.lines.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(Icons.Filled.Lyrics, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(48.dp))
                        Text("No Offline Lyrics Found", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
                        Text(
                            "VYBE checks local .lrc files and embedded audio tags (ID3 SYLT/USLT, FLAC, M4A). Import an .lrc file or paste lyrics manually.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = vybe.textMuted,
                            textAlign = TextAlign.Center
                        )
                        if (song != null) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(onClick = { lrcPicker.launch(arrayOf("*/*")) }) {
                                    Text("Import .LRC")
                                }
                                OutlinedButton(onClick = { showEditor = true }) {
                                    Text("Add Lyrics")
                                }
                            }
                        }
                    }
                }
            } else {
                SynchronizedLyricsView(
                    lyricsData = lyricsData,
                    positionMs = position,
                    durationMs = duration,
                    syncOffsetMs = manualSyncOffsetMs,
                    onSeekTo = { ms -> haptics.toggle(); onSeekTo(ms) },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Bottom Real-Time Playback Scrubber & Transport Controls
        if (song != null) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = vybe.surfaceCard.copy(alpha = 0.92f),
                border = BorderStroke(0.8.dp, vybe.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Slider(
                        value = position.toFloat(),
                        onValueChange = {
                            haptics.tick()
                            onSeekTo(it.toLong())
                        },
                        valueRange = 0f..duration.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = vybe.accentSecondary,
                            activeTrackColor = vybe.accentPrimary,
                            inactiveTrackColor = vybe.surfaceElevated
                        ),
                        modifier = Modifier.height(26.dp).testTag("lyrics_seek_slider")
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = TimeFormatter.formatDuration(position),
                            style = MaterialTheme.typography.labelSmall,
                            color = vybe.textMuted
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { haptics.skip(); onPrevious() },
                                modifier = Modifier.size(38.dp).testTag("lyrics_prev_btn")
                            ) {
                                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = vybe.textPrimary)
                            }
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(vybe.accentGradient)
                                    .clickable { haptics.playPause(); onPlayPause() }
                                    .testTag("lyrics_play_pause_btn"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (playbackState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = if (playbackState.isPlaying) "Pause" else "Play",
                                    tint = if (vybe.isRetro) Color(0xFF1D1309) else Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            IconButton(
                                onClick = { haptics.skip(); onNext() },
                                modifier = Modifier.size(38.dp).testTag("lyrics_next_btn")
                            ) {
                                Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = vybe.textPrimary)
                            }
                        }
                        Text(
                            text = TimeFormatter.formatDuration(duration),
                            style = MaterialTheme.typography.labelSmall,
                            color = vybe.textMuted
                        )
                    }
                }
            }
        }
    }

    if (showEditor && song != null) {
        var editorText by remember { mutableStateOf(lyricsData?.rawText ?: "") }
        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text("Edit Lyrics (LRC or Plain)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Tip: Prefix lines with [mm:ss.xx] for synchronized scrolling, or paste plain text.",
                        style = MaterialTheme.typography.labelSmall,
                        color = vybe.textMuted
                    )
                    OutlinedTextField(
                        value = editorText,
                        onValueChange = { editorText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp),
                        placeholder = { Text("[00:12.50]First lyric line...") }
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveLyrics(song.id, editorText)
                    showEditor = false
                }) { Text("Save Offline") }
            },
            dismissButton = {
                TextButton(onClick = { showEditor = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun OffsetChip(
    label: String,
    highlighted: Boolean = false,
    onClick: () -> Unit
) {
    val vybe = LocalVybeStyle.current
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(6.dp),
        color = if (highlighted) vybe.accentPrimary.copy(alpha = 0.25f) else vybe.surfaceCard,
        border = BorderStroke(0.7.dp, vybe.cardBorder)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (highlighted) vybe.accentSecondary else vybe.textMuted,
            fontSize = 10.sp,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}
