package com.example.util

import android.app.Activity
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.PowerManager
import android.view.Display
import com.example.model.DisplayRefreshInfo
import com.example.model.PerformanceMode
import kotlin.math.roundToInt

object DisplayRefreshRateManager {

    fun queryDisplayInfo(context: Context): DisplayRefreshInfo {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isPowerSave = powerManager?.isPowerSaveMode ?: false
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)

        val currentRate = display?.refreshRate ?: 60f
        val supportedRates = if (display != null) {
            display.supportedModes
                .map { it.refreshRate }
                .distinctBy { it.roundToInt() }
                .sorted()
        } else {
            listOf(60f)
        }

        val activeLabel = "${currentRate.roundToInt()} Hz"
        return DisplayRefreshInfo(
            currentRefreshRateHz = currentRate,
            supportedRatesHz = supportedRates,
            isPowerSaveMode = isPowerSave,
            activeModeLabel = activeLabel
        )
    }

    fun applyPerformanceMode(activity: Activity, mode: PerformanceMode) {
        val window = activity.window ?: return
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity.display
        } else {
            @Suppress("DEPRECATION")
            activity.windowManager.defaultDisplay
        } ?: return

        val powerManager = activity.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isBatterySaver = powerManager?.isPowerSaveMode ?: false

        val supportedModes = display.supportedModes.toList()
        if (supportedModes.isEmpty()) return

        val currentMode = display.mode
        val sameResolutionModes = supportedModes.filter {
            it.physicalWidth == currentMode.physicalWidth &&
                it.physicalHeight == currentMode.physicalHeight
        }.ifEmpty { supportedModes }

        val chosenMode = when (mode) {
            PerformanceMode.HIGH_REFRESH -> {
                if (isBatterySaver) {
                    // Respect Android battery saver restrictions
                    sameResolutionModes.minByOrNull { kotlin.math.abs(it.refreshRate - 60f) }
                } else {
                    sameResolutionModes.maxByOrNull { it.refreshRate }
                }
            }
            PerformanceMode.BALANCED -> {
                sameResolutionModes.minByOrNull { kotlin.math.abs(it.refreshRate - 60f) }
            }
            PerformanceMode.AUTO -> {
                // Let Android ARR / system manage dynamically by passing 0 (default)
                null
            }
        }

        val attrs = window.attributes
        val targetModeId = chosenMode?.modeId ?: 0
        if (attrs.preferredDisplayModeId != targetModeId) {
            attrs.preferredDisplayModeId = targetModeId
            window.attributes = attrs
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
            // Android 15+ Adaptive Refresh Rate power savings balance
            window.isFrameRatePowerSavingsBalanced = (mode != PerformanceMode.HIGH_REFRESH)
        }
    }

    fun targetFrameIntervalNanos(
        mode: PerformanceMode,
        displayInfo: DisplayRefreshInfo
    ): Long {
        val maxSupported = displayInfo.supportedRatesHz.maxOrNull() ?: displayInfo.currentRefreshRateHz
        val targetHz = when (mode) {
            PerformanceMode.HIGH_REFRESH -> {
                if (displayInfo.isPowerSaveMode) 60f else maxSupported.coerceAtLeast(60f)
            }
            PerformanceMode.BALANCED -> 60f
            PerformanceMode.AUTO -> {
                if (displayInfo.isPowerSaveMode) 60f else displayInfo.currentRefreshRateHz.coerceAtLeast(60f)
            }
        }
        return (1_000_000_000.0 / targetHz.toDouble()).toLong()
    }
}
