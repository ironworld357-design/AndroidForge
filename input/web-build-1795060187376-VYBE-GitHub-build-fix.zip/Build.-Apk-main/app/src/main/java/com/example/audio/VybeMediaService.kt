package com.example.audio

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.BitmapLoader
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSourceBitmapLoader
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.CacheBitmapLoader
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaConstants
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.example.MainActivity
import com.example.R
import com.example.VybeApplication
import com.example.data.local.VybeSettings
import com.example.model.CrossfadeCurve
import com.example.model.CrossfadeMath
import com.example.model.RepeatMode
import com.example.model.Song
import com.example.widget.VybeWidgetUpdater
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.google.common.util.concurrent.SettableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

@OptIn(UnstableApi::class)
class VybeMediaService : MediaSessionService() {

    private var player: ExoPlayer? = null
    private var crossfadePlayer: ExoPlayer? = null
    private val crossfadeDspProcessor = VybeDspAudioProcessor()
    private var mediaSession: MediaSession? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var tickerJob: Job? = null
    private var crossfadeJob: Job? = null
    private var isCrossfading: Boolean = false
    private var crossfadeTriggeredForIndex: Int = C.INDEX_UNSET
    private var latestSettings: VybeSettings = VybeSettings()
    private var userBaseVolume: Float = 1.0f

    private var currentActiveSong: Song? = null
    private var accumulatedListenMs: Long = 0L
    private var lastTickTimeMs: Long = 0L

    private val app: VybeApplication
        get() = application as VybeApplication

    override fun onCreate() {
        super.onCreate()

        val dspProcessor = app.dspProcessor
        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(dspProcessor))
                    .setEnableFloatOutput(false) // Keep PCM 16-bit for DSP processor compatibility
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .build()
            }
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val exoPlayer = ExoPlayer.Builder(this, renderersFactory)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        exoPlayer.pauseAtEndOfMediaItems = false // Gapless playback

        // Secondary pre-buffering player for overlapping Media3 crossfades (no audio focus theft)
        val cfRenderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(crossfadeDspProcessor))
                    .setEnableFloatOutput(false)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .build()
            }
        }
        crossfadePlayer = ExoPlayer.Builder(this, cfRenderersFactory)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ false)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build().apply {
                volume = 0f
                pauseAtEndOfMediaItems = false
            }

        exoPlayer.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                app.audioEffectsEngine.attachToAudioSession(audioSessionId)
                serviceScope.launch {
                    val settings = app.settingsDataStore.settingsFlow.first()
                    app.audioEffectsEngine.applyEqualizer(settings.eqEnabled, settings.eqBandsDb)
                    app.audioEffectsEngine.applyBassBoost(settings.eqEnabled, settings.bassBoostStrength)
                    app.audioEffectsEngine.applyVirtualizer(settings.eqEnabled, settings.virtualizerStrength)
                    app.audioEffectsEngine.applyLoudnessEnhancer(settings.eqEnabled, settings.loudnessGainMb)
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    lastTickTimeMs = System.currentTimeMillis()
                    startSessionTicker()
                } else {
                    if (isCrossfading) cancelActiveCrossfade(restoreVolume = true)
                    flushListeningSession()
                    stopSessionTicker()
                }
                refreshNotificationPreferences()
                pushWidgetUpdate()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (!isCrossfading) {
                    crossfadeTriggeredForIndex = C.INDEX_UNSET
                }
                flushListeningSession()
                val songId = mediaItem?.mediaId?.toLongOrNull()
                serviceScope.launch {
                    val songs = app.musicRepository.songsFlow.first()
                    val matched = songs.firstOrNull { it.id == songId }
                    currentActiveSong = matched
                    if (matched != null) {
                        app.musicRepository.recordSongPlay(matched)
                    }
                    refreshNotificationPreferences()
                    pushWidgetUpdate()
                }
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                refreshNotificationPreferences()
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                refreshNotificationPreferences()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                pushWidgetUpdate()
            }
        })

        // Configure rich Media3 foreground notification provider
        val notificationProvider = DefaultMediaNotificationProvider.Builder(this)
            .setChannelId(VYBE_NOTIFICATION_CHANNEL_ID)
            .setChannelName(R.string.vybe_playback_channel_name)
            .build().apply {
                setSmallIcon(R.drawable.ic_vybe_notif_logo)
            }
        setMediaNotificationProvider(notificationProvider)

        // Tapping notification or lock-screen media card opens Now Playing directly
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_NOW_PLAYING, true)
        }
        val sessionActivityPi = PendingIntent.getActivity(
            this,
            101,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        mediaSession = MediaSession.Builder(this, exoPlayer)
            .setSessionActivity(sessionActivityPi)
            .setCallback(VybeSessionCallback())
            .setBitmapLoader(VybeSessionBitmapLoader(this))
            .setMediaButtonPreferences(buildNotificationButtons(exoPlayer))
            .build()

        player = exoPlayer

        // Continuously sync user DSP & playback settings into ExoPlayer, Crossfade Deck, Media3 AudioProcessor & MediaSession
        serviceScope.launch {
            app.settingsDataStore.settingsFlow.collect { settings ->
                latestSettings = settings
                dspProcessor.setEqBands(settings.eqEnabled, settings.eqBandsDb)
                dspProcessor.preampDb = settings.preampDb
                dspProcessor.channelBalance = settings.channelBalance
                dspProcessor.normalizationEnabled = settings.volumeNormalization

                crossfadeDspProcessor.setEqBands(settings.eqEnabled, settings.eqBandsDb)
                crossfadeDspProcessor.preampDb = settings.preampDb
                crossfadeDspProcessor.channelBalance = settings.channelBalance
                crossfadeDspProcessor.normalizationEnabled = settings.volumeNormalization

                exoPlayer.setHandleAudioBecomingNoisy(settings.autoPauseOnDisconnect)
                exoPlayer.skipSilenceEnabled = settings.skipSilenceEnabled
                exoPlayer.pauseAtEndOfMediaItems = !settings.gaplessPlayback && settings.crossfadeDurationMs <= 0
            }
        }

        // Keep favorite button icon synced on lock screen / notification when changed in app UI
        serviceScope.launch {
            app.musicRepository.songsFlow.collect { songs ->
                val curId = currentActiveSong?.id ?: return@collect
                val updated = songs.firstOrNull { it.id == curId } ?: return@collect
                if (updated.isFavorite != currentActiveSong?.isFavorite) {
                    currentActiveSong = updated
                    refreshNotificationPreferences()
                    pushWidgetUpdate()
                }
            }
        }
    }

    private fun buildNotificationButtons(exoPlayer: ExoPlayer): List<CommandButton> {
        val isFav = currentActiveSong?.isFavorite == true
        val favButton = CommandButton.Builder(
            if (isFav) CommandButton.ICON_HEART_FILLED else CommandButton.ICON_HEART_UNFILLED
        )
            .setCustomIconResId(
                if (isFav) R.drawable.ic_notif_heart_filled else R.drawable.ic_notif_heart_outline
            )
            .setDisplayName(getString(R.string.vybe_notif_favorite))
            .setSessionCommand(SessionCommand(CMD_TOGGLE_FAVORITE, Bundle.EMPTY))
            .setSlots(CommandButton.SLOT_OVERFLOW)
            .build()

        val shuffleOn = exoPlayer.shuffleModeEnabled
        val shuffleButton = CommandButton.Builder(
            if (shuffleOn) CommandButton.ICON_SHUFFLE_ON else CommandButton.ICON_SHUFFLE_OFF
        )
            .setCustomIconResId(R.drawable.ic_notif_shuffle)
            .setDisplayName(getString(R.string.vybe_notif_shuffle))
            .setSessionCommand(SessionCommand(CMD_TOGGLE_SHUFFLE, Bundle.EMPTY))
            .setSlots(CommandButton.SLOT_OVERFLOW)
            .build()

        val repeatIcon = when (exoPlayer.repeatMode) {
            Player.REPEAT_MODE_ONE -> CommandButton.ICON_REPEAT_ONE
            Player.REPEAT_MODE_ALL -> CommandButton.ICON_REPEAT_ALL
            else -> CommandButton.ICON_REPEAT_OFF
        }
        val repeatRes = if (exoPlayer.repeatMode == Player.REPEAT_MODE_ONE) {
            R.drawable.ic_notif_repeat_one
        } else {
            R.drawable.ic_notif_repeat
        }
        val repeatButton = CommandButton.Builder(repeatIcon)
            .setCustomIconResId(repeatRes)
            .setDisplayName(getString(R.string.vybe_notif_repeat))
            .setSessionCommand(SessionCommand(CMD_CYCLE_REPEAT, Bundle.EMPTY))
            .setSlots(CommandButton.SLOT_OVERFLOW)
            .build()

        val replay10Button = CommandButton.Builder(CommandButton.ICON_SKIP_BACK_10)
            .setCustomIconResId(R.drawable.ic_notif_replay_10)
            .setDisplayName(getString(R.string.vybe_notif_replay_10))
            .setSessionCommand(SessionCommand(CMD_SEEK_BACK_10, Bundle.EMPTY))
            .setSlots(CommandButton.SLOT_OVERFLOW)
            .build()

        val forward10Button = CommandButton.Builder(CommandButton.ICON_SKIP_FORWARD_10)
            .setCustomIconResId(R.drawable.ic_notif_forward_10)
            .setDisplayName(getString(R.string.vybe_notif_forward_10))
            .setSessionCommand(SessionCommand(CMD_SEEK_FORWARD_10, Bundle.EMPTY))
            .setSlots(CommandButton.SLOT_OVERFLOW)
            .build()

        return listOf(favButton, shuffleButton, repeatButton, replay10Button, forward10Button)
    }

    private fun refreshNotificationPreferences() {
        val session = mediaSession ?: return
        val exoPlayer = player ?: return
        session.setMediaButtonPreferences(buildNotificationButtons(exoPlayer))
    }

    private inner class VybeSessionCallback : MediaSession.Callback {

        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val sessionCommands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_TOGGLE_FAVORITE, Bundle.EMPTY))
                .add(SessionCommand(CMD_TOGGLE_SHUFFLE, Bundle.EMPTY))
                .add(SessionCommand(CMD_CYCLE_REPEAT, Bundle.EMPTY))
                .add(SessionCommand(CMD_SEEK_BACK_10, Bundle.EMPTY))
                .add(SessionCommand(CMD_SEEK_FORWARD_10, Bundle.EMPTY))
                .add(SessionCommand(CMD_CROSSFADE_SKIP_TO, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_BASE_VOLUME, Bundle.EMPTY))
                .build()

            val exoPlayer = player
            val prefs = if (exoPlayer != null) buildNotificationButtons(exoPlayer) else emptyList()

            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(sessionCommands)
                .setMediaButtonPreferences(prefs)
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            val exoPlayer = player
            when (customCommand.customAction) {
                CMD_TOGGLE_FAVORITE -> {
                    currentActiveSong?.let { song ->
                        val nextFav = !song.isFavorite
                        currentActiveSong = song.copy(isFavorite = nextFav)
                        serviceScope.launch {
                            app.musicRepository.toggleFavorite(song.id, song.isFavorite)
                            refreshNotificationPreferences()
                            pushWidgetUpdate()
                        }
                    }
                }
                CMD_TOGGLE_SHUFFLE -> {
                    if (exoPlayer != null) {
                        val nextShuffle = !exoPlayer.shuffleModeEnabled
                        exoPlayer.shuffleModeEnabled = nextShuffle
                        serviceScope.launch { app.settingsDataStore.setShuffleEnabled(nextShuffle) }
                        refreshNotificationPreferences()
                    }
                }
                CMD_CYCLE_REPEAT -> {
                    if (exoPlayer != null) {
                        val nextRepeat = when (exoPlayer.repeatMode) {
                            Player.REPEAT_MODE_OFF -> RepeatMode.ALL
                            Player.REPEAT_MODE_ALL -> RepeatMode.ONE
                            else -> RepeatMode.OFF
                        }
                        exoPlayer.repeatMode = when (nextRepeat) {
                            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
                            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
                            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
                        }
                        serviceScope.launch { app.settingsDataStore.setRepeatMode(nextRepeat) }
                        refreshNotificationPreferences()
                    }
                }
                CMD_SEEK_BACK_10 -> {
                    if (exoPlayer != null) {
                        exoPlayer.seekTo((exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L))
                    }
                }
                CMD_SEEK_FORWARD_10 -> {
                    if (exoPlayer != null) {
                        val dur = exoPlayer.duration.takeIf { it > 0L } ?: Long.MAX_VALUE
                        exoPlayer.seekTo((exoPlayer.currentPosition + 10_000L).coerceAtMost(dur))
                    }
                }
                CMD_CROSSFADE_SKIP_TO -> {
                    val targetIndex = args.getInt(ARG_TARGET_INDEX, C.INDEX_UNSET)
                    if (exoPlayer != null && targetIndex in 0 until exoPlayer.mediaItemCount) {
                        val fadeMs = (latestSettings.crossfadeDurationMs / 2L).coerceIn(700L, 2500L)
                        startCrossfadeToIndex(targetIndex, fadeMs, latestSettings.crossfadeCurve)
                    }
                }
                CMD_SET_BASE_VOLUME -> {
                    val vol = args.getFloat(ARG_VOLUME, 1.0f).coerceIn(0f, 1f)
                    userBaseVolume = vol
                    if (!isCrossfading) {
                        exoPlayer?.volume = vol
                    }
                }
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }

        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val settable = SettableFuture.create<MediaSession.MediaItemsWithStartPosition>()
            serviceScope.launch {
                runCatching {
                    val settings = app.settingsDataStore.settingsFlow.first()
                    val songs = app.musicRepository.songsFlow.first()
                    val songMap = songs.associateBy { it.id }
                    val restoredQueue = settings.lastQueueIds.mapNotNull { songMap[it] }.ifEmpty {
                        listOfNotNull(songMap[settings.lastSongId]).ifEmpty { songs.take(15) }
                    }
                    if (restoredQueue.isEmpty()) {
                        settable.setException(IllegalStateException("No offline tracks available for resumption"))
                        return@launch
                    }
                    val startIdx = restoredQueue.indexOfFirst { it.id == settings.lastSongId }.coerceAtLeast(0)
                    val startPos = settings.lastPositionMs.coerceAtLeast(0L)

                    player?.apply {
                        shuffleModeEnabled = settings.shuffleEnabled
                        repeatMode = when (settings.repeatMode) {
                            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
                            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
                            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
                        }
                        playbackParameters = PlaybackParameters(settings.playbackSpeed)
                    }

                    val mediaItems = restoredQueue.map { song ->
                        val dur = song.durationMs.coerceAtLeast(1L)
                        val progressFraction = (startPos.toDouble() / dur.toDouble()).coerceIn(0.0, 1.0)
                        val extras = Bundle().apply {
                            putInt(
                                MediaConstants.EXTRAS_KEY_COMPLETION_STATUS,
                                MediaConstants.EXTRAS_VALUE_COMPLETION_STATUS_PARTIALLY_PLAYED
                            )
                            putDouble(MediaConstants.EXTRAS_KEY_COMPLETION_PERCENTAGE, progressFraction)
                        }
                        MediaItem.Builder()
                            .setMediaId(song.id.toString())
                            .setUri(song.contentUri)
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(song.title)
                                    .setArtist(song.artist)
                                    .setAlbumTitle(song.album)
                                    .setArtworkUri(Uri.parse(song.customArtworkUri ?: "content://media/external/audio/albumart/${song.albumId}"))
                                    .setExtras(extras)
                                    .build()
                            )
                            .build()
                    }
                    currentActiveSong = restoredQueue[startIdx]
                    settable.set(MediaSession.MediaItemsWithStartPosition(mediaItems, startIdx, startPos))
                }.onFailure { err ->
                    settable.setException(err)
                }
            }
            return settable
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_WIDGET_PLAY_PAUSE -> {
                player?.let { p ->
                    if (p.isPlaying) p.pause() else {
                        if (p.playbackState == Player.STATE_IDLE && p.mediaItemCount > 0) p.prepare()
                        p.play()
                    }
                }
            }
            ACTION_WIDGET_NEXT -> player?.seekToNextMediaItem()
            ACTION_WIDGET_PREV -> player?.seekToPreviousMediaItem()
            ACTION_WIDGET_FAVORITE -> {
                currentActiveSong?.let { song ->
                    serviceScope.launch {
                        app.musicRepository.toggleFavorite(song.id, song.isFavorite)
                        currentActiveSong = song.copy(isFavorite = !song.isFavorite)
                        refreshNotificationPreferences()
                        pushWidgetUpdate()
                    }
                }
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    private fun startSessionTicker() {
        tickerJob?.cancel()
        tickerJob = serviceScope.launch {
            var tickCount = 0
            while (isActive) {
                delay(150L)
                val p = player ?: continue
                if (p.isPlaying) {
                    val now = System.currentTimeMillis()
                    if (lastTickTimeMs > 0L) {
                        accumulatedListenMs += (now - lastTickTimeMs).coerceIn(0L, 5000L)
                    }
                    lastTickTimeMs = now

                    // Automatic overlapping Media3 crossfade near track end
                    val cfMs = latestSettings.crossfadeDurationMs
                    if (!isCrossfading && cfMs > 0 && p.repeatMode != Player.REPEAT_MODE_ONE) {
                        val nextIdx = p.nextMediaItemIndex
                        val dur = p.duration
                        val pos = p.currentPosition
                        if (nextIdx != C.INDEX_UNSET &&
                            nextIdx != crossfadeTriggeredForIndex &&
                            dur > cfMs + 1200L
                        ) {
                            val remaining = dur - pos
                            if (remaining in 350L..cfMs.toLong()) {
                                startCrossfadeToIndex(
                                    targetIndex = nextIdx,
                                    durationMs = remaining.coerceAtLeast(500L),
                                    curve = latestSettings.crossfadeCurve
                                )
                            }
                        }
                    }

                    // Save resumption position & push widget updates every ~5 seconds
                    tickCount++
                    if (tickCount % 33 == 0) {
                        val songId = p.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L
                        val qIds = (0 until p.mediaItemCount).mapNotNull {
                            p.getMediaItemAt(it).mediaId.toLongOrNull()
                        }
                        if (songId != -1L) {
                            app.settingsDataStore.savePlaybackResumption(songId, p.currentPosition, qIds)
                        }
                        pushWidgetUpdate()
                    }
                }
            }
        }
    }

    private fun startCrossfadeToIndex(targetIndex: Int, durationMs: Long, curve: CrossfadeCurve) {
        val main = player ?: return
        val deck = crossfadePlayer ?: return
        if (targetIndex !in 0 until main.mediaItemCount) return
        val startIndex = main.currentMediaItemIndex
        val targetItem = main.getMediaItemAt(targetIndex)

        crossfadeJob?.cancel()
        isCrossfading = true
        crossfadeTriggeredForIndex = targetIndex
        app.isCrossfadingFlow.value = true

        val baseVol = if (main.volume > 0.05f) main.volume.coerceIn(0.05f, 1f) else userBaseVolume

        crossfadeJob = serviceScope.launch {
            try {
                deck.setMediaItem(targetItem)
                deck.playbackParameters = main.playbackParameters
                deck.skipSilenceEnabled = main.skipSilenceEnabled
                deck.volume = 0f
                deck.prepare()
                deck.play()

                // Wait briefly for the incoming track decoder to reach READY without stalling
                var waitMs = 0L
                while (deck.playbackState == Player.STATE_BUFFERING && waitMs < 450L && isActive) {
                    delay(16L)
                    waitMs += 16L
                }

                val fadeMs = durationMs.coerceAtLeast(400L)
                val startTime = System.currentTimeMillis()
                while (isActive) {
                    if (!main.isPlaying || main.currentMediaItemIndex != startIndex) {
                        cancelActiveCrossfade(restoreVolume = true)
                        return@launch
                    }
                    val elapsed = System.currentTimeMillis() - startTime
                    val t = (elapsed.toFloat() / fadeMs.toFloat()).coerceIn(0f, 1f)
                    val (outGain, inGain) = CrossfadeMath.computeGains(t, curve)
                    main.volume = baseVol * outGain
                    deck.volume = baseVol * inGain

                    if (t >= 1f) break
                    delay(25L)
                }

                // Hand off seamlessly from overlapping deck back to the primary MediaSession player
                val handoffPos = deck.currentPosition.coerceAtLeast(0L)
                main.seekTo(targetIndex, handoffPos + 12L)
                main.volume = baseVol

                // Keep deck softly supporting for 35ms while primary seeks & resumes
                delay(35L)
                deck.volume = 0f
                deck.pause()
                deck.clearMediaItems()
            } finally {
                isCrossfading = false
                app.isCrossfadingFlow.value = false
                if (main.volume < baseVol * 0.9f) {
                    main.volume = baseVol
                }
            }
        }
    }

    private fun cancelActiveCrossfade(restoreVolume: Boolean) {
        crossfadeJob?.cancel()
        crossfadeJob = null
        isCrossfading = false
        app.isCrossfadingFlow.value = false
        crossfadePlayer?.apply {
            volume = 0f
            pause()
            clearMediaItems()
        }
        if (restoreVolume) {
            player?.volume = userBaseVolume
        }
    }

    private fun stopSessionTicker() {
        tickerJob?.cancel()
        tickerJob = null
    }

    private fun flushListeningSession() {
        val song = currentActiveSong
        val listened = accumulatedListenMs
        accumulatedListenMs = 0L
        lastTickTimeMs = 0L
        if (song != null && listened >= 1500L) {
            serviceScope.launch {
                app.musicRepository.recordListeningSession(song, listened)
            }
        }
    }

    private fun pushWidgetUpdate() {
        val p = player
        VybeWidgetUpdater.updateAllWidgets(
            context = this,
            song = currentActiveSong,
            isPlaying = p?.isPlaying == true,
            positionMs = p?.currentPosition ?: 0L,
            durationMs = p?.duration?.coerceAtLeast(0L) ?: currentActiveSong?.durationMs ?: 0L
        )
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        cancelActiveCrossfade(restoreVolume = false)
        flushListeningSession()
        stopSessionTicker()
        crossfadePlayer?.release()
        crossfadePlayer = null
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        player = null
        app.audioEffectsEngine.release()
        serviceScope.cancel()
        super.onDestroy()
    }

    private class VybeSessionBitmapLoader(private val context: Context) : BitmapLoader {
        private val executor = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())
        private val delegate = CacheBitmapLoader(DataSourceBitmapLoader(executor, DefaultDataSource.Factory(context)))

        override fun supportsMimeType(mimeType: String): Boolean = delegate.supportsMimeType(mimeType)

        override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> = delegate.decodeBitmap(data)

        override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> {
            return Futures.catchingAsync(
                delegate.loadBitmap(uri),
                Throwable::class.java,
                { loadFallbackArtwork(uri) },
                executor
            )
        }

        private fun loadFallbackArtwork(uri: Uri): ListenableFuture<Bitmap> {
            return executor.submit<Bitmap> {
                // Attempt embedded picture extraction if uri points to an audio file
                if (uri.scheme == "file" || (uri.scheme == "content" && !uri.toString().contains("albumart"))) {
                    val mmr = MediaMetadataRetriever()
                    try {
                        mmr.setDataSource(context, uri)
                        mmr.embeddedPicture?.let { bytes ->
                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { return@submit it }
                        }
                    } catch (_: Throwable) {
                    } finally {
                        runCatching { mmr.release() }
                    }
                }
                val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                BitmapFactory.decodeResource(context.resources, R.drawable.img_default_album, opts)
                    ?: Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
            }
        }
    }

    companion object {
        const val VYBE_NOTIFICATION_CHANNEL_ID = "vybe_playback_channel"
        const val EXTRA_OPEN_NOW_PLAYING = "com.example.vybe.EXTRA_OPEN_NOW_PLAYING"

        const val CMD_TOGGLE_FAVORITE = "com.example.vybe.CMD_TOGGLE_FAVORITE"
        const val CMD_TOGGLE_SHUFFLE = "com.example.vybe.CMD_TOGGLE_SHUFFLE"
        const val CMD_CYCLE_REPEAT = "com.example.vybe.CMD_CYCLE_REPEAT"
        const val CMD_SEEK_BACK_10 = "com.example.vybe.CMD_SEEK_BACK_10"
        const val CMD_SEEK_FORWARD_10 = "com.example.vybe.CMD_SEEK_FORWARD_10"
        const val CMD_CROSSFADE_SKIP_TO = "com.example.vybe.CMD_CROSSFADE_SKIP_TO"
        const val CMD_SET_BASE_VOLUME = "com.example.vybe.CMD_SET_BASE_VOLUME"

        const val ARG_TARGET_INDEX = "target_index"
        const val ARG_VOLUME = "volume"

        const val ACTION_WIDGET_PLAY_PAUSE = "com.example.vybe.ACTION_WIDGET_PLAY_PAUSE"
        const val ACTION_WIDGET_NEXT = "com.example.vybe.ACTION_WIDGET_NEXT"
        const val ACTION_WIDGET_PREV = "com.example.vybe.ACTION_WIDGET_PREV"
        const val ACTION_WIDGET_FAVORITE = "com.example.vybe.ACTION_WIDGET_FAVORITE"
    }
}
