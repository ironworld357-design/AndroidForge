package com.example.data.repo

import android.content.Context
import android.net.Uri
import com.example.data.local.EqPresetEntity
import com.example.data.local.ExcludedFolderEntity
import com.example.data.local.ListeningSessionEntity
import com.example.data.local.LyricsEntity
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistSongCrossRef
import com.example.data.local.SongEntity
import com.example.data.local.VybeDatabase
import com.example.data.scanner.MediaStoreScanner
import com.example.model.AlbumGroup
import com.example.model.ArtistGroup
import com.example.model.DuplicateGroup
import com.example.model.EqPreset
import com.example.model.FolderGroup
import com.example.model.GenreGroup
import com.example.model.ListeningStatSummary
import com.example.model.LyricsData
import com.example.model.Playlist
import com.example.model.SmartPlaylistType
import com.example.model.Song
import com.example.util.LyricsParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Serializable
private data class ExportedPlaylistJson(
    val name: String,
    val songs: List<ExportedSongRef>
)

@Serializable
private data class ExportedSongRef(
    val title: String,
    val artist: String,
    val filePath: String
)

class MusicRepository(
    private val context: Context,
    private val database: VybeDatabase,
    private val scanner: MediaStoreScanner
) {
    private val songDao = database.songDao()
    private val playlistDao = database.playlistDao()
    private val eqPresetDao = database.eqPresetDao()
    private val lyricsDao = database.lyricsDao()
    private val statsDao = database.statsDao()
    private val excludedFolderDao = database.excludedFolderDao()

    val songsFlow: Flow<List<Song>> = songDao.observeActiveSongs().map { list ->
        list.map { it.toDomain() }
    }

    val deletedSongsFlow: Flow<List<Song>> = songDao.observeDeletedSongs().map { list ->
        list.map { it.toDomain() }
    }

    val excludedFoldersFlow: Flow<List<ExcludedFolderEntity>> =
        excludedFolderDao.observeExcludedFolders()

    val customPlaylistsFlow: Flow<List<Playlist>> = combine(
        playlistDao.observePlaylists(),
        playlistDao.observeAllPlaylistSongs(),
        songsFlow
    ) { playlists, refs, allSongs ->
        val songMap = allSongs.associateBy { it.id }
        val groupedRefs = refs.groupBy { it.playlistId }
        playlists.map { pl ->
            val plSongs = groupedRefs[pl.id]
                ?.sortedBy { it.sortOrder }
                ?.mapNotNull { songMap[it.songId] }
                ?: emptyList()
            Playlist(
                id = pl.id,
                name = pl.name,
                customArtworkUri = pl.customArtworkUri,
                createdAt = pl.createdAt,
                songs = plSongs,
                isSmart = false
            )
        }
    }

    val smartPlaylistsFlow: Flow<List<Playlist>> = songsFlow.map { songs ->
        listOf(
            Playlist(
                id = -1L,
                name = "Favorites",
                songs = songs.filter { it.isFavorite },
                isSmart = true,
                smartType = SmartPlaylistType.FAVORITES
            ),
            Playlist(
                id = -2L,
                name = "Recently Played",
                songs = songs.filter { it.lastPlayedAt > 0L }
                    .sortedByDescending { it.lastPlayedAt }
                    .take(50),
                isSmart = true,
                smartType = SmartPlaylistType.RECENTLY_PLAYED
            ),
            Playlist(
                id = -3L,
                name = "Most Played",
                songs = songs.filter { it.playCount > 0 }
                    .sortedByDescending { it.playCount }
                    .take(50),
                isSmart = true,
                smartType = SmartPlaylistType.MOST_PLAYED
            ),
            Playlist(
                id = -4L,
                name = "Recently Added",
                songs = songs.sortedByDescending { it.dateAddedSec }.take(40),
                isSmart = true,
                smartType = SmartPlaylistType.RECENTLY_ADDED
            ),
            Playlist(
                id = -5L,
                name = "Lossless Hi-Fi",
                songs = songs.filter { it.isLossless },
                isSmart = true,
                smartType = SmartPlaylistType.LOSSLESS_HIFI
            )
        )
    }

    val customEqPresetsFlow: Flow<List<EqPreset>> = eqPresetDao.observeCustomPresets().map { list ->
        list.map { entity ->
            EqPreset(
                id = entity.id,
                name = entity.name,
                bandLevelsDb = entity.bandLevelsCsv.split(",")
                    .mapNotNull { it.toFloatOrNull() }
                    .takeIf { it.size == 10 } ?: List(10) { 0f },
                isCustom = true
            )
        }
    }

    val statsSummaryFlow: Flow<ListeningStatSummary> = combine(
        statsDao.observeAllSessions(),
        songsFlow
    ) { sessions, songs ->
        val totalPlayed = songs.sumOf { it.playCount }
        val totalMs = sessions.sumOf { it.durationListenedMs }

        val cal = Calendar.getInstance()
        val dayFmt = SimpleDateFormat("EEE", Locale.US)
        val dateKeyFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

        // Daily: last 7 days
        val dailyBuckets = linkedMapOf<String, Pair<String, Float>>()
        for (i in 6 downTo 0) {
            val c = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -i) }
            val key = dateKeyFmt.format(c.time)
            val label = dayFmt.format(c.time)
            dailyBuckets[key] = label to 0f
        }
        sessions.forEach { session ->
            val key = dateKeyFmt.format(Date(session.timestampMs))
            dailyBuckets[key]?.let { (label, cur) ->
                dailyBuckets[key] = label to (cur + session.durationListenedMs / 60_000f)
            }
        }

        // Weekly: last 4 weeks
        val nowMs = System.currentTimeMillis()
        val weekMs = 7L * 24 * 60 * 60 * 1000
        val weekly = (3 downTo 0).map { w ->
            val start = nowMs - (w + 1) * weekMs
            val end = nowMs - w * weekMs
            val mins = sessions.filter { it.timestampMs in start..end }
                .sumOf { it.durationListenedMs } / 60_000f
            val label = if (w == 0) "This Wk" else "-${w}w"
            label to mins
        }

        // Monthly: last 6 months
        val monthKeyFmt = SimpleDateFormat("yyyy-MM", Locale.US)
        val monthLabelFmt = SimpleDateFormat("MMM", Locale.US)
        val monthlyBuckets = linkedMapOf<String, Pair<String, Float>>()
        for (m in 5 downTo 0) {
            val c = (cal.clone() as Calendar).apply { add(Calendar.MONTH, -m) }
            val key = monthKeyFmt.format(c.time)
            val label = monthLabelFmt.format(c.time)
            monthlyBuckets[key] = label to 0f
        }
        sessions.forEach { session ->
            val key = monthKeyFmt.format(Date(session.timestampMs))
            monthlyBuckets[key]?.let { (label, cur) ->
                monthlyBuckets[key] = label to (cur + session.durationListenedMs / 60_000f)
            }
        }

        val topSongs = songs.filter { it.playCount > 0 }
            .sortedByDescending { it.playCount }
            .take(10)

        val topArtists = songs.groupBy { it.artist }
            .mapValues { (_, artistSongs) -> artistSongs.sumOf { it.playCount } }
            .filterValues { it > 0 }
            .entries
            .sortedByDescending { it.value }
            .take(8)
            .map { it.key to it.value }

        ListeningStatSummary(
            totalSongsPlayed = totalPlayed,
            totalListeningMs = totalMs,
            dailyMinutes = dailyBuckets.values.toList(),
            weeklyMinutes = weekly,
            monthlyMinutes = monthlyBuckets.values.toList(),
            topSongs = topSongs,
            topArtists = topArtists
        )
    }

    suspend fun refreshLibrary(): List<Song> {
        val excluded = excludedFolderDao.getExcludedPathsOnce().toSet()
        val existingMap = songDao.getAllSongsOnce().associateBy { it.id }
        val scanned = scanner.scanDeviceAudio(excluded, existingMap)
        if (scanned.isNotEmpty()) {
            songDao.upsertSongs(scanned)
            songDao.deleteMissingSongs(scanned.map { it.id })
        }
        return songDao.observeActiveSongs().first().map { it.toDomain() }
    }

    suspend fun generateTestTracksAndRefresh(): Int {
        val count = scanner.generateLocalTestWavTracks()
        refreshLibrary()
        return count
    }

    suspend fun toggleFavorite(songId: Long, current: Boolean) {
        songDao.setFavorite(songId, !current)
    }

    suspend fun recordSongPlay(song: Song) {
        songDao.recordPlay(song.id, System.currentTimeMillis())
    }

    suspend fun recordListeningSession(song: Song, listenedMs: Long) {
        if (listenedMs >= 1000L) {
            statsDao.insertSession(
                ListeningSessionEntity(
                    songId = song.id,
                    artist = song.artist,
                    durationListenedMs = listenedMs
                )
            )
        }
    }

    suspend fun clearListeningHistory() {
        statsDao.clearHistory()
    }

    suspend fun updateSongMetadata(
        songId: Long,
        title: String,
        artist: String,
        album: String,
        customArtworkUri: String?
    ) {
        songDao.updateMetadata(songId, title.trim(), artist.trim(), album.trim(), customArtworkUri)
    }

    suspend fun softDeleteSong(songId: Long) {
        songDao.softDeleteSong(songId, System.currentTimeMillis())
    }

    suspend fun restoreSong(songId: Long) {
        songDao.restoreSong(songId)
    }

    suspend fun excludeFolder(folderPath: String, folderName: String) {
        excludedFolderDao.excludeFolder(ExcludedFolderEntity(folderPath, folderName))
        refreshLibrary()
    }

    suspend fun includeFolder(folderPath: String) {
        excludedFolderDao.includeFolder(folderPath)
        refreshLibrary()
    }

    fun detectDuplicates(songs: List<Song>): List<DuplicateGroup> {
        val byTrackKey = songs.groupBy {
            "${it.title.lowercase().trim()}|${it.artist.lowercase().trim()}"
        }.filterValues { it.size > 1 }
        return byTrackKey.entries.map { (key, list) ->
            DuplicateGroup(key = key, songs = list)
        }
    }

    fun buildAlbums(songs: List<Song>): List<AlbumGroup> =
        songs.groupBy { it.albumId to it.album }
            .map { (key, list) ->
                AlbumGroup(
                    albumId = key.first,
                    name = key.second,
                    artist = list.firstOrNull()?.artist ?: "Unknown Artist",
                    songs = list
                )
            }.sortedBy { it.name.lowercase() }

    fun buildArtists(songs: List<Song>): List<ArtistGroup> =
        songs.groupBy { it.artist }
            .map { (artist, list) ->
                ArtistGroup(
                    name = artist,
                    songs = list,
                    albumCount = list.map { it.album }.distinct().size
                )
            }.sortedBy { it.name.lowercase() }

    fun buildFolders(songs: List<Song>): List<FolderGroup> =
        songs.groupBy { it.folderPath }
            .map { (path, list) ->
                FolderGroup(
                    folderName = list.firstOrNull()?.folderName ?: "Music",
                    folderPath = path,
                    songs = list
                )
            }.sortedBy { it.folderName.lowercase() }

    fun buildGenres(songs: List<Song>): List<GenreGroup> =
        songs.groupBy { it.genre }
            .map { (genre, list) -> GenreGroup(name = genre, songs = list) }
            .sortedBy { it.name.lowercase() }

    // Playlists
    suspend fun createPlaylist(name: String, initialSongIds: List<Long> = emptyList()): Long {
        val id = playlistDao.insertPlaylist(PlaylistEntity(name = name.trim()))
        initialSongIds.forEachIndexed { idx, songId ->
            playlistDao.insertPlaylistSong(PlaylistSongCrossRef(id, songId, idx))
        }
        return id
    }

    suspend fun renamePlaylist(playlistId: Long, newName: String) {
        playlistDao.renamePlaylist(playlistId, newName.trim())
    }

    suspend fun updatePlaylistArtwork(playlistId: Long, uri: String?) {
        playlistDao.updatePlaylistArtwork(playlistId, uri)
    }

    suspend fun deletePlaylist(playlistId: Long) {
        playlistDao.clearPlaylistSongs(playlistId)
        playlistDao.deletePlaylist(playlistId)
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long) {
        val current = playlistDao.getPlaylistSongsOnce(playlistId)
        if (current.any { it.songId == songId }) return
        val nextOrder = (current.maxOfOrNull { it.sortOrder } ?: -1) + 1
        playlistDao.insertPlaylistSong(PlaylistSongCrossRef(playlistId, songId, nextOrder))
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        playlistDao.removeSongFromPlaylist(playlistId, songId)
    }

    suspend fun reorderPlaylistSongs(playlistId: Long, orderedSongIds: List<Long>) {
        playlistDao.clearPlaylistSongs(playlistId)
        val refs = orderedSongIds.mapIndexed { index, songId ->
            PlaylistSongCrossRef(playlistId, songId, index)
        }
        playlistDao.insertPlaylistSongs(refs)
    }

    suspend fun exportPlaylistM3u(playlist: Playlist, targetUri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val content = buildString {
                appendLine("#EXTM3U")
                appendLine("#PLAYLIST:${playlist.name}")
                playlist.songs.forEach { song ->
                    appendLine("#EXTINF:${song.durationMs / 1000},${song.artist} - ${song.title}")
                    appendLine(song.filePath.ifBlank { song.contentUri })
                }
            }
            context.contentResolver.openOutputStream(targetUri)?.use { out ->
                out.write(content.toByteArray(Charsets.UTF_8))
            }
            true
        }.getOrDefault(false)
    }

    suspend fun exportPlaylistJson(playlist: Playlist, targetUri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val payload = ExportedPlaylistJson(
                name = playlist.name,
                songs = playlist.songs.map { ExportedSongRef(it.title, it.artist, it.filePath) }
            )
            val json = Json { prettyPrint = true }.encodeToString(payload)
            context.contentResolver.openOutputStream(targetUri)?.use { out ->
                out.write(json.toByteArray(Charsets.UTF_8))
            }
            true
        }.getOrDefault(false)
    }

    suspend fun importPlaylistFromUri(uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.use { stream ->
                BufferedReader(InputStreamReader(stream)).readText()
            } ?: return@withContext null

            val allSongs = songDao.observeActiveSongs().first().map { it.toDomain() }
            if (raw.trimStart().startsWith("{")) {
                val parsed = Json.decodeFromString<ExportedPlaylistJson>(raw)
                val matchedIds = parsed.songs.mapNotNull { ref ->
                    allSongs.firstOrNull {
                        it.filePath == ref.filePath ||
                            (it.title.equals(ref.title, true) && it.artist.equals(ref.artist, true))
                    }?.id
                }
                createPlaylist(parsed.name.ifBlank { "Imported Playlist" }, matchedIds)
                parsed.name
            } else {
                var playlistName = "Imported M3U"
                val matchedIds = mutableListOf<Long>()
                raw.lines().forEach { line ->
                    val trimmed = line.trim()
                    if (trimmed.startsWith("#PLAYLIST:")) {
                        playlistName = trimmed.removePrefix("#PLAYLIST:").trim().ifBlank { playlistName }
                    } else if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                        val match = allSongs.firstOrNull {
                            it.filePath == trimmed || it.filePath.endsWith("/$trimmed") || it.contentUri == trimmed
                        }
                        if (match != null) matchedIds.add(match.id)
                    }
                }
                createPlaylist(playlistName, matchedIds.distinct())
                playlistName
            }
        }.getOrNull()
    }

    // EQ Presets
    suspend fun saveCustomEqPreset(name: String, bandsDb: List<Float>) {
        val id = "custom_${System.currentTimeMillis()}"
        eqPresetDao.savePreset(
            EqPresetEntity(
                id = id,
                name = name.trim(),
                bandLevelsCsv = bandsDb.joinToString(",")
            )
        )
    }

    suspend fun deleteCustomEqPreset(presetId: String) {
        eqPresetDao.deletePreset(presetId)
    }

    // Lyrics
    suspend fun loadLyricsForSong(song: Song): LyricsData {
        val dbLyrics = lyricsDao.getLyricsOnce(song.id)
        if (dbLyrics != null && dbLyrics.rawText.isNotBlank()) {
            return LyricsParser.parse(song.id, dbLyrics.rawText, dbLyrics.sourceLabel)
        }
        return readLyricsFromFileOrTags(song)
    }

    suspend fun rescanLyricsFromSource(song: Song): LyricsData {
        val fresh = readLyricsFromFileOrTags(song)
        if (fresh.lines.isNotEmpty()) {
            lyricsDao.deleteLyrics(song.id)
            return fresh
        }
        return loadLyricsForSong(song)
    }

    private suspend fun readLyricsFromFileOrTags(song: Song): LyricsData {
        val sidecar = scanner.readSidecarLyrics(song)
        if (!sidecar.isNullOrBlank()) {
            return LyricsParser.parse(song.id, sidecar, "Local .lrc file")
        }
        val embedded = scanner.readEmbeddedLyricsTag(song)
        if (embedded != null && embedded.rawText.isNotBlank()) {
            return LyricsParser.parse(song.id, embedded.rawText, embedded.sourceLabel)
        }
        return LyricsData(
            songId = song.id,
            rawText = "",
            lines = emptyList(),
            isSynchronized = false,
            sourceLabel = "None"
        )
    }

    suspend fun saveLyrics(songId: Long, rawText: String, sourceLabel: String = "Edited locally") {
        lyricsDao.saveLyrics(
            LyricsEntity(
                songId = songId,
                rawText = rawText,
                sourceLabel = sourceLabel
            )
        )
    }

    suspend fun importLrcFromUri(songId: Long, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val text = context.contentResolver.openInputStream(uri)?.use {
                BufferedReader(InputStreamReader(it)).readText()
            } ?: return@withContext false
            saveLyrics(songId, text, "Imported LRC")
            true
        }.getOrDefault(false)
    }

    private fun SongEntity.toDomain() = Song(
        id = id,
        title = title,
        artist = artist,
        album = album,
        albumId = albumId,
        durationMs = durationMs,
        contentUri = contentUri,
        filePath = filePath,
        folderName = folderName,
        folderPath = folderPath,
        genre = genre,
        dateAddedSec = dateAddedSec,
        sizeBytes = sizeBytes,
        mimeType = mimeType,
        bitrateKbps = bitrateKbps,
        sampleRateHz = sampleRateHz,
        customArtworkUri = customArtworkUri,
        isFavorite = isFavorite,
        playCount = playCount,
        lastPlayedAt = lastPlayedAt,
        isDeleted = isDeleted,
        deletedAt = deletedAt
    )
}
