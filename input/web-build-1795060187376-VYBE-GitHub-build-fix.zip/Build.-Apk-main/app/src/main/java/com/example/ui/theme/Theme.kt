package com.example.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.AccentPreset
import com.example.model.AppearanceMode
import com.example.model.VybeThemeMode

@Immutable
data class VybeVisualStyle(
    val themeMode: VybeThemeMode,
    val appearanceMode: AppearanceMode,
    val isRetro: Boolean,
    val isLight: Boolean,
    val isGlassAddon: Boolean,
    val accentPrimary: Color,
    val accentSecondary: Color,
    val bgDeep: Color,
    val surfaceCard: Color,
    val surfaceElevated: Color,
    val cardBorder: Color,
    val textPrimary: Color,
    val textMuted: Color,
    val cardRadius: Dp,
    val heroGradient: Brush,
    val accentGradient: Brush,
    val meshTopColor: Color,
    val meshMidColor: Color,
    val glowColor: Color
)

val LocalVybeStyle = staticCompositionLocalOf {
    VybeVisualStyle(
        themeMode = VybeThemeMode.MODERN,
        appearanceMode = AppearanceMode.DARK,
        isRetro = false,
        isLight = false,
        isGlassAddon = false,
        accentPrimary = ModernViolet,
        accentSecondary = ModernElectricBlue,
        bgDeep = ModernObsidian,
        surfaceCard = ModernSurface,
        surfaceElevated = ModernSurfaceElevated,
        cardBorder = ModernViolet.copy(alpha = 0.25f),
        textPrimary = ModernTextPrimary,
        textMuted = ModernTextSecondary,
        cardRadius = 20.dp,
        heroGradient = Brush.linearGradient(listOf(ModernDeepPurple, ModernObsidian)),
        accentGradient = Brush.horizontalGradient(listOf(ModernViolet, ModernElectricBlue)),
        meshTopColor = ModernDeepPurple,
        meshMidColor = ModernViolet,
        glowColor = ModernElectricBlue.copy(alpha = 0.35f)
    )
}

@Composable
fun VybeTheme(
    themeMode: VybeThemeMode,
    appearanceMode: AppearanceMode,
    accentPreset: AccentPreset,
    content: @Composable () -> Unit
) {
    val isRetro = themeMode == VybeThemeMode.RETRO
    val isLight = appearanceMode == AppearanceMode.LIGHT
    val isGlassAddon = themeMode == VybeThemeMode.AURORA_GLASS ||
        themeMode == VybeThemeMode.LIQUID_SMOKE ||
        themeMode == VybeThemeMode.HALO_ORCHID

    val rawPrimary = when (themeMode) {
        VybeThemeMode.RETRO -> RetroAmber
        VybeThemeMode.AURORA_GLASS -> if (accentPreset == AccentPreset.ELECTRIC_VIOLET) Color(0xFFA78BFA) else accentPreset.primaryColor
        VybeThemeMode.LIQUID_SMOKE -> if (accentPreset == AccentPreset.ELECTRIC_VIOLET) Color(0xFFC4B5FD) else accentPreset.primaryColor
        VybeThemeMode.HALO_ORCHID -> if (accentPreset == AccentPreset.ELECTRIC_VIOLET) Color(0xFFD946EF) else accentPreset.primaryColor
        VybeThemeMode.MODERN -> accentPreset.primaryColor
    }
    val rawSecondary = when (themeMode) {
        VybeThemeMode.RETRO -> RetroCopper
        VybeThemeMode.AURORA_GLASS -> if (accentPreset == AccentPreset.ELECTRIC_VIOLET) Color(0xFF7DD3FC) else accentPreset.secondaryColor
        VybeThemeMode.LIQUID_SMOKE -> if (accentPreset == AccentPreset.ELECTRIC_VIOLET) Color(0xFFE2E8F0) else accentPreset.secondaryColor
        VybeThemeMode.HALO_ORCHID -> if (accentPreset == AccentPreset.ELECTRIC_VIOLET) Color(0xFF818CF8) else accentPreset.secondaryColor
        VybeThemeMode.MODERN -> accentPreset.secondaryColor
    }

    val rawBg = when {
        isLight && isRetro -> RetroLightBg
        isLight -> ModernLightBg
        appearanceMode == AppearanceMode.OLED_BLACK && isRetro -> RetroPureDark
        appearanceMode == AppearanceMode.OLED_BLACK -> ModernPureBlack
        themeMode == VybeThemeMode.RETRO -> RetroCharcoal
        themeMode == VybeThemeMode.AURORA_GLASS -> AuroraBg
        themeMode == VybeThemeMode.LIQUID_SMOKE -> LiquidBg
        themeMode == VybeThemeMode.HALO_ORCHID -> OrchidBg
        else -> ModernObsidian
    }

    val rawSurface = when {
        isLight && isRetro -> RetroLightSurface
        isLight -> ModernLightSurface
        themeMode == VybeThemeMode.RETRO -> RetroWalnut
        themeMode == VybeThemeMode.AURORA_GLASS -> AuroraSurface.copy(alpha = 0.72f)
        themeMode == VybeThemeMode.LIQUID_SMOKE -> LiquidSurface.copy(alpha = 0.78f)
        themeMode == VybeThemeMode.HALO_ORCHID -> OrchidSurface.copy(alpha = 0.76f)
        else -> ModernSurface
    }

    val rawElevated = when {
        isLight && isRetro -> RetroLightElevated
        isLight -> ModernLightElevated
        themeMode == VybeThemeMode.RETRO -> RetroBrushed
        themeMode == VybeThemeMode.AURORA_GLASS -> AuroraElevated.copy(alpha = 0.80f)
        themeMode == VybeThemeMode.LIQUID_SMOKE -> LiquidElevated.copy(alpha = 0.84f)
        themeMode == VybeThemeMode.HALO_ORCHID -> OrchidElevated.copy(alpha = 0.82f)
        else -> ModernSurfaceElevated
    }

    val rawText = when {
        isLight && isRetro -> RetroLightText
        isLight -> ModernLightText
        isRetro -> RetroCream
        else -> ModernTextPrimary
    }

    val rawMuted = when {
        isLight && isRetro -> RetroLightMuted
        isLight -> ModernLightMuted
        themeMode == VybeThemeMode.RETRO -> RetroMuted
        themeMode == VybeThemeMode.AURORA_GLASS -> AuroraTextMuted
        themeMode == VybeThemeMode.LIQUID_SMOKE -> LiquidTextMuted
        themeMode == VybeThemeMode.HALO_ORCHID -> OrchidTextMuted
        else -> ModernTextSecondary
    }

    val rawMeshTop = when (themeMode) {
        VybeThemeMode.RETRO -> if (isLight) Color(0xFFE7D3B3) else Color(0xFF3B2415)
        VybeThemeMode.AURORA_GLASS -> if (isLight) Color(0xFFC4B5FD) else AuroraOrbTop
        VybeThemeMode.LIQUID_SMOKE -> if (isLight) Color(0xFFCBD5E1) else LiquidMistTop
        VybeThemeMode.HALO_ORCHID -> if (isLight) Color(0xFFF0ABFC) else OrchidPlumTop
        VybeThemeMode.MODERN -> if (isLight) Color(0xFFDDD6FE) else ModernDeepPurple
    }

    val rawMeshMid = when (themeMode) {
        VybeThemeMode.RETRO -> RetroCopper
        VybeThemeMode.AURORA_GLASS -> AuroraOrbMid
        VybeThemeMode.LIQUID_SMOKE -> Color(0xFF2B2D42)
        VybeThemeMode.HALO_ORCHID -> Color(0xFF3E2470)
        VybeThemeMode.MODERN -> accentPreset.primaryColor
    }

    val animSpec = tween<Color>(durationMillis = 360)
    val accentPrimary by animateColorAsState(rawPrimary, animSpec, label = "accentPrimary")
    val accentSecondary by animateColorAsState(rawSecondary, animSpec, label = "accentSecondary")
    val bgDeep by animateColorAsState(rawBg, animSpec, label = "bgDeep")
    val surfaceCard by animateColorAsState(rawSurface, animSpec, label = "surfaceCard")
    val surfaceElevated by animateColorAsState(rawElevated, animSpec, label = "surfaceElevated")
    val textPrimary by animateColorAsState(rawText, animSpec, label = "textPrimary")
    val textMuted by animateColorAsState(rawMuted, animSpec, label = "textMuted")
    val meshTopColor by animateColorAsState(rawMeshTop, animSpec, label = "meshTop")
    val meshMidColor by animateColorAsState(rawMeshMid, animSpec, label = "meshMid")

    val border = when {
        isRetro -> accentPrimary.copy(alpha = 0.32f)
        isGlassAddon -> Color.White.copy(alpha = if (isLight) 0.35f else 0.18f)
        else -> accentPrimary.copy(alpha = 0.24f)
    }

    val heroGradient = when (themeMode) {
        VybeThemeMode.RETRO -> Brush.linearGradient(listOf(meshTopColor, bgDeep))
        VybeThemeMode.AURORA_GLASS -> Brush.verticalGradient(
            listOf(meshTopColor.copy(alpha = 0.85f), meshMidColor.copy(alpha = 0.55f), bgDeep)
        )
        VybeThemeMode.LIQUID_SMOKE -> Brush.verticalGradient(
            listOf(meshTopColor.copy(alpha = 0.78f), bgDeep)
        )
        VybeThemeMode.HALO_ORCHID -> Brush.verticalGradient(
            listOf(meshTopColor.copy(alpha = 0.88f), Color(0xFF201336), bgDeep)
        )
        VybeThemeMode.MODERN -> Brush.linearGradient(
            listOf(meshTopColor.copy(alpha = 0.85f), bgDeep)
        )
    }

    val accentGradient = Brush.horizontalGradient(listOf(accentPrimary, accentSecondary))

    val vybeStyle = VybeVisualStyle(
        themeMode = themeMode,
        appearanceMode = appearanceMode,
        isRetro = isRetro,
        isLight = isLight,
        isGlassAddon = isGlassAddon,
        accentPrimary = accentPrimary,
        accentSecondary = accentSecondary,
        bgDeep = bgDeep,
        surfaceCard = surfaceCard,
        surfaceElevated = surfaceElevated,
        cardBorder = border,
        textPrimary = textPrimary,
        textMuted = textMuted,
        cardRadius = when {
            isRetro -> 12.dp
            isGlassAddon -> 22.dp
            else -> 20.dp
        },
        heroGradient = heroGradient,
        accentGradient = accentGradient,
        meshTopColor = meshTopColor,
        meshMidColor = meshMidColor,
        glowColor = accentSecondary.copy(alpha = if (isLight) 0.2f else 0.35f)
    )

    val m3ColorScheme = if (isLight) {
        lightColorScheme(
            primary = accentPrimary,
            onPrimary = Color.White,
            secondary = accentSecondary,
            onSecondary = Color.White,
            tertiary = if (isRetro) RetroSage else ModernDeepPurple,
            background = bgDeep,
            onBackground = textPrimary,
            surface = surfaceCard,
            onSurface = textPrimary,
            surfaceVariant = surfaceElevated,
            onSurfaceVariant = textMuted,
            outline = border
        )
    } else {
        darkColorScheme(
            primary = accentPrimary,
            onPrimary = if (isRetro) Color(0xFF1F140A) else Color.White,
            secondary = accentSecondary,
            onSecondary = Color(0xFF061523),
            tertiary = if (isRetro) RetroSage else ModernViolet,
            background = bgDeep,
            onBackground = textPrimary,
            surface = surfaceCard,
            onSurface = textPrimary,
            surfaceVariant = surfaceElevated,
            onSurfaceVariant = textMuted,
            outline = border
        )
    }

    val shapes = Shapes(
        small = RoundedCornerShape(if (isRetro) 6.dp else 12.dp),
        medium = RoundedCornerShape(if (isRetro) 10.dp else 18.dp),
        large = RoundedCornerShape(if (isRetro) 14.dp else 24.dp)
    )

    CompositionLocalProvider(LocalVybeStyle provides vybeStyle) {
        MaterialTheme(
            colorScheme = m3ColorScheme,
            typography = if (isRetro) RetroTypography else ModernTypography,
            shapes = shapes,
            content = content
        )
    }
}
