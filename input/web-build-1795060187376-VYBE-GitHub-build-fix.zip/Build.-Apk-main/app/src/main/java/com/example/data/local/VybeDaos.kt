package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SongDao {
    @Query("SELECT * FROM songs WHERE isDeleted = 0 ORDER BY title COLLATE NOCASE ASC")
    fun observeActiveSongs(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE isDeleted = 1 ORDER BY deletedAt DESC")
    fun observeDeletedSongs(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs")
    suspend fun getAllSongsOnce(): List<SongEntity>

    @Query("SELECT * FROM songs WHERE id = :songId LIMIT 1")
    suspend fun getSongById(songId: Long): SongEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSongs(songs: List<SongEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSong(song: SongEntity)

    @Query("UPDATE songs SET isFavorite = :favorite WHERE id = :songId")
    suspend fun setFavorite(songId: Long, favorite: Boolean)

    @Query("UPDATE songs SET playCount = playCount + 1, lastPlayedAt = :playedAt WHERE id = :songId")
    suspend fun recordPlay(songId: Long, playedAt: Long)

    @Query("UPDATE songs SET title = :title, artist = :artist, album = :album, customArtworkUri = :customArtworkUri, hasUserEditedMetadata = 1 WHERE id = :songId")
    suspend fun updateMetadata(songId: Long, title: String, artist: String, album: String, customArtworkUri: String?)

    @Query("UPDATE songs SET isDeleted = 1, deletedAt = :deletedAt WHERE id = :songId")
    suspend fun softDeleteSong(songId: Long, deletedAt: Long)

    @Query("UPDATE songs SET isDeleted = 0, deletedAt = 0 WHERE id = :songId")
    suspend fun restoreSong(songId: Long)

    @Query("DELETE FROM songs WHERE id = :songId")
    suspend fun purgeSong(songId: Long)

    @Query("DELETE FROM songs WHERE id NOT IN (:validIds) AND isDeleted = 0 AND hasUserEditedMetadata = 0")
    suspend fun deleteMissingSongs(validIds: List<Long>)
}

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlist_songs ORDER BY playlistId, sortOrder ASC")
    fun observeAllPlaylistSongs(): Flow<List<PlaylistSongCrossRef>>

    @Query("SELECT * FROM playlist_songs WHERE playlistId = :playlistId ORDER BY sortOrder ASC")
    suspend fun getPlaylistSongsOnce(playlistId: Long): List<PlaylistSongCrossRef>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Update
    suspend fun updatePlaylist(playlist: PlaylistEntity)

    @Query("UPDATE playlists SET name = :name WHERE id = :playlistId")
    suspend fun renamePlaylist(playlistId: Long, name: String)

    @Query("UPDATE playlists SET customArtworkUri = :artworkUri WHERE id = :playlistId")
    suspend fun updatePlaylistArtwork(playlistId: Long, artworkUri: String?)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun clearPlaylistSongs(playlistId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistSong(crossRef: PlaylistSongCrossRef)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistSongs(crossRefs: List<PlaylistSongCrossRef>)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long)
}

@Dao
interface EqPresetDao {
    @Query("SELECT * FROM eq_presets ORDER BY createdAt DESC")
    fun observeCustomPresets(): Flow<List<EqPresetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePreset(preset: EqPresetEntity)

    @Query("DELETE FROM eq_presets WHERE id = :presetId")
    suspend fun deletePreset(presetId: String)
}

@Dao
interface LyricsDao {
    @Query("SELECT * FROM lyrics WHERE songId = :songId LIMIT 1")
    fun observeLyrics(songId: Long): Flow<LyricsEntity?>

    @Query("SELECT * FROM lyrics WHERE songId = :songId LIMIT 1")
    suspend fun getLyricsOnce(songId: Long): LyricsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLyrics(lyrics: LyricsEntity)

    @Query("DELETE FROM lyrics WHERE songId = :songId")
    suspend fun deleteLyrics(songId: Long)
}

@Dao
interface StatsDao {
    @Query("SELECT * FROM listening_sessions ORDER BY timestampMs DESC")
    fun observeAllSessions(): Flow<List<ListeningSessionEntity>>

    @Insert
    suspend fun insertSession(session: ListeningSessionEntity)

    @Query("DELETE FROM listening_sessions")
    suspend fun clearHistory()
}

@Dao
interface ExcludedFolderDao {
    @Query("SELECT * FROM excluded_folders ORDER BY folderName ASC")
    fun observeExcludedFolders(): Flow<List<ExcludedFolderEntity>>

    @Query("SELECT folderPath FROM excluded_folders")
    suspend fun getExcludedPathsOnce(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun excludeFolder(folder: ExcludedFolderEntity)

    @Query("DELETE FROM excluded_folders WHERE folderPath = :folderPath")
    suspend fun includeFolder(folderPath: String)
}
