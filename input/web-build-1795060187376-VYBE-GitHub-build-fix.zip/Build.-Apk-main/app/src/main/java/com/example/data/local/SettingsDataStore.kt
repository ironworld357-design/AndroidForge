package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AccentPreset
import com.example.model.AppearanceMode
import com.example.model.ArtworkStyle
import com.example.model.CrossfadeCurve
import com.example.model.HeadphoneProfile
import com.example.model.NavDockStyle
import com.example.model.PerformanceMode
import com.example.model.PlayerBackgroundStyle
import com.example.model.PlayerLayoutStyle
import com.example.model.RepeatMode
import com.example.model.SongSortOrder
import com.example.model.VisualizerSize
import com.example.model.VisualizerStyle
import com.example.model.VybeThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.vybeDataStore: DataStore<Preferences> by preferencesDataStore(name = "vybe_preferences")

data class VybeSettings(
    val themeMode: VybeThemeMode = VybeThemeMode.MODERN,
    val appearanceMode: AppearanceMode = AppearanceMode.DARK,
    val accentPreset: AccentPreset = AccentPreset.ELECTRIC_VIOLET,
    val artworkStyle: ArtworkStyle = ArtworkStyle.ROUNDED_CARD,
    val playerBackgroundStyle: PlayerBackgroundStyle = PlayerBackgroundStyle.DYNAMIC_GRADIENT,
    val animationsEnabled: Boolean = true,
    val performanceMode: PerformanceMode = PerformanceMode.AUTO,
    val visualizerEnabled: Boolean = true,
    val visualizerStyle: VisualizerStyle = VisualizerStyle.SPECTRUM_ANALYZER,
    val visualizerIntensity: Float = 1.0f,
    val visualizerSize: VisualizerSize = VisualizerSize.MEDIUM,
    val visualizerCustomColorHex: Long? = null,
    val eqEnabled: Boolean = true,
    val eqPresetId: String = "normal",
    val eqBandsDb: List<Float> = List(10) { 0f },
    val bassBoostStrength: Int = 0,
    val virtualizerStrength: Int = 0,
    val loudnessGainMb: Int = 0,
    val preampDb: Float = 0f,
    val channelBalance: Float = 0f, // -1.0 Left to +1.0 Right
    val volumeNormalization: Boolean = false,
    val headphoneProfile: HeadphoneProfile = HeadphoneProfile.NEUTRAL,
    val gaplessPlayback: Boolean = true,
    val crossfadeDurationMs: Int = 0,
    val crossfadeCurve: CrossfadeCurve = CrossfadeCurve.EQUAL_POWER,
    val crossfadeOnManualSkip: Boolean = false,
    val hapticFeedbackEnabled: Boolean = true,
    val fadeInOutEnabled: Boolean = true,
    val autoPauseOnDisconnect: Boolean = true,
    val playbackSpeed: Float = 1.0f,
    val shuffleEnabled: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val sortOrder: SongSortOrder = SongSortOrder.TITLE,
    val sortAscending: Boolean = true,
    val lastSongId: Long = -1L,
    val lastPositionMs: Long = 0L,
    val lastQueueIds: List<Long> = emptyList(),
    val showNotifications: Boolean = true,
    val skipSilenceEnabled: Boolean = false,
    val playerLayoutStyle: PlayerLayoutStyle = PlayerLayoutStyle.CLASSIC,
    val navDockStyle: NavDockStyle = NavDockStyle.STANDARD_BAR
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val APPEARANCE_MODE = stringPreferencesKey("appearance_mode")
        val ACCENT_PRESET = stringPreferencesKey("accent_preset")
        val ARTWORK_STYLE = stringPreferencesKey("artwork_style")
        val PLAYER_BG_STYLE = stringPreferencesKey("player_bg_style")
        val ANIMATIONS_ENABLED = booleanPreferencesKey("animations_enabled")
        val PERFORMANCE_MODE = stringPreferencesKey("performance_mode")
        val VISUALIZER_ENABLED = booleanPreferencesKey("visualizer_enabled")
        val VISUALIZER_STYLE = stringPreferencesKey("visualizer_style")
        val VISUALIZER_INTENSITY = floatPreferencesKey("visualizer_intensity")
        val VISUALIZER_SIZE = stringPreferencesKey("visualizer_size")
        val VISUALIZER_COLOR = longPreferencesKey("visualizer_color")
        val EQ_ENABLED = booleanPreferencesKey("eq_enabled")
        val EQ_PRESET_ID = stringPreferencesKey("eq_preset_id")
        val EQ_BANDS_CSV = stringPreferencesKey("eq_bands_csv")
        val BASS_BOOST = intPreferencesKey("bass_boost")
        val VIRTUALIZER = intPreferencesKey("virtualizer")
        val LOUDNESS_GAIN = intPreferencesKey("loudness_gain")
        val PREAMP_DB = floatPreferencesKey("preamp_db")
        val CHANNEL_BALANCE = floatPreferencesKey("channel_balance")
        val VOLUME_NORMALIZATION = booleanPreferencesKey("volume_normalization")
        val HEADPHONE_PROFILE = stringPreferencesKey("headphone_profile")
        val GAPLESS_PLAYBACK = booleanPreferencesKey("gapless_playback")
        val CROSSFADE_MS = intPreferencesKey("crossfade_ms")
        val CROSSFADE_CURVE = stringPreferencesKey("crossfade_curve")
        val CROSSFADE_ON_MANUAL_SKIP = booleanPreferencesKey("crossfade_on_manual_skip")
        val HAPTIC_FEEDBACK = booleanPreferencesKey("haptic_feedback")
        val FADE_IN_OUT = booleanPreferencesKey("fade_in_out")
        val AUTO_PAUSE_DISCONNECT = booleanPreferencesKey("auto_pause_disconnect")
        val PLAYBACK_SPEED = floatPreferencesKey("playback_speed")
        val SHUFFLE_ENABLED = booleanPreferencesKey("shuffle_enabled")
        val REPEAT_MODE = stringPreferencesKey("repeat_mode")
        val SORT_ORDER = stringPreferencesKey("sort_order")
        val SORT_ASCENDING = booleanPreferencesKey("sort_ascending")
        val LAST_SONG_ID = longPreferencesKey("last_song_id")
        val LAST_POSITION_MS = longPreferencesKey("last_position_ms")
        val LAST_QUEUE_CSV = stringPreferencesKey("last_queue_csv")
        val SHOW_NOTIFICATIONS = booleanPreferencesKey("show_notifications")
        val SKIP_SILENCE = booleanPreferencesKey("skip_silence")
        val PLAYER_LAYOUT_STYLE = stringPreferencesKey("player_layout_style")
        val NAV_DOCK_STYLE = stringPreferencesKey("nav_dock_style")
    }

    val settingsFlow: Flow<VybeSettings> = context.vybeDataStore.data.map { prefs ->
        VybeSettings(
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { VybeThemeMode.valueOf(it) }.getOrNull() } ?: VybeThemeMode.MODERN,
            appearanceMode = prefs[Keys.APPEARANCE_MODE]?.let { runCatching { AppearanceMode.valueOf(it) }.getOrNull() } ?: AppearanceMode.DARK,
            accentPreset = prefs[Keys.ACCENT_PRESET]?.let { runCatching { AccentPreset.valueOf(it) }.getOrNull() } ?: AccentPreset.ELECTRIC_VIOLET,
            artworkStyle = prefs[Keys.ARTWORK_STYLE]?.let { runCatching { ArtworkStyle.valueOf(it) }.getOrNull() } ?: ArtworkStyle.ROUNDED_CARD,
            playerBackgroundStyle = prefs[Keys.PLAYER_BG_STYLE]?.let { runCatching { PlayerBackgroundStyle.valueOf(it) }.getOrNull() } ?: PlayerBackgroundStyle.DYNAMIC_GRADIENT,
            animationsEnabled = prefs[Keys.ANIMATIONS_ENABLED] ?: true,
            performanceMode = prefs[Keys.PERFORMANCE_MODE]?.let { runCatching { PerformanceMode.valueOf(it) }.getOrNull() } ?: PerformanceMode.AUTO,
            visualizerEnabled = prefs[Keys.VISUALIZER_ENABLED] ?: true,
            visualizerStyle = prefs[Keys.VISUALIZER_STYLE]?.let { runCatching { VisualizerStyle.valueOf(it) }.getOrNull() } ?: VisualizerStyle.SPECTRUM_ANALYZER,
            visualizerIntensity = prefs[Keys.VISUALIZER_INTENSITY] ?: 1.0f,
            visualizerSize = prefs[Keys.VISUALIZER_SIZE]?.let { runCatching { VisualizerSize.valueOf(it) }.getOrNull() } ?: VisualizerSize.MEDIUM,
            visualizerCustomColorHex = prefs[Keys.VISUALIZER_COLOR]?.takeIf { it != -1L },
            eqEnabled = prefs[Keys.EQ_ENABLED] ?: true,
            eqPresetId = prefs[Keys.EQ_PRESET_ID] ?: "normal",
            eqBandsDb = prefs[Keys.EQ_BANDS_CSV]?.split(",")?.mapNotNull { it.toFloatOrNull() }?.takeIf { it.size == 10 } ?: List(10) { 0f },
            bassBoostStrength = prefs[Keys.BASS_BOOST] ?: 0,
            virtualizerStrength = prefs[Keys.VIRTUALIZER] ?: 0,
            loudnessGainMb = prefs[Keys.LOUDNESS_GAIN] ?: 0,
            preampDb = prefs[Keys.PREAMP_DB] ?: 0f,
            channelBalance = prefs[Keys.CHANNEL_BALANCE] ?: 0f,
            volumeNormalization = prefs[Keys.VOLUME_NORMALIZATION] ?: false,
            headphoneProfile = prefs[Keys.HEADPHONE_PROFILE]?.let { runCatching { HeadphoneProfile.valueOf(it) }.getOrNull() } ?: HeadphoneProfile.NEUTRAL,
            gaplessPlayback = prefs[Keys.GAPLESS_PLAYBACK] ?: true,
            crossfadeDurationMs = prefs[Keys.CROSSFADE_MS] ?: 0,
            crossfadeCurve = prefs[Keys.CROSSFADE_CURVE]?.let { runCatching { CrossfadeCurve.valueOf(it) }.getOrNull() } ?: CrossfadeCurve.EQUAL_POWER,
            crossfadeOnManualSkip = prefs[Keys.CROSSFADE_ON_MANUAL_SKIP] ?: false,
            hapticFeedbackEnabled = prefs[Keys.HAPTIC_FEEDBACK] ?: true,
            fadeInOutEnabled = prefs[Keys.FADE_IN_OUT] ?: true,
            autoPauseOnDisconnect = prefs[Keys.AUTO_PAUSE_DISCONNECT] ?: true,
            playbackSpeed = prefs[Keys.PLAYBACK_SPEED] ?: 1.0f,
            shuffleEnabled = prefs[Keys.SHUFFLE_ENABLED] ?: false,
            repeatMode = prefs[Keys.REPEAT_MODE]?.let { runCatching { RepeatMode.valueOf(it) }.getOrNull() } ?: RepeatMode.OFF,
            sortOrder = prefs[Keys.SORT_ORDER]?.let { runCatching { SongSortOrder.valueOf(it) }.getOrNull() } ?: SongSortOrder.TITLE,
            sortAscending = prefs[Keys.SORT_ASCENDING] ?: true,
            lastSongId = prefs[Keys.LAST_SONG_ID] ?: -1L,
            lastPositionMs = prefs[Keys.LAST_POSITION_MS] ?: 0L,
            lastQueueIds = prefs[Keys.LAST_QUEUE_CSV]?.split(",")?.mapNotNull { it.toLongOrNull() } ?: emptyList(),
            showNotifications = prefs[Keys.SHOW_NOTIFICATIONS] ?: true,
            skipSilenceEnabled = prefs[Keys.SKIP_SILENCE] ?: false,
            playerLayoutStyle = prefs[Keys.PLAYER_LAYOUT_STYLE]?.let { runCatching { PlayerLayoutStyle.valueOf(it) }.getOrNull() } ?: PlayerLayoutStyle.CLASSIC,
            navDockStyle = prefs[Keys.NAV_DOCK_STYLE]?.let { runCatching { NavDockStyle.valueOf(it) }.getOrNull() } ?: NavDockStyle.STANDARD_BAR
        )
    }

    suspend fun setThemeMode(mode: VybeThemeMode) = context.vybeDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    suspend fun setAppearanceMode(mode: AppearanceMode) = context.vybeDataStore.edit { it[Keys.APPEARANCE_MODE] = mode.name }
    suspend fun setAccentPreset(preset: AccentPreset) = context.vybeDataStore.edit { it[Keys.ACCENT_PRESET] = preset.name }
    suspend fun setArtworkStyle(style: ArtworkStyle) = context.vybeDataStore.edit { it[Keys.ARTWORK_STYLE] = style.name }
    suspend fun setPlayerBackgroundStyle(style: PlayerBackgroundStyle) = context.vybeDataStore.edit { it[Keys.PLAYER_BG_STYLE] = style.name }
    suspend fun setAnimationsEnabled(enabled: Boolean) = context.vybeDataStore.edit { it[Keys.ANIMATIONS_ENABLED] = enabled }
    suspend fun setPerformanceMode(mode: PerformanceMode) = context.vybeDataStore.edit { it[Keys.PERFORMANCE_MODE] = mode.name }
    suspend fun setVisualizerEnabled(enabled: Boolean) = context.vybeDataStore.edit { it[Keys.VISUALIZER_ENABLED] = enabled }
    suspend fun setVisualizerStyle(style: VisualizerStyle) = context.vybeDataStore.edit { it[Keys.VISUALIZER_STYLE] = style.name }
    suspend fun setVisualizerIntensity(intensity: Float) = context.vybeDataStore.edit { it[Keys.VISUALIZER_INTENSITY] = intensity }
    suspend fun setVisualizerSize(size: VisualizerSize) = context.vybeDataStore.edit { it[Keys.VISUALIZER_SIZE] = size.name }
    suspend fun setVisualizerCustomColor(colorHex: Long?) = context.vybeDataStore.edit { it[Keys.VISUALIZER_COLOR] = colorHex ?: -1L }

    suspend fun setEqState(enabled: Boolean, presetId: String, bands: List<Float>) {
        context.vybeDataStore.edit {
            it[Keys.EQ_ENABLED] = enabled
            it[Keys.EQ_PRESET_ID] = presetId
            it[Keys.EQ_BANDS_CSV] = bands.joinToString(",")
        }
    }

    suspend fun setBassBoost(strength: Int) = context.vybeDataStore.edit { it[Keys.BASS_BOOST] = strength }
    suspend fun setVirtualizer(strength: Int) = context.vybeDataStore.edit { it[Keys.VIRTUALIZER] = strength }
    suspend fun setLoudnessGain(gainMb: Int) = context.vybeDataStore.edit { it[Keys.LOUDNESS_GAIN] = gainMb }
    suspend fun setPreampDb(db: Float) = context.vybeDataStore.edit { it[Keys.PREAMP_DB] = db }
    suspend fun setChannelBalance(balance: Float) = context.vybeDataStore.edit { it[Keys.CHANNEL_BALANCE] = balance }
    suspend fun setVolumeNormalization(enabled: Boolean) = context.vybeDataStore.edit { it[Keys.VOLUME_NORMALIZATION] = enabled }
    suspend fun setHeadphoneProfile(profile: HeadphoneProfile) = context.vybeDataStore.edit { it[Keys.HEADPHONE_PROFILE] = profile.name }
    suspend fun setGaplessPlayback(enabled: Boolean) = context.vybeDataStore.edit { it[Keys.GAPLESS_PLAYBACK] = enabled }
    suspend fun setCrossfadeDurationMs(ms: Int) = context.vybeDataStore.edit { it[Keys.CROSSFADE_MS] = ms }
    suspend fun setCrossfadeCurve(curve: CrossfadeCurve) = context.vybeDataStore.edit { it[Keys.CROSSFADE_CURVE] = curve.name }
    suspend fun setCrossfadeOnManualSkip(enabled: Boolean) = context.vybeDataStore.edit { it[Keys.CROSSFADE_ON_MANUAL_SKIP] = enabled }
    suspend fun setHapticFeedbackEnabled(enabled: Boolean) = context.vybeDataStore.edit { it[Keys.HAPTIC_FEEDBACK] = enabled }
    suspend fun setFadeInOutEnabled(enabled: Boolean) = context.vybeDataStore.edit { it[Keys.FADE_IN_OUT] = enabled }
    suspend fun setAutoPauseOnDisconnect(enabled: Boolean) = context.vybeDataStore.edit { it[Keys.AUTO_PAUSE_DISCONNECT] = enabled }
    suspend fun setPlaybackSpeed(speed: Float) = context.vybeDataStore.edit { it[Keys.PLAYBACK_SPEED] = speed }
    suspend fun setShuffleEnabled(enabled: Boolean) = context.vybeDataStore.edit { it[Keys.SHUFFLE_ENABLED] = enabled }
    suspend fun setRepeatMode(mode: RepeatMode) = context.vybeDataStore.edit { it[Keys.REPEAT_MODE] = mode.name }
    suspend fun setSort(order: SongSortOrder, ascending: Boolean) {
        context.vybeDataStore.edit {
            it[Keys.SORT_ORDER] = order.name
            it[Keys.SORT_ASCENDING] = ascending
        }
    }
    suspend fun setShowNotifications(show: Boolean) = context.vybeDataStore.edit { it[Keys.SHOW_NOTIFICATIONS] = show }
    suspend fun setSkipSilenceEnabled(enabled: Boolean) = context.vybeDataStore.edit { it[Keys.SKIP_SILENCE] = enabled }
    suspend fun setPlayerLayoutStyle(style: PlayerLayoutStyle) = context.vybeDataStore.edit { it[Keys.PLAYER_LAYOUT_STYLE] = style.name }
    suspend fun setNavDockStyle(style: NavDockStyle) = context.vybeDataStore.edit { it[Keys.NAV_DOCK_STYLE] = style.name }

    suspend fun savePlaybackResumption(songId: Long, positionMs: Long, queueIds: List<Long>) {
        context.vybeDataStore.edit {
            it[Keys.LAST_SONG_ID] = songId
            it[Keys.LAST_POSITION_MS] = positionMs
            it[Keys.LAST_QUEUE_CSV] = queueIds.joinToString(",")
        }
    }
}
