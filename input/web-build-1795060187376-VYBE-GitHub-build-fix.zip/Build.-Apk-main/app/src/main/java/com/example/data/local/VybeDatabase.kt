package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SongEntity::class,
        PlaylistEntity::class,
        PlaylistSongCrossRef::class,
        EqPresetEntity::class,
        LyricsEntity::class,
        ListeningSessionEntity::class,
        ExcludedFolderEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class VybeDatabase : RoomDatabase() {
    abstract fun songDao(): SongDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun eqPresetDao(): EqPresetDao
    abstract fun lyricsDao(): LyricsDao
    abstract fun statsDao(): StatsDao
    abstract fun excludedFolderDao(): ExcludedFolderDao

    companion object {
        @Volatile
        private var INSTANCE: VybeDatabase? = null

        fun getInstance(context: Context): VybeDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    VybeDatabase::class.java,
                    "vybe_music_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
