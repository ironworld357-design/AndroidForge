package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.Playlist
import com.example.model.Song
import com.example.ui.components.VybeArtwork
import com.example.ui.theme.LocalVybeStyle
import com.example.util.TimeFormatter

@Composable
fun PlaylistsScreen(
    smartPlaylists: List<Playlist>,
    customPlaylists: List<Playlist>,
    allSongs: List<Song>,
    selectedPlaylistId: Long?,
    onSelectPlaylist: (Long?) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onRenamePlaylist: (Long, String) -> Unit,
    onUpdatePlaylistArtwork: (Long, String?) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onAddSongToPlaylist: (Long, Long) -> Unit,
    onRemoveSongFromPlaylist: (Long, Long) -> Unit,
    onMovePlaylistSong: (Playlist, Int, Int) -> Unit,
    onPlaySongs: (List<Song>, Int) -> Unit,
    onExportM3u: (Playlist, Uri) -> Unit,
    onExportJson: (Playlist, Uri) -> Unit,
    onImportPlaylist: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val context = LocalContext.current

    var showCreateDialog by remember { mutableStateOf(false) }
    var renamingPlaylist by remember { mutableStateOf<Playlist?>(null) }
    var addSongsPlaylist by remember { mutableStateOf<Playlist?>(null) }

    val activePlaylist = remember(selectedPlaylistId, smartPlaylists, customPlaylists) {
        (smartPlaylists + customPlaylists).firstOrNull { it.id == selectedPlaylistId }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let(onImportPlaylist) }

    val exportM3uLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("audio/x-mpegurl")
    ) { uri ->
        if (uri != null && activePlaylist != null) onExportM3u(activePlaylist, uri)
    }

    val exportJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null && activePlaylist != null) onExportJson(activePlaylist, uri)
    }

    val artworkPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null && activePlaylist != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            onUpdatePlaylistArtwork(activePlaylist.id, uri.toString())
        }
    }

    if (activePlaylist != null) {
        BackHandler { onSelectPlaylist(null) }

        LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 140.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = { onSelectPlaylist(null) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = vybe.textPrimary)
                    }
                    Row {
                        if (!activePlaylist.isSmart) {
                            IconButton(onClick = {
                                artworkPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }) {
                                Icon(Icons.Filled.Image, contentDescription = "Change artwork", tint = vybe.textPrimary)
                            }
                            IconButton(onClick = { renamingPlaylist = activePlaylist }) {
                                Icon(Icons.Filled.Edit, contentDescription = "Rename", tint = vybe.textPrimary)
                            }
                            IconButton(onClick = {
                                onDeletePlaylist(activePlaylist.id)
                                onSelectPlaylist(null)
                            }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete playlist", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(vybe.cardRadius),
                    color = vybe.surfaceCard,
                    border = BorderStroke(1.dp, vybe.cardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        VybeArtwork(
                            model = activePlaylist.customArtworkUri ?: activePlaylist.songs.firstOrNull()?.artworkModel ?: R.drawable.img_playlist_vibe,
                            contentDescription = activePlaylist.name,
                            cornerRadius = 14.dp,
                            modifier = Modifier.size(84.dp)
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (activePlaylist.isSmart) "SMART PLAYLIST" else "CUSTOM PLAYLIST",
                                style = MaterialTheme.typography.labelSmall,
                                color = vybe.accentSecondary
                            )
                            Text(activePlaylist.name, style = MaterialTheme.typography.headlineSmall, color = vybe.textPrimary)
                            Text(
                                "${activePlaylist.songCount} tracks • ${TimeFormatter.formatDuration(activePlaylist.totalDurationMs)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = vybe.textMuted
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { if (activePlaylist.songs.isNotEmpty()) onPlaySongs(activePlaylist.songs, 0) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Play All")
                    }
                    if (!activePlaylist.isSmart) {
                        OutlinedButton(onClick = { addSongsPlaylist = activePlaylist }) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Add")
                        }
                    }
                    OutlinedButton(onClick = { exportM3uLauncher.launch("${activePlaylist.name}.m3u") }) {
                        Icon(Icons.Filled.Download, contentDescription = "Export M3U", modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("M3U")
                    }
                    OutlinedButton(onClick = { exportJsonLauncher.launch("${activePlaylist.name}.json") }) {
                        Text("JSON")
                    }
                }
            }

            if (activePlaylist.songs.isEmpty()) {
                item {
                    Text(
                        "No songs in this playlist yet.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = vybe.textMuted,
                        modifier = Modifier.padding(top = 24.dp)
                    )
                }
            } else {
                itemsIndexed(activePlaylist.songs, key = { idx, s -> "${s.id}_$idx" }) { idx, song ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPlaySongs(activePlaylist.songs, idx) },
                        shape = RoundedCornerShape(12.dp),
                        color = vybe.surfaceCard,
                        border = BorderStroke(0.7.dp, vybe.cardBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            VybeArtwork(
                                model = song.artworkModel,
                                contentDescription = song.title,
                                cornerRadius = 8.dp,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(song.title, style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artist, style = MaterialTheme.typography.bodyMedium, color = vybe.textMuted, maxLines = 1)
                            }
                            if (!activePlaylist.isSmart) {
                                IconButton(
                                    onClick = { if (idx > 0) onMovePlaylistSong(activePlaylist, idx, idx - 1) },
                                    enabled = idx > 0
                                ) {
                                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Move up", tint = vybe.textMuted, modifier = Modifier.size(18.dp))
                                }
                                IconButton(
                                    onClick = { if (idx < activePlaylist.songs.lastIndex) onMovePlaylistSong(activePlaylist, idx, idx + 1) },
                                    enabled = idx < activePlaylist.songs.lastIndex
                                ) {
                                    Icon(Icons.Filled.ArrowDownward, contentDescription = "Move down", tint = vybe.textMuted, modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onRemoveSongFromPlaylist(activePlaylist.id, song.id) }) {
                                    Icon(Icons.Filled.RemoveCircleOutline, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 140.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Playlists", style = MaterialTheme.typography.headlineMedium, color = vybe.textPrimary)
                        Text("Smart collections & custom mixes", style = MaterialTheme.typography.labelMedium, color = vybe.textMuted)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { importLauncher.launch(arrayOf("*/*")) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("import_playlist_btn")
                        ) {
                            Icon(Icons.Filled.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Import")
                        }
                        Button(
                            onClick = { showCreateDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("create_playlist_btn")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("New")
                        }
                    }
                }
            }

            item {
                Text("SMART PLAYLISTS", style = MaterialTheme.typography.labelMedium, color = vybe.accentSecondary)
            }

            items(smartPlaylists, key = { it.id }) { pl ->
                PlaylistCardRow(playlist = pl, onClick = { onSelectPlaylist(pl.id) })
            }

            item {
                Spacer(Modifier.height(4.dp))
                Text("YOUR PLAYLISTS (${customPlaylists.size})", style = MaterialTheme.typography.labelMedium, color = vybe.accentSecondary)
            }

            if (customPlaylists.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(vybe.cardRadius),
                        color = vybe.surfaceCard,
                        border = BorderStroke(0.8.dp, vybe.cardBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.QueueMusic, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(36.dp))
                            Text("No custom playlists yet", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                            Text("Create one or import an M3U / JSON playlist file.", style = MaterialTheme.typography.bodyMedium, color = vybe.textMuted)
                        }
                    }
                }
            } else {
                items(customPlaylists, key = { it.id }) { pl ->
                    PlaylistCardRow(playlist = pl, onClick = { onSelectPlaylist(pl.id) })
                }
            }
        }
    }

    if (showCreateDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create Playlist") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Playlist Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        onCreatePlaylist(name)
                        showCreateDialog = false
                    }
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }

    renamingPlaylist?.let { target ->
        var name by remember { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renamingPlaylist = null },
            title = { Text("Rename Playlist") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true)
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        onRenamePlaylist(target.id, name)
                        renamingPlaylist = null
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renamingPlaylist = null }) { Text("Cancel") }
            }
        )
    }

    addSongsPlaylist?.let { target ->
        AlertDialog(
            onDismissRequest = { addSongsPlaylist = null },
            title = { Text("Add Songs to ${target.name}") },
            text = {
                LazyColumn(
                    modifier = Modifier.height(300.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(allSongs, key = { it.id }) { song ->
                        val alreadyIn = target.songs.any { it.id == song.id }
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !alreadyIn) {
                                    onAddSongToPlaylist(target.id, song.id)
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (alreadyIn) vybe.surfaceElevated.copy(alpha = 0.45f) else vybe.surfaceElevated
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(song.artist, style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                                }
                                Text(if (alreadyIn) "Added" else "+ Add", color = vybe.accentSecondary, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { addSongsPlaylist = null }) { Text("Done") }
            }
        )
    }
}

@Composable
private fun PlaylistCardRow(
    playlist: Playlist,
    onClick: () -> Unit
) {
    val vybe = LocalVybeStyle.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(vybe.cardRadius * 0.75f),
        color = vybe.surfaceCard,
        border = BorderStroke(0.8.dp, vybe.cardBorder)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            VybeArtwork(
                model = playlist.customArtworkUri ?: playlist.songs.firstOrNull()?.artworkModel ?: R.drawable.img_playlist_vibe,
                contentDescription = playlist.name,
                cornerRadius = 10.dp,
                modifier = Modifier.size(56.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(playlist.name, style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                Text(
                    "${playlist.songCount} tracks • ${TimeFormatter.formatDuration(playlist.totalDurationMs)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = vybe.textMuted
                )
            }
            Icon(Icons.Filled.PlayArrow, contentDescription = "Open playlist", tint = vybe.accentSecondary)
        }
    }
}
