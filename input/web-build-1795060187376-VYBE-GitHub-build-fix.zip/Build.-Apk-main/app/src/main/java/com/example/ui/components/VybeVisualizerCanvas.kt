package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.audio.VybeDspAudioProcessor
import com.example.model.DisplayRefreshInfo
import com.example.model.PerformanceMode
import com.example.model.VisualizerSize
import com.example.model.VisualizerStyle
import com.example.ui.theme.LocalVybeStyle
import com.example.util.DisplayRefreshRateManager
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VybeVisualizerCanvas(
    dspProcessor: VybeDspAudioProcessor,
    isPlaying: Boolean,
    style: VisualizerStyle,
    intensity: Float,
    sizePreset: VisualizerSize,
    customColorHex: Long?,
    performanceMode: PerformanceMode,
    displayRefreshInfo: DisplayRefreshInfo,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val primaryColor = customColorHex?.let { Color(it) } ?: vybe.accentPrimary
    val secondaryColor = if (customColorHex != null) {
        Color(customColorHex).copy(alpha = 0.72f)
    } else {
        vybe.accentSecondary
    }

    // Pre-allocated zero-GC arrays for smooth 60/90/120Hz Canvas rendering
    val spectrum = remember { FloatArray(32) }
    val smoothedSpectrum = remember { FloatArray(32) }
    val peakHold = remember { FloatArray(32) }
    val waveform = remember { FloatArray(64) }
    val smoothedWave = remember { FloatArray(64) }
    var frameTick by remember { mutableLongStateOf(0L) }
    var elapsedSec by remember { mutableLongStateOf(0L) }

    val minFrameIntervalNs = remember(performanceMode, displayRefreshInfo) {
        DisplayRefreshRateManager.targetFrameIntervalNanos(performanceMode, displayRefreshInfo)
    }

    LaunchedEffect(isPlaying, minFrameIntervalNs) {
        var lastFrameNs = 0L
        var lastRenderNs = 0L
        while (true) {
            withFrameNanos { nowNs ->
                if (lastFrameNs == 0L) {
                    lastFrameNs = nowNs
                    lastRenderNs = nowNs
                }
                val sinceRender = nowNs - lastRenderNs
                if (sinceRender >= minFrameIntervalNs - 500_000L) {
                    val dt = ((nowNs - lastFrameNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                    lastFrameNs = nowNs
                    lastRenderNs = nowNs
                    elapsedSec = nowNs

                    if (isPlaying) {
                        dspProcessor.copySpectrumInto(spectrum)
                        dspProcessor.copyWaveformInto(waveform)
                    } else {
                        spectrum.fill(0f)
                        waveform.fill(0f)
                    }

                    val riseRate = (dt * 24f).coerceIn(0.1f, 0.9f)
                    val decayRate = (dt * 6.5f).coerceIn(0.05f, 0.45f)
                    for (i in 0 until 32) {
                        val target = (spectrum[i] * intensity).coerceIn(0f, 1f)
                        smoothedSpectrum[i] = if (target > smoothedSpectrum[i]) {
                            smoothedSpectrum[i] + (target - smoothedSpectrum[i]) * riseRate
                        } else {
                            smoothedSpectrum[i] * (1f - decayRate)
                        }
                        peakHold[i] = if (smoothedSpectrum[i] >= peakHold[i]) {
                            smoothedSpectrum[i]
                        } else {
                            (peakHold[i] - dt * 0.35f).coerceAtLeast(0f)
                        }
                    }

                    for (i in 0 until 64) {
                        val targetW = (waveform[i] * intensity).coerceIn(-1f, 1f)
                        smoothedWave[i] = smoothedWave[i] + (targetW - smoothedWave[i]) * riseRate
                    }

                    frameTick++
                }
            }
            if (!isPlaying && smoothedSpectrum.all { it < 0.005f }) {
                // Idle cleanly without burning battery when paused and decayed
                kotlinx.coroutines.delay(120L)
            }
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(sizePreset.heightDp.dp)
    ) {
        // Read frameTick to trigger DrawScope invalidation cleanly without recomposing parent UI
        val tick = frameTick
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas

        when (style) {
            VisualizerStyle.SPECTRUM_ANALYZER -> {
                val count = 32
                val barGap = w * 0.008f
                val barW = (w - barGap * (count + 1)) / count
                val brush = Brush.verticalGradient(listOf(secondaryColor, primaryColor))
                for (i in 0 until count) {
                    val mag = smoothedSpectrum[i].coerceIn(0.03f, 1f)
                    val barH = mag * (h * 0.88f)
                    val x = barGap + i * (barW + barGap)
                    val y = h - barH
                    drawRoundRect(
                        brush = brush,
                        topLeft = Offset(x, y),
                        size = Size(barW, barH),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                    val peakY = h - (peakHold[i].coerceIn(0.04f, 1f) * h * 0.90f)
                    drawLine(
                        color = Color.White.copy(alpha = 0.85f),
                        start = Offset(x, peakY),
                        end = Offset(x + barW, peakY),
                        strokeWidth = 2.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            VisualizerStyle.FREQUENCY_BARS -> {
                val count = 28
                val centerY = h / 2f
                val barGap = w * 0.01f
                val barW = (w - barGap * (count + 1)) / count
                val brush = Brush.verticalGradient(listOf(secondaryColor, primaryColor, secondaryColor))
                for (i in 0 until count) {
                    val mirrorIdx = if (i < count / 2) (count / 2 - 1 - i) else (i - count / 2)
                    val mag = smoothedSpectrum[(mirrorIdx * 2).coerceIn(0, 31)].coerceIn(0.05f, 1f)
                    val halfBarH = mag * (h * 0.44f)
                    val x = barGap + i * (barW + barGap)
                    drawRoundRect(
                        brush = brush,
                        topLeft = Offset(x, centerY - halfBarH),
                        size = Size(barW, halfBarH * 2f),
                        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                    )
                }
            }

            VisualizerStyle.WAVEFORM -> {
                val path = Path()
                val midY = h / 2f
                val stepX = w / 63f
                for (i in 0 until 64) {
                    val x = i * stepX
                    val y = midY + smoothedWave[i] * (h * 0.42f)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(
                    path = path,
                    brush = Brush.horizontalGradient(listOf(primaryColor, secondaryColor, primaryColor)),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
                // Soft glow under-trace
                drawPath(
                    path = path,
                    color = secondaryColor.copy(alpha = 0.25f),
                    style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            VisualizerStyle.MINIMAL_WAVE -> {
                val path = Path()
                val midY = h / 2f
                val stepX = w / 63f
                for (i in 0 until 64) {
                    val x = i * stepX
                    val env = sin(PI * i / 63.0).toFloat()
                    val y = midY + smoothedWave[i] * env * (h * 0.36f)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawLine(
                    color = primaryColor.copy(alpha = 0.25f),
                    start = Offset(0f, midY),
                    end = Offset(w, midY),
                    strokeWidth = 1.dp.toPx()
                )
                drawPath(
                    path = path,
                    color = secondaryColor,
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            VisualizerStyle.CIRCULAR -> {
                val center = Offset(w / 2f, h / 2f)
                val baseR = minOf(w, h) * 0.24f
                val maxBar = minOf(w, h) * 0.22f
                val bars = 32
                val phase = (tick * 0.015f)
                for (i in 0 until bars) {
                    val angle = (2.0 * PI * i / bars) + phase
                    val mag = smoothedSpectrum[i].coerceIn(0.05f, 1f)
                    val rStart = baseR
                    val rEnd = baseR + mag * maxBar
                    val start = Offset(
                        center.x + cos(angle).toFloat() * rStart,
                        center.y + sin(angle).toFloat() * rStart
                    )
                    val end = Offset(
                        center.x + cos(angle).toFloat() * rEnd,
                        center.y + sin(angle).toFloat() * rEnd
                    )
                    drawLine(
                        color = if (i % 2 == 0) secondaryColor else primaryColor,
                        start = start,
                        end = end,
                        strokeWidth = 3.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
                drawCircle(
                    color = primaryColor.copy(alpha = 0.35f),
                    radius = baseR * 0.9f,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }

            VisualizerStyle.AUDIO_RINGS -> {
                val center = Offset(w / 2f, h / 2f)
                val maxR = minOf(w, h) * 0.45f
                val bass = (smoothedSpectrum[0] + smoothedSpectrum[1] + smoothedSpectrum[2]) / 3f
                val mid = (smoothedSpectrum[8] + smoothedSpectrum[10] + smoothedSpectrum[12]) / 3f
                val high = (smoothedSpectrum[20] + smoothedSpectrum[24] + smoothedSpectrum[28]) / 3f
                val energies = listOf(bass, mid, high, (bass + high) * 0.5f)
                energies.forEachIndexed { idx, e ->
                    val r = maxR * (0.28f + idx * 0.20f) * (0.82f + e * 0.38f)
                    drawCircle(
                        color = (if (idx % 2 == 0) primaryColor else secondaryColor).copy(
                            alpha = (0.35f + e * 0.65f).coerceIn(0.2f, 1f)
                        ),
                        radius = r,
                        center = center,
                        style = Stroke(width = (2f + e * 4f).dp.toPx())
                    )
                }
            }

            VisualizerStyle.NEON_PARTICLES -> {
                val timeSec = elapsedSec / 1_000_000_000.0
                val count = 24
                for (i in 0 until count) {
                    val band = smoothedSpectrum[(i * 32) / count]
                    val px = ((i + 0.5f) / count) * w
                    val drift = sin(timeSec * (1.2 + (i % 5) * 0.35) + i).toFloat()
                    val py = h * 0.5f + drift * (h * 0.25f) - band * (h * 0.28f)
                    val radius = (3.dp.toPx() + band * 9.dp.toPx())
                    val col = if (i % 2 == 0) secondaryColor else primaryColor
                    drawCircle(color = col.copy(alpha = 0.28f), radius = radius * 1.9f, center = Offset(px, py))
                    drawCircle(color = col, radius = radius * 0.65f, center = Offset(px, py))
                }
            }

            VisualizerStyle.RETRO_ANALOG -> {
                // Dual analog VU meters (Left / Right energy)
                val lowAvg = (smoothedSpectrum[0] + smoothedSpectrum[2] + smoothedSpectrum[4]) / 3f
                val highAvg = (smoothedSpectrum[6] + smoothedSpectrum[10] + smoothedSpectrum[14]) / 3f
                val levels = listOf(lowAvg.coerceIn(0f, 1f), highAvg.coerceIn(0f, 1f))
                val panelW = (w - 16.dp.toPx()) / 2f
                levels.forEachIndexed { idx, level ->
                    val left = idx * (panelW + 16.dp.toPx())
                    val center = Offset(left + panelW / 2f, h * 0.86f)
                    val arcR = minOf(panelW * 0.44f, h * 0.72f)
                    drawRoundRect(
                        color = Color(0xFF281F17),
                        topLeft = Offset(left, 4.dp.toPx()),
                        size = Size(panelW, h - 8.dp.toPx()),
                        cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                    )
                    drawArc(
                        color = Color(0xFFF59E0B).copy(alpha = 0.35f),
                        startAngle = 210f,
                        sweepAngle = 120f,
                        useCenter = false,
                        topLeft = Offset(center.x - arcR, center.y - arcR),
                        size = Size(arcR * 2f, arcR * 2f),
                        style = Stroke(width = 2.dp.toPx())
                    )
                    // Red zone on right side of arc
                    drawArc(
                        color = Color(0xFFEF4444).copy(alpha = 0.7f),
                        startAngle = 300f,
                        sweepAngle = 30f,
                        useCenter = false,
                        topLeft = Offset(center.x - arcR, center.y - arcR),
                        size = Size(arcR * 2f, arcR * 2f),
                        style = Stroke(width = 3.dp.toPx())
                    )
                    val needleDeg = 215f + level * 110f
                    val rad = needleDeg * (PI / 180.0)
                    val tip = Offset(
                        center.x + cos(rad).toFloat() * (arcR * 0.92f),
                        center.y + sin(rad).toFloat() * (arcR * 0.92f)
                    )
                    drawLine(
                        color = Color(0xFFFBBF24),
                        start = center,
                        end = tip,
                        strokeWidth = 2.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                    drawCircle(color = Color(0xFFEA580C), radius = 4.dp.toPx(), center = center)
                }
            }
        }
    }
}
