package com.example.ui

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.QueueMusic
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.model.ArtworkStyle
import com.example.model.NavDockStyle
import com.example.ui.components.AuroraMeshBackground
import com.example.ui.components.MiniPlayerBar
import com.example.ui.components.ThemeSwitcherSheet
import com.example.ui.components.VybeArtwork
import com.example.ui.components.rememberVinylRotationAngle
import com.example.ui.navigation.VybeRoute
import com.example.ui.screens.EqualizerScreen
import com.example.ui.screens.GuitarScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.LyricsScreen
import com.example.ui.screens.NowPlayingScreen
import com.example.ui.screens.PlaylistsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.screens.VinylModeScreen
import com.example.ui.theme.LocalVybeStyle
import com.example.ui.theme.VybeTheme

private data class BottomNavTab(
    val route: VybeRoute,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun VybeApp(
    openNowPlayingTrigger: Int = 0,
    viewModel: VybeViewModel = viewModel()
) {
    val context = LocalContext.current
    val activity = context as? Activity

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val songs by viewModel.filteredSongs.collectAsStateWithLifecycle()
    val allSongs by viewModel.allSongs.collectAsStateWithLifecycle()
    val albums by viewModel.albums.collectAsStateWithLifecycle()
    val artists by viewModel.artists.collectAsStateWithLifecycle()
    val folders by viewModel.folders.collectAsStateWithLifecycle()
    val genres by viewModel.genres.collectAsStateWithLifecycle()
    val deletedSongs by viewModel.deletedSongs.collectAsStateWithLifecycle()
    val excludedFolders by viewModel.excludedFolders.collectAsStateWithLifecycle()
    val customPlaylists by viewModel.customPlaylists.collectAsStateWithLifecycle()
    val smartPlaylists by viewModel.smartPlaylists.collectAsStateWithLifecycle()
    val customEqPresets by viewModel.customEqPresets.collectAsStateWithLifecycle()
    val eqCapabilities by viewModel.eqCapabilities.collectAsStateWithLifecycle()
    val currentLyrics by viewModel.currentLyrics.collectAsStateWithLifecycle()
    val statsSummary by viewModel.statsSummary.collectAsStateWithLifecycle()
    val storageSummary by viewModel.storageSummary.collectAsStateWithLifecycle()
    val displayRefreshInfo by viewModel.displayRefreshInfo.collectAsStateWithLifecycle()
    val tunerState by viewModel.tunerState.collectAsStateWithLifecycle()
    val metronomeState by viewModel.metronomeState.collectAsStateWithLifecycle()
    val practiceTools by viewModel.practiceTools.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    val audioPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[audioPermission] == true
        hasAudioPermission = granted
        viewModel.scanLibrary()
    }

    val requestAudioPermissions = {
        val perms = mutableListOf(audioPermission)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionsLauncher.launch(perms.toTypedArray())
    }

    // Initial scan & display refresh rate sync
    LaunchedEffect(hasAudioPermission) {
        viewModel.scanLibrary()
    }
    LaunchedEffect(settings.performanceMode) {
        viewModel.refreshDisplayInfo(activity)
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(statusBanner) {
        val msg = statusBanner
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    var showThemeSheet by remember { mutableStateOf(false) }
    var selectedPlaylistId by remember { mutableStateOf<Long?>(null) }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = navBackStackEntry?.destination

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    // Navigate directly to Now Playing when user taps the lock-screen card or notification
    LaunchedEffect(openNowPlayingTrigger) {
        if (openNowPlayingTrigger > 0) {
            navController.navigate(VybeRoute.NowPlaying) {
                launchSingleTop = true
            }
        }
    }

    // Ensure POST_NOTIFICATIONS is requested on Android 13+ when playback begins so lock-screen controls appear
    LaunchedEffect(playbackState.isPlaying) {
        if (playbackState.isPlaying && settings.showNotifications &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val topLevelTabs = remember {
        listOf(
            BottomNavTab(VybeRoute.Home, "Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
            BottomNavTab(VybeRoute.Library, "Library", Icons.Filled.LibraryMusic, Icons.Outlined.LibraryMusic, "nav_library"),
            BottomNavTab(VybeRoute.Playlists, "Playlists", Icons.Filled.QueueMusic, Icons.Outlined.QueueMusic, "nav_playlists"),
            BottomNavTab(VybeRoute.Guitar, "Guitar", Icons.Filled.MusicNote, Icons.Outlined.MusicNote, "nav_guitar"),
            BottomNavTab(VybeRoute.Settings, "Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "nav_settings")
        )
    }

    val isFullScreenPlayerOrSubpage = currentDest?.let { dest ->
        dest.hasRoute<VybeRoute.NowPlaying>() ||
            dest.hasRoute<VybeRoute.VinylMode>() ||
            dest.hasRoute<VybeRoute.Equalizer>() ||
            dest.hasRoute<VybeRoute.Lyrics>() ||
            dest.hasRoute<VybeRoute.Stats>()
    } ?: false

    VybeTheme(
        themeMode = settings.themeMode,
        appearanceMode = settings.appearanceMode,
        accentPreset = settings.accentPreset
    ) {
        val vybe = LocalVybeStyle.current

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(vybe.bgDeep)
        ) {
            if (vybe.isGlassAddon) {
                AuroraMeshBackground(animationsEnabled = settings.animationsEnabled)
            }

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = if (vybe.isGlassAddon) Color.Transparent else vybe.bgDeep,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!isFullScreenPlayerOrSubpage) {
                        Column(modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)) {
                            MiniPlayerBar(
                                playbackState = playbackState,
                                artworkStyle = settings.artworkStyle,
                                onOpenNowPlaying = { navController.navigate(VybeRoute.NowPlaying) },
                                onPlayPause = { viewModel.playerController.togglePlayPause() },
                                onNext = { viewModel.playerController.next() },
                                onPrevious = { viewModel.playerController.previous() },
                                hapticsEnabled = settings.hapticFeedbackEnabled
                            )

                            val onSelectTab: (BottomNavTab) -> Unit = { tab ->
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }

                            if (settings.navDockStyle == NavDockStyle.FLOATING_GLASS_PILL) {
                                FloatingGlassPillDock(
                                    tabs = topLevelTabs,
                                    currentDest = currentDest,
                                    artworkModel = playbackState.currentSong?.artworkModel,
                                    isPlaying = playbackState.isPlaying,
                                    animationsEnabled = settings.animationsEnabled,
                                    onSelectTab = onSelectTab,
                                    onOpenNowPlaying = { navController.navigate(VybeRoute.NowPlaying) }
                                )
                            } else {
                                NavigationBar(
                                    containerColor = vybe.surfaceCard,
                                    contentColor = vybe.textPrimary,
                                    windowInsets = WindowInsets(0, 0, 0, 0)
                                ) {
                                    topLevelTabs.forEach { tab ->
                                        val selected = currentDest?.hasRoute(tab.route::class) == true
                                        NavigationBarItem(
                                            selected = selected,
                                            onClick = { onSelectTab(tab) },
                                            icon = {
                                                Icon(
                                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                    contentDescription = tab.label
                                                )
                                            },
                                            label = { Text(tab.label, maxLines = 1) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = vybe.accentSecondary,
                                                selectedTextColor = vybe.accentSecondary,
                                                indicatorColor = vybe.accentPrimary.copy(alpha = 0.22f),
                                                unselectedIconColor = vybe.textMuted,
                                                unselectedTextColor = vybe.textMuted
                                            ),
                                            modifier = Modifier.testTag(tab.testTag)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = VybeRoute.Home,
                    enterTransition = { fadeIn(tween(200)) },
                    exitTransition = { fadeOut(tween(180)) }
                ) {
                    composable<VybeRoute.Home> {
                        HomeScreen(
                            songs = allSongs,
                            artists = artists,
                            smartPlaylists = smartPlaylists,
                            customPlaylists = customPlaylists,
                            playbackState = playbackState,
                            settings = settings,
                            displayRefreshInfo = displayRefreshInfo,
                            hasAudioPermission = hasAudioPermission,
                            onRequestAudioPermission = requestAudioPermissions,
                            onCreateSampleTracks = { viewModel.createSampleOfflineTracks() },
                            onPlaySongs = { list, idx ->
                                viewModel.playerController.playSongs(list, idx)
                                navController.navigate(VybeRoute.NowPlaying)
                            },
                            onOpenNowPlaying = { navController.navigate(VybeRoute.NowPlaying) },
                            onOpenVinylMode = { navController.navigate(VybeRoute.VinylMode) },
                            onOpenEqualizer = { navController.navigate(VybeRoute.Equalizer) },
                            onOpenStats = { navController.navigate(VybeRoute.Stats) },
                            onOpenLibrary = { navController.navigate(VybeRoute.Library) },
                            onOpenPlaylist = { pl ->
                                selectedPlaylistId = pl.id
                                navController.navigate(VybeRoute.Playlists)
                            },
                            onOpenThemeSheet = { showThemeSheet = true },
                            onToggleThemeMode = { viewModel.toggleThemeMode() }
                        )
                    }

                    composable<VybeRoute.Library> {
                        LibraryScreen(
                            songs = songs,
                            albums = albums,
                            artists = artists,
                            folders = folders,
                            genres = genres,
                            deletedSongs = deletedSongs,
                            excludedFolders = excludedFolders,
                            customPlaylists = customPlaylists,
                            searchQuery = searchQuery,
                            isScanning = isScanning,
                            playbackState = playbackState,
                            settings = settings,
                            onSearchChange = viewModel::setSearchQuery,
                            onUpdateSort = viewModel::updateSort,
                            onRefreshScan = {
                                if (!hasAudioPermission) requestAudioPermissions()
                                else viewModel.scanLibrary()
                            },
                            onCreateSamples = viewModel::createSampleOfflineTracks,
                            onPlaySongs = { list, idx -> viewModel.playerController.playSongs(list, idx) },
                            onToggleFavorite = viewModel::toggleFavorite,
                            onPlayNext = { s ->
                                viewModel.playerController.playNextInQueue(s)
                                viewModel.showMessage("Playing \"${s.title}\" next")
                            },
                            onAddToQueue = { s ->
                                viewModel.playerController.addToQueue(s)
                                viewModel.showMessage("Added \"${s.title}\" to queue")
                            },
                            onAddSongToPlaylist = viewModel::addSongToPlaylist,
                            onCreatePlaylistWithSong = { name, songId ->
                                viewModel.createPlaylist(name, listOf(songId))
                            },
                            onUpdateMetadata = viewModel::updateSongMetadata,
                            onShareSong = { s -> viewModel.shareSongInfo(context, s) },
                            onMoveToTrash = viewModel::moveToTrash,
                            onRestoreSong = viewModel::restoreFromTrash,
                            onDetectDuplicates = viewModel::detectDuplicates,
                            onExcludeFolder = viewModel::excludeFolder,
                            onIncludeFolder = viewModel::includeFolder
                        )
                    }

                    composable<VybeRoute.Playlists> {
                        PlaylistsScreen(
                            smartPlaylists = smartPlaylists,
                            customPlaylists = customPlaylists,
                            allSongs = allSongs,
                            selectedPlaylistId = selectedPlaylistId,
                            onSelectPlaylist = { selectedPlaylistId = it },
                            onCreatePlaylist = { name -> viewModel.createPlaylist(name) },
                            onRenamePlaylist = viewModel::renamePlaylist,
                            onUpdatePlaylistArtwork = viewModel::updatePlaylistArtwork,
                            onDeletePlaylist = viewModel::deletePlaylist,
                            onAddSongToPlaylist = viewModel::addSongToPlaylist,
                            onRemoveSongFromPlaylist = viewModel::removeSongFromPlaylist,
                            onMovePlaylistSong = viewModel::movePlaylistSong,
                            onPlaySongs = { list, idx ->
                                viewModel.playerController.playSongs(list, idx)
                                navController.navigate(VybeRoute.NowPlaying)
                            },
                            onExportM3u = viewModel::exportPlaylistM3u,
                            onExportJson = viewModel::exportPlaylistJson,
                            onImportPlaylist = viewModel::importPlaylist
                        )
                    }

                    composable<VybeRoute.Guitar> {
                        GuitarScreen(
                            tunerState = tunerState,
                            metronomeState = metronomeState,
                            practiceTools = practiceTools,
                            onStartTuner = viewModel::startTuner,
                            onStopTuner = viewModel::stopTuner,
                            onPlayReferenceTone = viewModel::playReferenceTone,
                            onToggleMetronome = viewModel::toggleMetronome,
                            onSetMetronomeBpm = viewModel::setMetronomeBpm,
                            onTapTempo = { viewModel.tapTempo() },
                            onSetTimeSignature = viewModel::setTimeSignature,
                            onSetMetronomeAccent = viewModel::setMetronomeAccent,
                            onPlayChordPreview = viewModel::playChordPreview,
                            onTogglePracticeTimer = viewModel::togglePracticeTimer,
                            onResetPracticeTimer = viewModel::resetPracticeTimer,
                            onSetBpmTrainer = viewModel::setBpmTrainer,
                            onSelectProgression = viewModel::selectProgression
                        )
                    }

                    composable<VybeRoute.Settings> {
                        SettingsScreen(
                            settings = settings,
                            displayRefreshInfo = displayRefreshInfo,
                            storageSummary = storageSummary,
                            onOpenThemeSheet = { showThemeSheet = true },
                            onOpenEqualizer = { navController.navigate(VybeRoute.Equalizer) },
                            onOpenStats = { navController.navigate(VybeRoute.Stats) },
                            onSetPerformanceMode = { mode -> viewModel.setPerformanceMode(mode, activity) },
                            onSetAnimationsEnabled = viewModel::setAnimationsEnabled,
                            onSetPlayerBackground = viewModel::setPlayerBackgroundStyle,
                            onSetPlayerLayout = viewModel::setPlayerLayoutStyle,
                            onSetNavDockStyle = viewModel::setNavDockStyle,
                            onSetVisualizerEnabled = viewModel::setVisualizerEnabled,
                            onSetVisualizerStyle = viewModel::setVisualizerStyle,
                            onSetVisualizerSize = viewModel::setVisualizerSize,
                            onSetVisualizerIntensity = viewModel::setVisualizerIntensity,
                            onSetGapless = viewModel::setGaplessPlayback,
                            onSetCrossfadeMs = viewModel::setCrossfadeMs,
                            onSetFadeInOut = viewModel::setFadeInOut,
                            onSetAutoPauseDisconnect = viewModel::setAutoPauseDisconnect,
                            onSetShowNotifications = viewModel::setShowNotifications,
                            onSetSkipSilence = viewModel::setSkipSilence,
                            onSetCrossfadeCurve = viewModel::setCrossfadeCurve,
                            onSetCrossfadeOnManualSkip = viewModel::setCrossfadeOnManualSkip,
                            onSetHapticFeedback = viewModel::setHapticFeedbackEnabled,
                            onRefreshScan = viewModel::scanLibrary
                        )
                    }

                    composable<VybeRoute.NowPlaying>(
                        enterTransition = {
                            slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Up, tween(280))
                        },
                        exitTransition = {
                            slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Down, tween(240))
                        }
                    ) {
                        NowPlayingScreen(
                            playbackState = playbackState,
                            settings = settings,
                            dspProcessor = viewModel.dspProcessor,
                            displayRefreshInfo = displayRefreshInfo,
                            currentLyrics = currentLyrics,
                            onBack = { navController.popBackStack() },
                            onToggleThemeMode = viewModel::toggleThemeMode,
                            onOpenVinylMode = { navController.navigate(VybeRoute.VinylMode) },
                            onOpenLyrics = { navController.navigate(VybeRoute.Lyrics) },
                            onOpenEqualizer = { navController.navigate(VybeRoute.Equalizer) },
                            onPlayPause = { viewModel.playerController.togglePlayPause() },
                            onNext = { viewModel.playerController.next() },
                            onPrevious = { viewModel.playerController.previous() },
                            onSeekTo = { viewModel.playerController.seekTo(it) },
                            onSeekBy = { viewModel.playerController.seekBy(it) },
                            onToggleAbLoop = { viewModel.playerController.toggleAbLoopMarker() },
                            onClearAbLoop = { viewModel.playerController.clearAbLoop() },
                            onToggleShuffle = { viewModel.playerController.toggleShuffle() },
                            onCycleRepeat = { viewModel.playerController.cycleRepeatMode() },
                            onToggleFavorite = viewModel::toggleFavorite,
                            onSetSpeed = { viewModel.playerController.setPlaybackSpeed(it) },
                            onSetVolume = { viewModel.playerController.setVolume(it) },
                            onStartSleepTimer = { viewModel.playerController.startSleepTimer(it) },
                            onJumpToQueue = { viewModel.playerController.jumpToQueueIndex(it) },
                            onRemoveFromQueue = { viewModel.playerController.removeFromQueue(it) },
                            onMoveQueueItem = { from, to -> viewModel.playerController.moveQueueItem(from, to) },
                            onSelectVisualizerStyle = viewModel::setVisualizerStyle,
                            onToggleVisualizer = viewModel::setVisualizerEnabled,
                            onSetSkipSilence = viewModel::setSkipSilence,
                            onSetFadeInOut = viewModel::setFadeInOut,
                            onSetAutoPauseDisconnect = viewModel::setAutoPauseDisconnect,
                            onSetShowNotifications = viewModel::setShowNotifications,
                            onSelectPlayerLayout = viewModel::setPlayerLayoutStyle,
                            onShareSong = { s -> viewModel.shareSongInfo(context, s) },
                            onSetCrossfadeMs = viewModel::setCrossfadeMs,
                            onSetCrossfadeCurve = viewModel::setCrossfadeCurve,
                            onSetCrossfadeOnManualSkip = viewModel::setCrossfadeOnManualSkip,
                            onSetHapticFeedback = viewModel::setHapticFeedbackEnabled
                        )
                    }

                    composable<VybeRoute.VinylMode> {
                        VinylModeScreen(
                            playbackState = playbackState,
                            onBack = { navController.popBackStack() },
                            onPlayPause = { viewModel.playerController.togglePlayPause() },
                            onNext = { viewModel.playerController.next() },
                            onPrevious = { viewModel.playerController.previous() },
                            onSeekTo = { viewModel.playerController.seekTo(it) },
                            onToggleFavorite = viewModel::toggleFavorite,
                            hapticsEnabled = settings.hapticFeedbackEnabled
                        )
                    }

                    composable<VybeRoute.Equalizer> {
                        EqualizerScreen(
                            settings = settings,
                            capabilities = eqCapabilities,
                            dspProcessor = viewModel.dspProcessor,
                            isPlaying = playbackState.isPlaying,
                            displayRefreshInfo = displayRefreshInfo,
                            builtInPresets = viewModel.audioEffectsEngine.builtInPresets,
                            customPresets = customEqPresets,
                            bandLabels = viewModel.audioEffectsEngine.bandLabels,
                            isClipping = playbackState.isClipping,
                            onBack = { navController.popBackStack() },
                            onToggleEq = viewModel::setEqEnabled,
                            onUpdateBand = viewModel::updateEqBand,
                            onApplyPreset = viewModel::applyEqPreset,
                            onResetFlat = viewModel::resetEqFlat,
                            onSaveCustomPreset = viewModel::saveCustomEqPreset,
                            onDeleteCustomPreset = viewModel::deleteCustomEqPreset,
                            onSelectVisualizerStyle = viewModel::setVisualizerStyle,
                            onSetBassBoost = viewModel::setBassBoost,
                            onSetVirtualizer = viewModel::setVirtualizer,
                            onSetLoudness = viewModel::setLoudnessGain,
                            onSetPreamp = viewModel::setPreampDb,
                            onSetBalance = viewModel::setChannelBalance,
                            onSetNormalization = viewModel::setVolumeNormalization,
                            onApplyHeadphoneProfile = viewModel::applyHeadphoneProfile
                        )
                    }

                    composable<VybeRoute.Lyrics> {
                        LyricsScreen(
                            playbackState = playbackState,
                            lyricsData = currentLyrics,
                            onBack = { navController.popBackStack() },
                            onSeekTo = { viewModel.playerController.seekTo(it) },
                            onSaveLyrics = viewModel::saveManualLyrics,
                            onImportLrc = viewModel::importLrcFile,
                            onWebSearchLyrics = { song -> viewModel.openManualLyricsWebSearch(context, song) },
                            onPlayPause = { viewModel.playerController.togglePlayPause() },
                            onNext = { viewModel.playerController.next() },
                            onPrevious = { viewModel.playerController.previous() },
                            onReloadFromFile = viewModel::rescanCurrentLyrics,
                            hapticsEnabled = settings.hapticFeedbackEnabled
                        )
                    }

                    composable<VybeRoute.Stats> {
                        StatsScreen(
                            stats = statsSummary,
                            onBack = { navController.popBackStack() },
                            onClearHistory = viewModel::clearStatsHistory
                        )
                    }
                }
                }
            }
        }

        if (showThemeSheet) {
            ThemeSwitcherSheet(
                settings = settings,
                onDismiss = { showThemeSheet = false },
                onSelectThemeMode = viewModel::setThemeMode,
                onSelectAppearance = viewModel::setAppearanceMode,
                onSelectAccent = viewModel::setAccentPreset,
                onSelectArtworkStyle = viewModel::setArtworkStyle,
                onSelectPlayerLayout = viewModel::setPlayerLayoutStyle,
                onSelectPlayerBackground = viewModel::setPlayerBackgroundStyle,
                onSelectNavDockStyle = viewModel::setNavDockStyle
            )
        }
    }
}

@Composable
private fun FloatingGlassPillDock(
    tabs: List<BottomNavTab>,
    currentDest: androidx.navigation.NavDestination?,
    artworkModel: Any?,
    isPlaying: Boolean,
    animationsEnabled: Boolean,
    onSelectTab: (BottomNavTab) -> Unit,
    onOpenNowPlaying: () -> Unit
) {
    val vybe = LocalVybeStyle.current
    val spinDeg = rememberVinylRotationAngle(
        isPlaying = isPlaying,
        playbackSpeed = 1f,
        enabled = animationsEnabled,
        baseDegPerSec = 65f
    )

    val leftTabs = tabs.take(2)
    val rightTabs = tabs.drop(2)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("floating_glass_pill_dock"),
        shape = RoundedCornerShape(32.dp),
        color = vybe.surfaceCard.copy(alpha = 0.90f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = if (vybe.isLight) 0.45f else 0.18f)),
        shadowElevation = 14.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            leftTabs.forEach { tab ->
                FloatingDockTabButton(
                    tab = tab,
                    selected = currentDest?.hasRoute(tab.route::class) == true,
                    onClick = { onSelectTab(tab) }
                )
            }

            // Center glowing spinning album-art / audio orb
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .border(2.dp, vybe.accentGradient, CircleShape)
                    .background(vybe.surfaceElevated)
                    .clickable(onClick = onOpenNowPlaying)
                    .testTag("nav_floating_now_playing_orb"),
                contentAlignment = Alignment.Center
            ) {
                if (artworkModel != null) {
                    VybeArtwork(
                        model = artworkModel,
                        contentDescription = "Open Now Playing",
                        style = ArtworkStyle.VINYL_DISC,
                        cornerRadius = 24.dp,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(3.dp)
                            .clip(CircleShape)
                            .graphicsLayer { rotationZ = spinDeg }
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.GraphicEq,
                        contentDescription = "Open Now Playing",
                        tint = vybe.accentSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            rightTabs.forEach { tab ->
                FloatingDockTabButton(
                    tab = tab,
                    selected = currentDest?.hasRoute(tab.route::class) == true,
                    onClick = { onSelectTab(tab) }
                )
            }
        }
    }
}

@Composable
private fun FloatingDockTabButton(
    tab: BottomNavTab,
    selected: Boolean,
    onClick: () -> Unit
) {
    val vybe = LocalVybeStyle.current
    Box(
        modifier = Modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clip(CircleShape)
            .background(
                if (selected) vybe.accentPrimary.copy(alpha = 0.28f) else Color.Transparent
            )
            .then(
                if (selected) {
                    Modifier.border(1.dp, vybe.accentSecondary.copy(alpha = 0.55f), CircleShape)
                } else {
                    Modifier
                }
            )
            .clickable(onClick = onClick)
            .testTag(tab.testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
            contentDescription = tab.label,
            tint = if (selected) vybe.accentSecondary else vybe.textMuted,
            modifier = Modifier.size(22.dp)
        )
    }
}
