package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.audio.PlaybackUiState
import com.example.data.local.VybeSettings
import com.example.model.ArtistGroup
import com.example.model.DisplayRefreshInfo
import com.example.model.Playlist
import com.example.model.Song
import com.example.ui.components.AnimatedEqBars
import com.example.ui.components.VybeArtwork
import com.example.ui.theme.LocalVybeStyle
import com.example.util.TimeFormatter
import kotlin.math.roundToInt

private enum class HomeQuickFilter(val label: String) {
    ALL("All"),
    NEW_RELEASE("New Release"),
    FAVORITES("Favorites"),
    LOSSLESS("Lossless"),
    MOST_PLAYED("Most Played")
}

@Composable
fun HomeScreen(
    songs: List<Song>,
    artists: List<ArtistGroup>,
    smartPlaylists: List<Playlist>,
    customPlaylists: List<Playlist>,
    playbackState: PlaybackUiState,
    settings: VybeSettings,
    displayRefreshInfo: DisplayRefreshInfo,
    hasAudioPermission: Boolean,
    onRequestAudioPermission: () -> Unit,
    onCreateSampleTracks: () -> Unit,
    onPlaySongs: (List<Song>, Int) -> Unit,
    onOpenNowPlaying: () -> Unit,
    onOpenVinylMode: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onOpenThemeSheet: () -> Unit,
    onToggleThemeMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    var activeFilter by remember { mutableStateOf(HomeQuickFilter.ALL) }

    val recentlyPlayed = songs.filter { it.lastPlayedAt > 0L }.sortedByDescending { it.lastPlayedAt }.take(10)
    val favorites = songs.filter { it.isFavorite }.take(12)
    val recentlyAdded = songs.sortedByDescending { it.dateAddedSec }.take(12)
    val popularArtists = artists.sortedByDescending { a -> a.songs.sumOf { it.playCount } + a.trackCount }.take(10)
    val recommendedPlaylists = (customPlaylists + smartPlaylists).filter { it.songs.isNotEmpty() }.take(6)

    val filteredQuickTracks = remember(songs, activeFilter) {
        when (activeFilter) {
            HomeQuickFilter.ALL -> songs.take(6)
            HomeQuickFilter.NEW_RELEASE -> songs.sortedByDescending { it.dateAddedSec }.take(8)
            HomeQuickFilter.FAVORITES -> songs.filter { it.isFavorite }.take(8)
            HomeQuickFilter.LOSSLESS -> songs.filter { it.isLossless }.take(8)
            HomeQuickFilter.MOST_PLAYED -> songs.sortedByDescending { it.playCount }.take(8)
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Hero Welcome Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(vybe.surfaceCard)
            ) {
                Image(
                    painter = painterResource(
                        if (vybe.isRetro) R.drawable.img_hero_retro else R.drawable.img_hero_modern
                    ),
                    contentDescription = "VYBE Studio Hero Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Black.copy(alpha = 0.25f),
                                    Color.Black.copy(alpha = 0.85f)
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .padding(18.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = Color.Black.copy(alpha = 0.55f),
                            border = BorderStroke(1.dp, vybe.accentSecondary.copy(alpha = 0.6f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (playbackState.isPlaying) {
                                    AnimatedEqBars(
                                        isPlaying = true,
                                        color = vybe.accentSecondary,
                                        modifier = Modifier.size(width = 14.dp, height = 12.dp),
                                        barCount = 3
                                    )
                                } else {
                                    Icon(
                                        Icons.Filled.Speed,
                                        contentDescription = null,
                                        tint = vybe.accentSecondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Text(
                                    text = if (playbackState.isPlaying) {
                                        "PLAYING IN BG • ${displayRefreshInfo.currentRefreshRateHz.roundToInt()} Hz"
                                    } else {
                                        "${displayRefreshInfo.currentRefreshRateHz.roundToInt()} Hz • OFFLINE"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .testTag("home_theme_toggle_chip")
                                .clickable(onClick = onToggleThemeMode),
                            shape = RoundedCornerShape(50),
                            color = vybe.accentPrimary.copy(alpha = 0.85f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    if (vybe.isRetro) Icons.Filled.Radio else Icons.Filled.AutoAwesome,
                                    contentDescription = "Switch Theme",
                                    tint = if (vybe.isRetro) Color.Black else Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = vybe.themeMode.displayName.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (vybe.isRetro) Color.Black else Color.White
                                )
                            }
                        }
                    }

                    Column {
                        Text(
                            text = "VYBE",
                            style = MaterialTheme.typography.displaySmall,
                            color = Color.White
                        )
                        Text(
                            text = "Feel Every Beat • ${songs.size} Offline Tracks",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    if (playbackState.currentSong != null) onOpenNowPlaying()
                                    else if (songs.isNotEmpty()) onPlaySongs(songs, 0)
                                    else onOpenLibrary()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = vybe.accentSecondary,
                                    contentColor = Color(0xFF061320)
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("home_primary_play_btn")
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = if (playbackState.currentSong != null) "Open Player" else "Play All",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }

                            OutlinedButton(
                                onClick = onOpenThemeSheet,
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.55f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("home_customize_theme_btn")
                            ) {
                                Text("Customize", style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }
            }
        }

        // Frosted Filter Pills Strip (Additive Aurora / Glass library filter)
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(HomeQuickFilter.entries) { filter ->
                    val selected = activeFilter == filter
                    Surface(
                        modifier = Modifier
                            .clickable { activeFilter = filter }
                            .testTag("home_filter_${filter.name.lowercase()}"),
                        shape = RoundedCornerShape(50),
                        color = if (selected) vybe.accentPrimary.copy(alpha = 0.85f) else vybe.surfaceCard,
                        border = BorderStroke(
                            1.dp,
                            if (selected) vybe.accentSecondary else vybe.cardBorder
                        )
                    ) {
                        Text(
                            text = filter.label,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) Color.White else vybe.textPrimary,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                        )
                    }
                }
            }
        }

        // Filtered Quick Play List (shown when user picks a specific filter or has tracks)
        if (filteredQuickTracks.isNotEmpty() && activeFilter != HomeQuickFilter.ALL) {
            item {
                SectionHeader(activeFilter.label, "${filteredQuickTracks.size} tracks")
                Spacer(Modifier.height(8.dp))
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filteredQuickTracks.forEachIndexed { idx, song ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPlaySongs(filteredQuickTracks, idx) },
                            shape = RoundedCornerShape(16.dp),
                            color = vybe.surfaceCard,
                            border = BorderStroke(0.8.dp, vybe.cardBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                VybeArtwork(
                                    model = song.artworkModel,
                                    contentDescription = song.title,
                                    style = settings.artworkStyle,
                                    cornerRadius = 10.dp,
                                    modifier = Modifier.size(46.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = song.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = vybe.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${song.artist} • ${song.formatBadge}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = vybe.textMuted,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = TimeFormatter.formatDuration(song.durationMs),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = vybe.textMuted
                                )
                                Surface(
                                    shape = CircleShape,
                                    color = vybe.surfaceElevated,
                                    border = BorderStroke(1.dp, vybe.cardBorder)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PlayArrow,
                                        contentDescription = "Play ${song.title}",
                                        tint = vybe.accentSecondary,
                                        modifier = Modifier
                                            .padding(6.dp)
                                            .size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Studio Quick Actions Row
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    QuickStudioPill(
                        label = "Vinyl Mode",
                        icon = Icons.Filled.Album,
                        onClick = onOpenVinylMode,
                        modifier = Modifier.testTag("quick_vinyl_btn")
                    )
                }
                item {
                    QuickStudioPill(
                        label = "Equalizer",
                        icon = Icons.Filled.Equalizer,
                        onClick = onOpenEqualizer,
                        modifier = Modifier.testTag("quick_eq_btn")
                    )
                }
                item {
                    QuickStudioPill(
                        label = "Statistics",
                        icon = Icons.Filled.Analytics,
                        onClick = onOpenStats,
                        modifier = Modifier.testTag("quick_stats_btn")
                    )
                }
                item {
                    QuickStudioPill(
                        label = "Now Playing",
                        icon = Icons.Filled.GraphicEq,
                        onClick = onOpenNowPlaying,
                        modifier = Modifier.testTag("quick_now_playing_btn")
                    )
                }
            }
        }

        // Permission or Empty Library Helper
        if (!hasAudioPermission || songs.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(vybe.cardRadius),
                    color = vybe.surfaceCard,
                    border = BorderStroke(1.dp, vybe.accentPrimary.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = vybe.accentSecondary)
                            Text(
                                text = if (!hasAudioPermission) "Grant Local Audio Access" else "Your Offline Library is Ready",
                                style = MaterialTheme.typography.titleLarge,
                                color = vybe.textPrimary
                            )
                        }
                        Text(
                            text = if (!hasAudioPermission) {
                                "VYBE needs audio permission to scan MP3, FLAC, WAV, AAC, and OGG files stored on your device."
                            } else {
                                "No audio files were found on device storage yet. You can scan again or generate 3 lossless studio WAV tracks with LRC lyrics to experience every VYBE feature offline."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = vybe.textMuted
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (!hasAudioPermission) {
                                Button(
                                    onClick = onRequestAudioPermission,
                                    modifier = Modifier.testTag("grant_audio_permission_btn")
                                ) {
                                    Text("Allow & Scan")
                                }
                            }
                            OutlinedButton(
                                onClick = onCreateSampleTracks,
                                modifier = Modifier.testTag("generate_sample_tracks_btn")
                            ) {
                                Icon(Icons.Filled.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Add Studio WAV Samples")
                            }
                        }
                    }
                }
            }
        }

        // Recently Played
        if (recentlyPlayed.isNotEmpty()) {
            item {
                SectionHeader("Recently Played", "${recentlyPlayed.size} tracks")
                Spacer(Modifier.height(10.dp))
                HorizontalSongCards(
                    songs = recentlyPlayed,
                    settings = settings,
                    onPlaySong = { idx -> onPlaySongs(recentlyPlayed, idx) }
                )
            }
        }

        // Favorite Songs
        if (favorites.isNotEmpty()) {
            item {
                SectionHeader("Favorite Songs", "${favorites.size} loved", icon = Icons.Filled.Favorite)
                Spacer(Modifier.height(10.dp))
                HorizontalSongCards(
                    songs = favorites,
                    settings = settings,
                    onPlaySong = { idx -> onPlaySongs(favorites, idx) }
                )
            }
        }

        // Recently Added
        if (recentlyAdded.isNotEmpty()) {
            item {
                SectionHeader("Recently Added", "Fresh offline audio")
                Spacer(Modifier.height(10.dp))
                HorizontalSongCards(
                    songs = recentlyAdded,
                    settings = settings,
                    onPlaySong = { idx -> onPlaySongs(recentlyAdded, idx) }
                )
            }
        }

        // Popular Artists
        if (popularArtists.isNotEmpty()) {
            item {
                SectionHeader("Popular Artists", "${popularArtists.size} artists")
                Spacer(Modifier.height(10.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(popularArtists, key = { it.name }) { artist ->
                        Surface(
                            modifier = Modifier
                                .width(124.dp)
                                .clickable { onPlaySongs(artist.songs, 0) },
                            shape = RoundedCornerShape(vybe.cardRadius),
                            color = vybe.surfaceCard,
                            border = BorderStroke(0.8.dp, vybe.cardBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(vybe.surfaceElevated),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (artist.artworkModel != null) {
                                        VybeArtwork(
                                            model = artist.artworkModel,
                                            contentDescription = artist.name,
                                            cornerRadius = 32.dp,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Icon(Icons.Filled.Person, contentDescription = null, tint = vybe.accentSecondary)
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = artist.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = vybe.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${artist.trackCount} tracks",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = vybe.textMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // Recommended Playlists
        if (recommendedPlaylists.isNotEmpty()) {
            item {
                SectionHeader("Recommended Playlists", "Curated from your library")
                Spacer(Modifier.height(10.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(recommendedPlaylists, key = { "${it.isSmart}_${it.id}" }) { playlist ->
                        Surface(
                            modifier = Modifier
                                .width(168.dp)
                                .clickable { onOpenPlaylist(playlist) },
                            shape = RoundedCornerShape(vybe.cardRadius),
                            color = vybe.surfaceCard,
                            border = BorderStroke(0.8.dp, vybe.cardBorder)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Filled.QueueMusic,
                                        contentDescription = null,
                                        tint = vybe.accentSecondary
                                    )
                                    Text(
                                        text = if (playlist.isSmart) "SMART" else "MIX",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = vybe.accentPrimary
                                    )
                                }
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    text = playlist.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = vybe.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${playlist.songCount} songs",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = vybe.textMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickStudioPill(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = vybe.surfaceCard,
        border = BorderStroke(1.dp, vybe.cardBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(18.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, color = vybe.textPrimary)
        }
    }
}

@Composable
private fun SectionHeader(
    title: String,
    subtitle: String,
    icon: ImageVector? = null
) {
    val vybe = LocalVybeStyle.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(18.dp))
            }
            Text(title, style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
        }
        Text(subtitle, style = MaterialTheme.typography.labelMedium, color = vybe.textMuted)
    }
}

@Composable
private fun HorizontalSongCards(
    songs: List<Song>,
    settings: VybeSettings,
    onPlaySong: (Int) -> Unit
) {
    val vybe = LocalVybeStyle.current
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(songs.size, key = { idx -> songs[idx].id }) { idx ->
            val song = songs[idx]
            Surface(
                modifier = Modifier
                    .width(148.dp)
                    .clickable { onPlaySong(idx) },
                shape = RoundedCornerShape(vybe.cardRadius),
                color = vybe.surfaceCard,
                border = BorderStroke(0.8.dp, vybe.cardBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    VybeArtwork(
                        model = song.artworkModel,
                        contentDescription = song.title,
                        style = settings.artworkStyle,
                        cornerRadius = 12.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(124.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = song.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = vybe.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.artist,
                        style = MaterialTheme.typography.bodyMedium,
                        color = vybe.textMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
