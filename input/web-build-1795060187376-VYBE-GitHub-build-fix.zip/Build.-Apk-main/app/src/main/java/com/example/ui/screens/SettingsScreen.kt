package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.VybeSettings
import com.example.model.CrossfadeCurve
import com.example.model.DisplayRefreshInfo
import com.example.model.NavDockStyle
import com.example.model.PerformanceMode
import com.example.model.PlayerBackgroundStyle
import com.example.model.PlayerLayoutStyle
import com.example.model.VisualizerSize
import com.example.model.VisualizerStyle
import com.example.ui.StorageSummary
import com.example.ui.theme.LocalVybeStyle
import com.example.util.TimeFormatter
import com.example.util.rememberVybeHaptics
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    settings: VybeSettings,
    displayRefreshInfo: DisplayRefreshInfo,
    storageSummary: StorageSummary,
    onOpenThemeSheet: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onOpenStats: () -> Unit,
    onSetPerformanceMode: (PerformanceMode) -> Unit,
    onSetAnimationsEnabled: (Boolean) -> Unit,
    onSetPlayerBackground: (PlayerBackgroundStyle) -> Unit,
    onSetPlayerLayout: (PlayerLayoutStyle) -> Unit,
    onSetNavDockStyle: (NavDockStyle) -> Unit,
    onSetVisualizerEnabled: (Boolean) -> Unit,
    onSetVisualizerStyle: (VisualizerStyle) -> Unit,
    onSetVisualizerSize: (VisualizerSize) -> Unit,
    onSetVisualizerIntensity: (Float) -> Unit,
    onSetGapless: (Boolean) -> Unit,
    onSetCrossfadeMs: (Int) -> Unit,
    onSetFadeInOut: (Boolean) -> Unit,
    onSetAutoPauseDisconnect: (Boolean) -> Unit,
    onSetShowNotifications: (Boolean) -> Unit,
    onSetSkipSilence: (Boolean) -> Unit,
    onSetCrossfadeCurve: (CrossfadeCurve) -> Unit = {},
    onSetCrossfadeOnManualSkip: (Boolean) -> Unit = {},
    onSetHapticFeedback: (Boolean) -> Unit = {},
    onRefreshScan: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val haptics = rememberVybeHaptics(settings.hapticFeedbackEnabled)

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Settings", style = MaterialTheme.typography.headlineMedium, color = vybe.textPrimary)
            Text("Themes, 120Hz Engine, Audio DSP & Storage", style = MaterialTheme.typography.labelMedium, color = vybe.textMuted)
        }

        // Theme & Customization
        item {
            SettingsCard(title = "Theme & Appearance", icon = Icons.Filled.Palette) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "${vybe.themeMode.displayName} Mode",
                            style = MaterialTheme.typography.titleMedium,
                            color = vybe.textPrimary
                        )
                        Text(
                            "${settings.appearanceMode.name} • ${settings.accentPreset.displayName} • ${settings.playerLayoutStyle.displayName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = vybe.textMuted
                        )
                    }
                    OutlinedButton(onClick = onOpenThemeSheet, modifier = Modifier.testTag("settings_open_theme_btn")) {
                        Text("Customize")
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text("Now Playing Deck Layout", style = MaterialTheme.typography.labelLarge, color = vybe.textPrimary)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PlayerLayoutStyle.entries.forEach { layout ->
                        FilterChip(
                            selected = settings.playerLayoutStyle == layout,
                            onClick = { onSetPlayerLayout(layout) },
                            label = { Text(layout.displayName, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text("Player Background Style", style = MaterialTheme.typography.labelLarge, color = vybe.textPrimary)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PlayerBackgroundStyle.entries.forEach { bg ->
                        FilterChip(
                            selected = settings.playerBackgroundStyle == bg,
                            onClick = { onSetPlayerBackground(bg) },
                            label = { Text(bg.displayName, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text("Navigation Dock Style", style = MaterialTheme.typography.labelLarge, color = vybe.textPrimary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NavDockStyle.entries.forEach { dock ->
                        FilterChip(
                            selected = settings.navDockStyle == dock,
                            onClick = { onSetNavDockStyle(dock) },
                            label = { Text(dock.displayName, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Rich Micro-Animations", style = MaterialTheme.typography.bodyLarge, color = vybe.textPrimary)
                    Switch(checked = settings.animationsEnabled, onCheckedChange = onSetAnimationsEnabled)
                }
            }
        }

        // High Refresh Rate & Performance Mode (60Hz / 90Hz / 120Hz)
        item {
            SettingsCard(title = "High Refresh Rate & Performance", icon = Icons.Filled.Speed) {
                Text(
                    text = "Active Display: ${displayRefreshInfo.activeModeLabel} • Supported: ${
                        displayRefreshInfo.supportedRatesHz.joinToString(", ") { "${it.roundToInt()}Hz" }
                    }${if (displayRefreshInfo.isPowerSaveMode) " (Battery Saver Active)" else ""}",
                    style = MaterialTheme.typography.labelMedium,
                    color = vybe.accentSecondary
                )
                Spacer(Modifier.height(8.dp))
                PerformanceMode.entries.forEach { mode ->
                    val selected = settings.performanceMode == mode
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clickable { onSetPerformanceMode(mode) }
                            .testTag("perf_mode_${mode.name.lowercase()}"),
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) vybe.accentPrimary.copy(alpha = 0.2f) else vybe.surfaceElevated,
                        border = BorderStroke(1.dp, if (selected) vybe.accentSecondary else vybe.cardBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(mode.displayName, style = MaterialTheme.typography.titleMedium, color = if (selected) vybe.accentSecondary else vybe.textPrimary)
                            Text(mode.description, style = MaterialTheme.typography.bodyMedium, color = vybe.textMuted)
                        }
                    }
                }
            }
        }

        // Audio & Playback Settings
        item {
            SettingsCard(title = "Audio & Playback Engine", icon = Icons.Filled.Equalizer) {
                OutlinedButton(
                    onClick = onOpenEqualizer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open 10-Band Equalizer & Headphone Profiles")
                }
                Spacer(Modifier.height(8.dp))
                ToggleRow(
                    title = "Gapless Playback",
                    subtitle = "Seamless transitions for live & concept albums",
                    checked = settings.gaplessPlayback,
                    onCheckedChange = {
                        haptics.toggle()
                        onSetGapless(it)
                    }
                )
                ToggleRow(
                    title = "Skip Silence",
                    subtitle = "Trim extended quiet passages automatically",
                    checked = settings.skipSilenceEnabled,
                    onCheckedChange = {
                        haptics.toggle()
                        onSetSkipSilence(it)
                    }
                )
                ToggleRow(
                    title = "Fade In / Fade Out",
                    subtitle = "Smooth volume ramp on play & pause",
                    checked = settings.fadeInOutEnabled,
                    onCheckedChange = {
                        haptics.toggle()
                        onSetFadeInOut(it)
                    }
                )
                ToggleRow(
                    title = "Auto-Pause on Disconnect",
                    subtitle = "Pause when wired or Bluetooth headphones unplug",
                    checked = settings.autoPauseOnDisconnect,
                    onCheckedChange = {
                        haptics.toggle()
                        onSetAutoPauseDisconnect(it)
                    }
                )
                ToggleRow(
                    title = "Tactile Haptic Feedback",
                    subtitle = "Crisp vibration cues on playback, sliders & transitions",
                    checked = settings.hapticFeedbackEnabled,
                    onCheckedChange = { enabled ->
                        if (enabled) haptics.toggle()
                        onSetHapticFeedback(enabled)
                    },
                    switchTag = "settings_haptics_switch"
                )

                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Media3 Crossfade (${if (settings.crossfadeDurationMs == 0) "Off" else "${settings.crossfadeDurationMs / 1000}s"})",
                    style = MaterialTheme.typography.bodyLarge,
                    color = vybe.textPrimary
                )
                Text(
                    text = "Dual-engine overlapping blend eliminates pauses between tracks",
                    style = MaterialTheme.typography.bodySmall,
                    color = vybe.textMuted
                )
                Slider(
                    value = settings.crossfadeDurationMs.toFloat(),
                    onValueChange = { raw ->
                        val snapped = (raw / 1000f).roundToInt() * 1000
                        if (snapped != settings.crossfadeDurationMs) {
                            haptics.tick()
                            onSetCrossfadeMs(snapped)
                        }
                    },
                    valueRange = 0f..12000f,
                    steps = 11,
                    modifier = Modifier.testTag("settings_crossfade_slider")
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(0, 2000, 4000, 6000, 8000, 12000).forEach { ms ->
                        FilterChip(
                            selected = settings.crossfadeDurationMs == ms,
                            onClick = {
                                haptics.toggle()
                                onSetCrossfadeMs(ms)
                            },
                            label = {
                                Text(
                                    text = if (ms == 0) "Off" else "${ms / 1000}s",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            modifier = Modifier.testTag("settings_crossfade_preset_${ms / 1000}s")
                        )
                    }
                }

                Spacer(Modifier.height(4.dp))
                Text("Crossfade Curve", style = MaterialTheme.typography.labelLarge, color = vybe.textPrimary)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CrossfadeCurve.entries.forEach { curve ->
                        FilterChip(
                            selected = settings.crossfadeCurve == curve,
                            onClick = {
                                haptics.toggle()
                                onSetCrossfadeCurve(curve)
                            },
                            label = { Text(curve.displayName, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("settings_crossfade_curve_${curve.name.lowercase()}")
                        )
                    }
                }
                Text(
                    text = settings.crossfadeCurve.subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = vybe.textMuted
                )

                ToggleRow(
                    title = "Crossfade on Manual Skip",
                    subtitle = "Smoothly blend tracks when tapping Next or Previous",
                    checked = settings.crossfadeOnManualSkip,
                    onCheckedChange = {
                        haptics.toggle()
                        onSetCrossfadeOnManualSkip(it)
                    },
                    switchTag = "settings_crossfade_skip_switch"
                )
            }
        }

        // Visualizer Settings
        item {
            SettingsCard(title = "Audio Visualizer", icon = Icons.Filled.GraphicEq) {
                ToggleRow("Enable Now Playing Visualizer", "Real-time PCM/FFT audio reactivity", settings.visualizerEnabled, onSetVisualizerEnabled)
                Spacer(Modifier.height(6.dp))
                Text("Style", style = MaterialTheme.typography.labelLarge, color = vybe.textPrimary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    VisualizerStyle.entries.take(4).forEach { style ->
                        FilterChip(
                            selected = settings.visualizerStyle == style,
                            onClick = { onSetVisualizerStyle(style) },
                            label = { Text(style.displayName.substringBefore(" "), style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    VisualizerStyle.entries.drop(4).forEach { style ->
                        FilterChip(
                            selected = settings.visualizerStyle == style,
                            onClick = { onSetVisualizerStyle(style) },
                            label = { Text(style.displayName.substringBefore(" "), style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Text("Visualizer Size", style = MaterialTheme.typography.labelLarge, color = vybe.textPrimary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VisualizerSize.entries.forEach { sz ->
                        FilterChip(
                            selected = settings.visualizerSize == sz,
                            onClick = { onSetVisualizerSize(sz) },
                            label = { Text(sz.displayName) }
                        )
                    }
                }

                Text("Sensitivity (${(settings.visualizerIntensity * 100).roundToInt()}%)", style = MaterialTheme.typography.bodyMedium, color = vybe.textPrimary)
                Slider(
                    value = settings.visualizerIntensity,
                    onValueChange = onSetVisualizerIntensity,
                    valueRange = 0.4f..2.0f
                )
            }
        }

        // Library, Notifications & Stats
        item {
            SettingsCard(title = "Library, Storage & Stats", icon = Icons.Filled.Storage) {
                Text(
                    "Tracks: ${storageSummary.trackCount} (${storageSummary.losslessCount} lossless) • Library Size: ${TimeFormatter.formatFileSize(storageSummary.totalLibraryBytes)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = vybe.textPrimary
                )
                Text(
                    "Device Free Storage: ${TimeFormatter.formatFileSize(storageSummary.availableDeviceBytes)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = vybe.textMuted
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onRefreshScan, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Rescan Audio")
                    }
                    OutlinedButton(onClick = onOpenStats, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Analytics, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("View Stats")
                    }
                }
                Spacer(Modifier.height(6.dp))
                ToggleRow("Media Notification Controls", "Lock-screen & shade playback controls", settings.showNotifications, onSetShowNotifications)
            }
        }

        // About & Offline Privacy
        item {
            SettingsCard(title = "About VYBE & Privacy", icon = Icons.Filled.Security) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Info, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(18.dp))
                    Text("VYBE v1.0 • Feel Every Beat.", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "100% Offline Music Player. Your music library, playlists, lyrics, EQ presets, and listening statistics are stored strictly on your device with zero accounts, zero subscriptions, and zero telemetry.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = vybe.textMuted
                )
            }
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    val vybe = LocalVybeStyle.current
    Surface(
        shape = RoundedCornerShape(vybe.cardRadius),
        color = vybe.surfaceCard,
        border = BorderStroke(0.8.dp, vybe.cardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(icon, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(20.dp))
                Text(title, style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
            }
            Spacer(Modifier.height(4.dp))
            content()
        }
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    switchTag: String? = null
) {
    val vybe = LocalVybeStyle.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = vybe.textPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = vybe.textMuted)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = if (switchTag != null) Modifier.testTag(switchTag) else Modifier
        )
    }
}
