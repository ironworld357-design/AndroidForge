package com.example.ui.navigation

import kotlinx.serialization.Serializable

sealed interface VybeRoute {
    @Serializable data object Home : VybeRoute
    @Serializable data object Library : VybeRoute
    @Serializable data object Playlists : VybeRoute
    @Serializable data object Guitar : VybeRoute
    @Serializable data object Settings : VybeRoute
    @Serializable data object NowPlaying : VybeRoute
    @Serializable data object VinylMode : VybeRoute
    @Serializable data object Equalizer : VybeRoute
    @Serializable data object Lyrics : VybeRoute
    @Serializable data object Stats : VybeRoute
}
