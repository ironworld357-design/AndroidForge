package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun AnimatedEqBars(
    isPlaying: Boolean,
    color: Color,
    modifier: Modifier = Modifier.size(18.dp),
    barCount: Int = 3
) {
    var phase by remember { mutableFloatStateOf(0f) }
    var energy by remember { mutableFloatStateOf(if (isPlaying) 1f else 0.25f) }

    LaunchedEffect(isPlaying) {
        var lastNs = 0L
        while (true) {
            withFrameNanos { nowNs ->
                if (lastNs == 0L) lastNs = nowNs
                val dt = ((nowNs - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastNs = nowNs

                val targetEnergy = if (isPlaying) 1f else 0.28f
                energy += (targetEnergy - energy) * (dt * 8f).coerceIn(0f, 1f)
                if (isPlaying || energy > 0.30f) {
                    phase = (phase + dt * 7.5f) % (2f * PI.toFloat())
                }
            }
            if (!isPlaying && energy <= 0.30f) {
                delay(160L)
            }
        }
    }

    Canvas(modifier = modifier) {
        val gap = size.width * 0.16f
        val totalGaps = gap * (barCount - 1)
        val barWidth = ((size.width - totalGaps) / barCount).coerceAtLeast(2.dp.toPx())
        val radius = CornerRadius(barWidth / 2f, barWidth / 2f)

        for (i in 0 until barCount) {
            val wave = 0.5f + 0.5f * sin(phase + i * 1.45f)
            val heightFrac = (0.22f + wave * 0.78f * energy).coerceIn(0.18f, 1f)
            val barH = size.height * heightFrac
            val x = i * (barWidth + gap)
            drawRoundRect(
                color = color,
                topLeft = Offset(x, size.height - barH),
                size = Size(barWidth, barH),
                cornerRadius = radius
            )
        }
    }
}
