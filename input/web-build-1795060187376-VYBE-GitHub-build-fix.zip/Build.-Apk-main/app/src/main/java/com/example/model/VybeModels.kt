package com.example.model

import androidx.compose.ui.graphics.Color
import kotlinx.serialization.Serializable

enum class VybeThemeMode(val displayName: String, val tagline: String) {
    MODERN("Modern Pro", "Obsidian • Violet • Electric Blue"),
    RETRO("Retro Cassette", "Analog Reels • Warm Amber"),
    AURORA_GLASS("Aurora Glass", "Frosted Mesh • Lavender Mist"),
    LIQUID_SMOKE("Liquid Smoke", "Smoked Slate • Fluted Frost"),
    HALO_ORCHID("Halo Orchid", "Orchid Glow • Midnight Rings")
}

enum class AppearanceMode {
    DARK,
    OLED_BLACK,
    LIGHT
}

enum class AccentPreset(
    val displayName: String,
    val primaryHex: Long,
    val secondaryHex: Long
) {
    ELECTRIC_VIOLET("Electric Violet", 0xFF8B5CF6, 0xFF38BDF8),
    CYAN_PULSE("Cyan Pulse", 0xFF00D4FF, 0xFF6366F1),
    PLASMA_MAGENTA("Plasma Magenta", 0xFFE879F9, 0xFF8B5CF6),
    AMBER_ANALOG("Amber Analog", 0xFFF59E0B, 0xFFEA580C),
    EMERALD_STUDIO("Emerald Studio", 0xFF10B981, 0xFF38BDF8),
    AURORA_LAVENDER("Aurora Lavender", 0xFFA78BFA, 0xFF7DD3FC),
    ORCHID_NEBULA("Orchid Nebula", 0xFFD946EF, 0xFF818CF8),
    LIQUID_SILVER("Liquid Silver", 0xFFC4B5FD, 0xFFE2E8F0);

    val primaryColor: Color get() = Color(primaryHex)
    val secondaryColor: Color get() = Color(secondaryHex)
}

enum class ArtworkStyle(val displayName: String) {
    ROUNDED_CARD("Rounded Card"),
    VINYL_DISC("Vinyl Disc"),
    GLASS_FRAME("Glass Frame"),
    RETRO_LABEL("Retro Tape Label"),
    RIBBED_GLASS("Ribbed Frost"),
    HALO_RING("Halo Ring"),
    AURORA_COVERFLOW("Aurora Glow")
}

enum class PlayerBackgroundStyle(val displayName: String) {
    DYNAMIC_GRADIENT("Dynamic Gradient"),
    PURE_BLACK("OLED Pure Black"),
    ARTWORK_GLOW("Artwork Glow"),
    AURORA_MESH("Aurora Mesh"),
    FROSTED_FULL_BLEED("Full-Bleed Blur")
}

enum class PlayerLayoutStyle(val displayName: String, val subtitle: String) {
    CLASSIC("Classic Studio", "Album sleeve with spinning vinyl disc"),
    VINYL_RECORD("Vinyl Record", "Spinning 33⅓ RPM disc & tonearm"),
    ORBITAL_ARC("Orbital Arc", "Full-bleed art with curved plasma arc"),
    HALO_CAROUSEL("Halo Carousel", "Circular ring progress & disc peek"),
    WAVEFORM_COVERFLOW("Wave Coverflow", "Interactive soundwave & cover peek")
}

enum class NavDockStyle(val displayName: String) {
    STANDARD_BAR("Classic Dock"),
    FLOATING_GLASS_PILL("Floating Pill Dock")
}

enum class VisualizerStyle(val displayName: String) {
    SPECTRUM_ANALYZER("Spectrum Analyzer"),
    WAVEFORM("Waveform"),
    CIRCULAR("Circular Radial"),
    FREQUENCY_BARS("Symmetrical Bars"),
    NEON_PARTICLES("Neon Particles"),
    AUDIO_RINGS("Audio-Reactive Rings"),
    RETRO_ANALOG("Retro Analog VU"),
    MINIMAL_WAVE("Minimal Waveform")
}

enum class VisualizerSize(val displayName: String, val heightDp: Int) {
    COMPACT("Compact", 80),
    MEDIUM("Medium", 136),
    EXPANDED("Expanded", 200)
}

enum class PerformanceMode(val displayName: String, val description: String) {
    AUTO("Auto Mode", "Adapts smoothly to device refresh rate & battery saver"),
    BALANCED("Balanced Mode", "Prioritizes battery efficiency with steady 60 FPS cap"),
    HIGH_REFRESH("High Refresh Rate", "Targets 90Hz / 120Hz / max supported display rate")
}

enum class SongSortOrder(val displayName: String) {
    TITLE("Name"),
    ARTIST("Artist"),
    ALBUM("Album"),
    DURATION("Duration"),
    DATE_ADDED("Date Added")
}

enum class RepeatMode {
    OFF,
    ALL,
    ONE
}

enum class CrossfadeCurve(val displayName: String, val subtitle: String) {
    EQUAL_POWER("Equal Power", "Constant loudness cosine/sine curve"),
    SMOOTH_S_CURVE("Smooth S-Curve", "Cinematic ease-in & ease-out"),
    LINEAR("Linear", "Constant-rate linear fade")
}

object CrossfadeMath {
    fun computeGains(progress: Float, curve: CrossfadeCurve): Pair<Float, Float> {
        val t = progress.coerceIn(0f, 1f)
        return when (curve) {
            CrossfadeCurve.EQUAL_POWER -> {
                val angle = t * (Math.PI / 2.0)
                kotlin.math.cos(angle).toFloat().coerceIn(0f, 1f) to
                    kotlin.math.sin(angle).toFloat().coerceIn(0f, 1f)
            }
            CrossfadeCurve.SMOOTH_S_CURVE -> {
                val smooth = t * t * (3f - 2f * t)
                (1f - smooth).coerceIn(0f, 1f) to smooth.coerceIn(0f, 1f)
            }
            CrossfadeCurve.LINEAR -> {
                (1f - t).coerceIn(0f, 1f) to t
            }
        }
    }
}

enum class HeadphoneProfile(
    val displayName: String,
    val description: String,
    val bandOffsetsDb: List<Float>,
    val bassBoost: Int,
    val virtualizer: Int
) {
    NEUTRAL("Neutral Studio", "Flat reference response", listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f), 0, 0),
    OVER_EAR("Over-Ear Warm", "Lush mids & airy treble", listOf(2f, 2.5f, 1.5f, 0f, -0.5f, 0.5f, 1.5f, 2f, 2.5f, 1.5f), 250, 350),
    IEM_CLARITY("IEM Precision", "Crisp vocal & transient detail", listOf(1f, 0.5f, 0f, 0f, 1f, 2f, 2.5f, 2f, 1.5f, 1f), 150, 200),
    BASS_EXCURSION("Sub-Bass Excursion", "Deep sub impact without mud", listOf(5f, 4.5f, 3f, 0.5f, -1f, 0f, 1f, 1.5f, 1f, 0.5f), 650, 250),
    BLUETOOTH_SAFE("Bluetooth Balanced", "Compensates AAC/SBC rolloff", listOf(2f, 1.5f, 0.5f, 0f, 0.5f, 1.5f, 2f, 2.5f, 3f, 2.5f), 200, 300)
}

@Serializable
data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val contentUri: String,
    val filePath: String,
    val folderName: String,
    val folderPath: String,
    val genre: String,
    val dateAddedSec: Long,
    val sizeBytes: Long,
    val mimeType: String,
    val bitrateKbps: Int = 0,
    val sampleRateHz: Int = 0,
    val customArtworkUri: String? = null,
    val isFavorite: Boolean = false,
    val playCount: Int = 0,
    val lastPlayedAt: Long = 0L,
    val isDeleted: Boolean = false,
    val deletedAt: Long = 0L
) {
    val formatBadge: String
        get() {
            val lowerPath = filePath.lowercase()
            val lowerMime = mimeType.lowercase()
            return when {
                lowerMime.contains("flac") || lowerPath.endsWith(".flac") -> "FLAC"
                lowerMime.contains("wav") || lowerPath.endsWith(".wav") -> "WAV"
                lowerMime.contains("alac") || lowerPath.endsWith(".alac") -> "ALAC"
                lowerMime.contains("ogg") || lowerPath.endsWith(".ogg") -> "OGG"
                lowerMime.contains("opus") || lowerPath.endsWith(".opus") -> "OPUS"
                lowerMime.contains("aac") || lowerPath.endsWith(".aac") || lowerPath.endsWith(".m4a") -> "AAC"
                lowerMime.contains("mpeg") || lowerPath.endsWith(".mp3") -> "MP3"
                else -> "AUDIO"
            }
        }

    val isLossless: Boolean
        get() = formatBadge in setOf("FLAC", "WAV", "ALAC")

    val artworkModel: Any
        get() = customArtworkUri ?: "content://media/external/audio/albumart/$albumId"
}

data class AlbumGroup(
    val albumId: Long,
    val name: String,
    val artist: String,
    val songs: List<Song>
) {
    val trackCount: Int get() = songs.size
    val totalDurationMs: Long get() = songs.sumOf { it.durationMs }
    val artworkModel: Any? get() = songs.firstOrNull()?.artworkModel
}

data class ArtistGroup(
    val name: String,
    val songs: List<Song>,
    val albumCount: Int
) {
    val trackCount: Int get() = songs.size
    val artworkModel: Any? get() = songs.firstOrNull()?.artworkModel
}

data class FolderGroup(
    val folderName: String,
    val folderPath: String,
    val songs: List<Song>
)

data class GenreGroup(
    val name: String,
    val songs: List<Song>
)

data class Playlist(
    val id: Long,
    val name: String,
    val customArtworkUri: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val songs: List<Song> = emptyList(),
    val isSmart: Boolean = false,
    val smartType: SmartPlaylistType? = null
) {
    val songCount: Int get() = songs.size
    val totalDurationMs: Long get() = songs.sumOf { it.durationMs }
}

enum class SmartPlaylistType {
    FAVORITES,
    RECENTLY_PLAYED,
    MOST_PLAYED,
    RECENTLY_ADDED,
    LOSSLESS_HIFI
}

data class EqPreset(
    val id: String,
    val name: String,
    val bandLevelsDb: List<Float>, // 10 bands: 31, 62, 125, 250, 500, 1k, 2k, 4k, 8k, 16k
    val isCustom: Boolean = false
)

data class LyricLine(
    val timestampMs: Long?,
    val text: String
)

data class LyricsData(
    val songId: Long,
    val rawText: String,
    val lines: List<LyricLine>,
    val isSynchronized: Boolean,
    val sourceLabel: String,
    val offsetMs: Long = 0L,
    val metadataTitle: String? = null,
    val metadataArtist: String? = null
)

data class DuplicateGroup(
    val key: String,
    val songs: List<Song>
)

data class AudioOutputInfo(
    val deviceName: String,
    val deviceTypeLabel: String,
    val isWiredHeadset: Boolean,
    val isBluetooth: Boolean
)

data class ListeningStatSummary(
    val totalSongsPlayed: Int,
    val totalListeningMs: Long,
    val dailyMinutes: List<Pair<String, Float>>,
    val weeklyMinutes: List<Pair<String, Float>>,
    val monthlyMinutes: List<Pair<String, Float>>,
    val topSongs: List<Song>,
    val topArtists: List<Pair<String, Int>>
)

data class DisplayRefreshInfo(
    val currentRefreshRateHz: Float,
    val supportedRatesHz: List<Float>,
    val isPowerSaveMode: Boolean,
    val activeModeLabel: String
)
