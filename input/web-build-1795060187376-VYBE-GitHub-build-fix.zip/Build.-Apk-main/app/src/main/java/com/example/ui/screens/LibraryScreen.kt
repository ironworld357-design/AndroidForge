package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FileCopy
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOff
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.audio.PlaybackUiState
import com.example.data.local.ExcludedFolderEntity
import com.example.data.local.VybeSettings
import com.example.model.AlbumGroup
import com.example.model.ArtistGroup
import com.example.model.DuplicateGroup
import com.example.model.FolderGroup
import com.example.model.GenreGroup
import com.example.model.Playlist
import com.example.model.Song
import com.example.model.SongSortOrder
import com.example.ui.components.SongRowItem
import com.example.ui.components.VybeArtwork
import com.example.ui.theme.LocalVybeStyle
import com.example.util.TimeFormatter

private enum class LibraryTab(val title: String) {
    SONGS("Songs"),
    ALBUMS("Albums"),
    ARTISTS("Artists"),
    FOLDERS("Folders"),
    GENRES("Genres"),
    FAVORITES("Favorites"),
    RECENT("Recent"),
    MOST_PLAYED("Most Played")
}

@Composable
fun LibraryScreen(
    songs: List<Song>,
    albums: List<AlbumGroup>,
    artists: List<ArtistGroup>,
    folders: List<FolderGroup>,
    genres: List<GenreGroup>,
    deletedSongs: List<Song>,
    excludedFolders: List<ExcludedFolderEntity>,
    customPlaylists: List<Playlist>,
    searchQuery: String,
    isScanning: Boolean,
    playbackState: PlaybackUiState,
    settings: VybeSettings,
    onSearchChange: (String) -> Unit,
    onUpdateSort: (SongSortOrder, Boolean) -> Unit,
    onRefreshScan: () -> Unit,
    onCreateSamples: () -> Unit,
    onPlaySongs: (List<Song>, Int) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onAddSongToPlaylist: (Long, Long) -> Unit,
    onCreatePlaylistWithSong: (String, Long) -> Unit,
    onUpdateMetadata: (Long, String, String, String, String?) -> Unit,
    onShareSong: (Song) -> Unit,
    onMoveToTrash: (Song) -> Unit,
    onRestoreSong: (Song) -> Unit,
    onDetectDuplicates: () -> List<DuplicateGroup>,
    onExcludeFolder: (FolderGroup) -> Unit,
    onIncludeFolder: (ExcludedFolderEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var sortMenuOpen by remember { mutableStateOf(false) }

    // Drill-down group sheet/view
    var activeGroupTitle by remember { mutableStateOf<String?>(null) }
    var activeGroupSongs by remember { mutableStateOf<List<Song>>(emptyList()) }

    // Management dialogs
    var editingSong by remember { mutableStateOf<Song?>(null) }
    var playlistPickerSong by remember { mutableStateOf<Song?>(null) }
    var showTrashDialog by remember { mutableStateOf(false) }
    var showDuplicatesDialog by remember { mutableStateOf(false) }
    var duplicateGroups by remember { mutableStateOf<List<DuplicateGroup>>(emptyList()) }
    var showExcludedDialog by remember { mutableStateOf(false) }

    val favoriteSongs = remember(songs) { songs.filter { it.isFavorite } }
    val recentSongs = remember(songs) { songs.sortedByDescending { it.dateAddedSec } }
    val mostPlayedSongs = remember(songs) { songs.filter { it.playCount > 0 }.sortedByDescending { it.playCount } }

    Column(modifier = modifier.fillMaxSize()) {
        // Header + Search + Sort + Tools
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Music Library", style = MaterialTheme.typography.headlineMedium, color = vybe.textPrimary)
                    Text(
                        text = if (isScanning) "Scanning local storage..." else "${songs.size} offline tracks",
                        style = MaterialTheme.typography.labelMedium,
                        color = vybe.textMuted
                    )
                }
                Row {
                    IconButton(onClick = onRefreshScan, modifier = Modifier.testTag("library_scan_btn")) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh library", tint = vybe.accentSecondary)
                    }
                    Box {
                        IconButton(onClick = { sortMenuOpen = true }, modifier = Modifier.testTag("library_sort_btn")) {
                            Icon(Icons.Filled.Sort, contentDescription = "Sort songs", tint = vybe.textPrimary)
                        }
                        DropdownMenu(
                            expanded = sortMenuOpen,
                            onDismissRequest = { sortMenuOpen = false },
                            containerColor = vybe.surfaceElevated
                        ) {
                            SongSortOrder.entries.forEach { order ->
                                val selected = settings.sortOrder == order
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                order.displayName,
                                                color = if (selected) vybe.accentSecondary else vybe.textPrimary
                                            )
                                            if (selected) {
                                                Spacer(Modifier.width(8.dp))
                                                Icon(
                                                    if (settings.sortAscending) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward,
                                                    contentDescription = null,
                                                    tint = vybe.accentSecondary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    },
                                    onClick = {
                                        val nextAsc = if (selected) !settings.sortAscending else true
                                        onUpdateSort(order, nextAsc)
                                        sortMenuOpen = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("library_search_input"),
                singleLine = true,
                placeholder = { Text("Search tracks, artists, albums, genres...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear search")
                        }
                    }
                },
                shape = RoundedCornerShape(14.dp)
            )

            // Library Management Quick Actions
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    OutlinedButton(
                        onClick = {
                            duplicateGroups = onDetectDuplicates()
                            showDuplicatesDialog = true
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Filled.FileCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Duplicates", style = MaterialTheme.typography.labelMedium)
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { showTrashDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Deleted (${deletedSongs.size})", style = MaterialTheme.typography.labelMedium)
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { showExcludedDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Filled.FolderOff, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Excluded (${excludedFolders.size})", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            // Category Chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(LibraryTab.entries) { idx, tab ->
                    FilterChip(
                        selected = selectedTabIndex == idx,
                        onClick = {
                            selectedTabIndex = idx
                            activeGroupTitle = null
                        },
                        label = { Text(tab.title) }
                    )
                }
            }
        }

        // Drill-down Header when inside an Album / Artist / Folder / Genre
        if (activeGroupTitle != null) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = vybe.surfaceElevated
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(activeGroupTitle!!, style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                        Text("${activeGroupSongs.size} tracks", style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                    }
                    TextButton(onClick = { onPlaySongs(activeGroupSongs, 0) }) { Text("Play All") }
                    TextButton(onClick = { activeGroupTitle = null }) { Text("Back") }
                }
            }
        }

        val currentTab = LibraryTab.entries[selectedTabIndex]

        if (activeGroupTitle != null) {
            SongListSection(
                list = activeGroupSongs,
                playbackState = playbackState,
                settings = settings,
                onPlay = { idx -> onPlaySongs(activeGroupSongs, idx) },
                onToggleFavorite = onToggleFavorite,
                onPlayNext = onPlayNext,
                onAddToQueue = onAddToQueue,
                onAddToPlaylist = { playlistPickerSong = it },
                onEditMetadata = { editingSong = it },
                onShare = onShareSong,
                onMoveToTrash = onMoveToTrash
            )
        } else {
            when (currentTab) {
                LibraryTab.SONGS -> {
                    if (songs.isEmpty()) {
                        EmptyLibraryNotice(onRefreshScan = onRefreshScan, onCreateSamples = onCreateSamples)
                    } else {
                        SongListSection(
                            list = songs,
                            playbackState = playbackState,
                            settings = settings,
                            onPlay = { idx -> onPlaySongs(songs, idx) },
                            onToggleFavorite = onToggleFavorite,
                            onPlayNext = onPlayNext,
                            onAddToQueue = onAddToQueue,
                            onAddToPlaylist = { playlistPickerSong = it },
                            onEditMetadata = { editingSong = it },
                            onShare = onShareSong,
                            onMoveToTrash = onMoveToTrash
                        )
                    }
                }

                LibraryTab.FAVORITES -> SongListSection(
                    list = favoriteSongs,
                    playbackState = playbackState,
                    settings = settings,
                    onPlay = { idx -> onPlaySongs(favoriteSongs, idx) },
                    onToggleFavorite = onToggleFavorite,
                    onPlayNext = onPlayNext,
                    onAddToQueue = onAddToQueue,
                    onAddToPlaylist = { playlistPickerSong = it },
                    onEditMetadata = { editingSong = it },
                    onShare = onShareSong,
                    onMoveToTrash = onMoveToTrash
                )

                LibraryTab.RECENT -> SongListSection(
                    list = recentSongs,
                    playbackState = playbackState,
                    settings = settings,
                    onPlay = { idx -> onPlaySongs(recentSongs, idx) },
                    onToggleFavorite = onToggleFavorite,
                    onPlayNext = onPlayNext,
                    onAddToQueue = onAddToQueue,
                    onAddToPlaylist = { playlistPickerSong = it },
                    onEditMetadata = { editingSong = it },
                    onShare = onShareSong,
                    onMoveToTrash = onMoveToTrash
                )

                LibraryTab.MOST_PLAYED -> SongListSection(
                    list = mostPlayedSongs,
                    playbackState = playbackState,
                    settings = settings,
                    onPlay = { idx -> onPlaySongs(mostPlayedSongs, idx) },
                    onToggleFavorite = onToggleFavorite,
                    onPlayNext = onPlayNext,
                    onAddToQueue = onAddToQueue,
                    onAddToPlaylist = { playlistPickerSong = it },
                    onEditMetadata = { editingSong = it },
                    onShare = onShareSong,
                    onMoveToTrash = onMoveToTrash
                )

                LibraryTab.ALBUMS -> LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(albums, key = { "${it.albumId}_${it.name}" }) { album ->
                        GroupRowCard(
                            title = album.name,
                            subtitle = "${album.artist} • ${album.trackCount} tracks",
                            artworkModel = album.artworkModel,
                            icon = Icons.Filled.Album,
                            onClick = {
                                activeGroupTitle = album.name
                                activeGroupSongs = album.songs
                            }
                        )
                    }
                }

                LibraryTab.ARTISTS -> LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(artists, key = { it.name }) { artist ->
                        GroupRowCard(
                            title = artist.name,
                            subtitle = "${artist.albumCount} albums • ${artist.trackCount} tracks",
                            artworkModel = artist.artworkModel,
                            icon = Icons.Filled.Person,
                            onClick = {
                                activeGroupTitle = artist.name
                                activeGroupSongs = artist.songs
                            }
                        )
                    }
                }

                LibraryTab.FOLDERS -> LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(folders, key = { it.folderPath }) { folder ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    activeGroupTitle = folder.folderName
                                    activeGroupSongs = folder.songs
                                },
                            shape = RoundedCornerShape(vybe.cardRadius * 0.75f),
                            color = vybe.surfaceCard,
                            border = BorderStroke(0.8.dp, vybe.cardBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.Folder, contentDescription = null, tint = vybe.accentSecondary)
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(folder.folderName, style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                                    Text("${folder.songs.size} tracks • ${folder.folderPath}", style = MaterialTheme.typography.labelSmall, color = vybe.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                IconButton(onClick = { onExcludeFolder(folder) }) {
                                    Icon(Icons.Filled.FolderOff, contentDescription = "Exclude folder", tint = vybe.textMuted)
                                }
                            }
                        }
                    }
                }

                LibraryTab.GENRES -> LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(genres, key = { it.name }) { genre ->
                        GroupRowCard(
                            title = genre.name,
                            subtitle = "${genre.songs.size} tracks",
                            artworkModel = genre.songs.firstOrNull()?.artworkModel,
                            icon = Icons.Filled.LibraryMusic,
                            onClick = {
                                activeGroupTitle = genre.name
                                activeGroupSongs = genre.songs
                            }
                        )
                    }
                }
            }
        }
    }

    // Metadata & Custom Artwork Editor Dialog (uses Zero-Permission Android Photo Picker!)
    editingSong?.let { target ->
        EditSongMetadataDialog(
            song = target,
            onDismiss = { editingSong = null },
            onSave = { title, artist, album, artUri ->
                onUpdateMetadata(target.id, title, artist, album, artUri)
                editingSong = null
            }
        )
    }

    // Add to Playlist Dialog
    playlistPickerSong?.let { target ->
        var newPlName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { playlistPickerSong = null },
            title = { Text("Add to Playlist") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(target.title, style = MaterialTheme.typography.labelMedium, color = vybe.accentSecondary)
                    customPlaylists.forEach { pl ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onAddSongToPlaylist(pl.id, target.id)
                                    playlistPickerSong = null
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = vybe.surfaceElevated
                        ) {
                            Text(
                                "${pl.name} (${pl.songCount})",
                                modifier = Modifier.padding(12.dp),
                                color = vybe.textPrimary
                            )
                        }
                    }
                    OutlinedTextField(
                        value = newPlName,
                        onValueChange = { newPlName = it },
                        label = { Text("Or create new playlist") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPlName.isNotBlank()) {
                            onCreatePlaylistWithSong(newPlName, target.id)
                            playlistPickerSong = null
                        }
                    }
                ) { Text("Create & Add") }
            },
            dismissButton = {
                TextButton(onClick = { playlistPickerSong = null }) { Text("Cancel") }
            }
        )
    }

    // Recently Deleted Dialog
    if (showTrashDialog) {
        AlertDialog(
            onDismissRequest = { showTrashDialog = false },
            title = { Text("Recently Deleted") },
            text = {
                if (deletedSongs.isEmpty()) {
                    Text("No deleted tracks. Original device files are never removed automatically.")
                } else {
                    LazyColumn(
                        modifier = Modifier.height(260.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(deletedSongs, key = { it.id }) { song ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(song.artist, style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                                }
                                IconButton(onClick = { onRestoreSong(song) }) {
                                    Icon(Icons.Filled.RestoreFromTrash, contentDescription = "Restore", tint = vybe.accentSecondary)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTrashDialog = false }) { Text("Close") }
            }
        )
    }

    // Duplicates Dialog
    if (showDuplicatesDialog) {
        AlertDialog(
            onDismissRequest = { showDuplicatesDialog = false },
            title = { Text("Duplicate Tracks (${duplicateGroups.size})") },
            text = {
                if (duplicateGroups.isEmpty()) {
                    Text("No duplicate songs detected in your offline library.")
                } else {
                    LazyColumn(
                        modifier = Modifier.height(280.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(duplicateGroups, key = { it.key }) { group ->
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    group.songs.first().title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = vybe.accentSecondary
                                )
                                group.songs.forEach { copy ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "${copy.formatBadge} • ${TimeFormatter.formatFileSize(copy.sizeBytes)} • ${copy.folderName}",
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.weight(1f)
                                        )
                                        TextButton(onClick = {
                                            onMoveToTrash(copy)
                                            duplicateGroups = onDetectDuplicates()
                                        }) {
                                            Text("Hide")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDuplicatesDialog = false }) { Text("Done") }
            }
        )
    }

    // Excluded Folders Dialog
    if (showExcludedDialog) {
        AlertDialog(
            onDismissRequest = { showExcludedDialog = false },
            title = { Text("Excluded Folders") },
            text = {
                if (excludedFolders.isEmpty()) {
                    Text("No folders excluded. Tap the folder-off icon in Folders tab to exclude any folder.")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        excludedFolders.forEach { folder ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(folder.folderName, modifier = Modifier.weight(1f))
                                TextButton(onClick = { onIncludeFolder(folder) }) { Text("Restore") }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showExcludedDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun SongListSection(
    list: List<Song>,
    playbackState: PlaybackUiState,
    settings: VybeSettings,
    onPlay: (Int) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onEditMetadata: (Song) -> Unit,
    onShare: (Song) -> Unit,
    onMoveToTrash: (Song) -> Unit
) {
    if (list.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No tracks in this category yet.", style = MaterialTheme.typography.bodyLarge, color = LocalVybeStyle.current.textMuted)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(list, key = { _, s -> s.id }) { idx, song ->
            SongRowItem(
                song = song,
                isCurrent = playbackState.currentSong?.id == song.id,
                isPlaying = playbackState.isPlaying,
                artworkStyle = settings.artworkStyle,
                onClick = { onPlay(idx) },
                onToggleFavorite = { onToggleFavorite(song) },
                onPlayNext = { onPlayNext(song) },
                onAddToQueue = { onAddToQueue(song) },
                onAddToPlaylist = { onAddToPlaylist(song) },
                onEditMetadata = { onEditMetadata(song) },
                onShare = { onShare(song) },
                onMoveToTrash = { onMoveToTrash(song) }
            )
        }
    }
}

@Composable
private fun GroupRowCard(
    title: String,
    subtitle: String,
    artworkModel: Any?,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    val vybe = LocalVybeStyle.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(vybe.cardRadius * 0.75f),
        color = vybe.surfaceCard,
        border = BorderStroke(0.8.dp, vybe.cardBorder)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (artworkModel != null) {
                VybeArtwork(
                    model = artworkModel,
                    contentDescription = title,
                    cornerRadius = 10.dp,
                    modifier = Modifier.size(52.dp)
                )
            } else {
                Icon(icon, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = vybe.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun EmptyLibraryNotice(
    onRefreshScan: () -> Unit,
    onCreateSamples: () -> Unit
) {
    val vybe = LocalVybeStyle.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Filled.LibraryMusic, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(52.dp))
            Text("No Local Audio Found", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
            Text(
                "Add MP3, FLAC, WAV, AAC, or OGG files to your device, or generate built-in studio WAV samples to test offline playback.",
                style = MaterialTheme.typography.bodyMedium,
                color = vybe.textMuted
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onRefreshScan) { Text("Rescan") }
                Button(onClick = onCreateSamples) { Text("Add Studio WAVs") }
            }
        }
    }
}

@Composable
private fun EditSongMetadataDialog(
    song: Song,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String?) -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(song.title) }
    var artist by remember { mutableStateOf(song.artist) }
    var album by remember { mutableStateOf(song.album) }
    var customArtUri by remember { mutableStateOf(song.customArtworkUri) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            customArtUri = uri.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Song Info") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                OutlinedTextField(value = artist, onValueChange = { artist = it }, label = { Text("Artist") }, singleLine = true)
                OutlinedTextField(value = album, onValueChange = { album = it }, label = { Text("Album") }, singleLine = true)
                OutlinedButton(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (customArtUri != null) "Change Custom Artwork" else "Pick Custom Artwork")
                }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(title, artist, album, customArtUri) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
