package com.example.guitar

import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

data class TuningString(
    val stringNumber: Int, // 6 down to 1
    val noteLabel: String,
    val targetHz: Double
)

data class GuitarTuningPreset(
    val id: String,
    val name: String,
    val subtitle: String,
    val strings: List<TuningString>
)

enum class ChordCategory(val displayName: String) {
    ALL("All"),
    OPEN("Open"),
    MAJOR("Major"),
    MINOR("Minor"),
    SEVENTH("7th"),
    BARRE("Barre")
}

data class GuitarChord(
    val id: String,
    val name: String,
    val fullName: String,
    val category: ChordCategory,
    val isBarre: Boolean,
    val startingFret: Int,
    // 6 values from Low E (index 0) to High e (index 5): -1 = muted, 0 = open, >0 = fret
    val frets: List<Int>,
    // 6 values: 0 = open/mute, 1 = index, 2 = middle, 3 = ring, 4 = pinky
    val fingers: List<Int>,
    val barreFret: Int? = null,
    val stringNotes: List<String>
)

data class ChordProgressionPreset(
    val id: String,
    val title: String,
    val style: String,
    val chordIds: List<String>,
    val recommendedBpm: Int,
    val beatsPerChord: Int
)

data class GuitarExercise(
    val id: String,
    val title: String,
    val level: String,
    val durationMinutes: Int,
    val targetBpm: Int,
    val description: String,
    val patternSteps: List<String>
)

object ChordLibraryData {

    val tuningPresets: List<GuitarTuningPreset> = listOf(
        GuitarTuningPreset(
            id = "standard",
            name = "Standard",
            subtitle = "E A D G B E",
            strings = listOf(
                TuningString(6, "E2", 82.41),
                TuningString(5, "A2", 110.00),
                TuningString(4, "D3", 146.83),
                TuningString(3, "G3", 196.00),
                TuningString(2, "B3", 246.94),
                TuningString(1, "E4", 329.63)
            )
        ),
        GuitarTuningPreset(
            id = "drop_d",
            name = "Drop D",
            subtitle = "D A D G B E",
            strings = listOf(
                TuningString(6, "D2", 73.42),
                TuningString(5, "A2", 110.00),
                TuningString(4, "D3", 146.83),
                TuningString(3, "G3", 196.00),
                TuningString(2, "B3", 246.94),
                TuningString(1, "E4", 329.63)
            )
        ),
        GuitarTuningPreset(
            id = "half_step",
            name = "Half-Step Down",
            subtitle = "Eb Ab Db Gb Bb Eb",
            strings = listOf(
                TuningString(6, "Eb2", 77.78),
                TuningString(5, "Ab2", 103.83),
                TuningString(4, "Db3", 138.59),
                TuningString(3, "Gb3", 185.00),
                TuningString(2, "Bb3", 233.08),
                TuningString(1, "Eb4", 311.13)
            )
        ),
        GuitarTuningPreset(
            id = "open_g",
            name = "Open G",
            subtitle = "D G D G B D",
            strings = listOf(
                TuningString(6, "D2", 73.42),
                TuningString(5, "G2", 98.00),
                TuningString(4, "D3", 146.83),
                TuningString(3, "G3", 196.00),
                TuningString(2, "B3", 246.94),
                TuningString(1, "D4", 293.66)
            )
        ),
        GuitarTuningPreset(
            id = "open_d",
            name = "Open D",
            subtitle = "D A D F# A D",
            strings = listOf(
                TuningString(6, "D2", 73.42),
                TuningString(5, "A2", 110.00),
                TuningString(4, "D3", 146.83),
                TuningString(3, "F#3", 185.00),
                TuningString(2, "A3", 220.00),
                TuningString(1, "D4", 293.66)
            )
        ),
        GuitarTuningPreset(
            id = "dadgad",
            name = "DADGAD",
            subtitle = "D A D G A D",
            strings = listOf(
                TuningString(6, "D2", 73.42),
                TuningString(5, "A2", 110.00),
                TuningString(4, "D3", 146.83),
                TuningString(3, "G3", 196.00),
                TuningString(2, "A3", 220.00),
                TuningString(1, "D4", 293.66)
            )
        )
    )

    val chords: List<GuitarChord> = listOf(
        GuitarChord("C", "C", "C Major", ChordCategory.MAJOR, false, 1, listOf(-1, 3, 2, 0, 1, 0), listOf(0, 3, 2, 0, 1, 0), null, listOf("X", "C3", "E3", "G3", "C4", "E4")),
        GuitarChord("D", "D", "D Major", ChordCategory.MAJOR, false, 1, listOf(-1, -1, 0, 2, 3, 2), listOf(0, 0, 0, 1, 3, 2), null, listOf("X", "X", "D3", "A3", "D4", "F#4")),
        GuitarChord("E", "E", "E Major", ChordCategory.MAJOR, false, 1, listOf(0, 2, 2, 1, 0, 0), listOf(0, 2, 3, 1, 0, 0), null, listOf("E2", "B2", "E3", "G#3", "B3", "E4")),
        GuitarChord("G", "G", "G Major", ChordCategory.MAJOR, false, 1, listOf(3, 2, 0, 0, 0, 3), listOf(2, 1, 0, 0, 0, 3), null, listOf("G2", "B2", "D3", "G3", "B3", "G4")),
        GuitarChord("A", "A", "A Major", ChordCategory.MAJOR, false, 1, listOf(-1, 0, 2, 2, 2, 0), listOf(0, 0, 1, 2, 3, 0), null, listOf("X", "A2", "E3", "A3", "C#4", "E4")),
        GuitarChord("F", "F", "F Major (Barre)", ChordCategory.BARRE, true, 1, listOf(1, 3, 3, 2, 1, 1), listOf(1, 3, 4, 2, 1, 1), 1, listOf("F2", "C3", "F3", "A3", "C4", "F4")),
        GuitarChord("B", "B", "B Major (Barre)", ChordCategory.BARRE, true, 2, listOf(-1, 2, 4, 4, 4, 2), listOf(0, 1, 2, 3, 4, 1), 2, listOf("X", "B2", "F#3", "B3", "D#4", "F#4")),
        GuitarChord("Am", "Am", "A Minor", ChordCategory.MINOR, false, 1, listOf(-1, 0, 2, 2, 1, 0), listOf(0, 0, 2, 3, 1, 0), null, listOf("X", "A2", "E3", "A3", "C4", "E4")),
        GuitarChord("Em", "Em", "E Minor", ChordCategory.MINOR, false, 1, listOf(0, 2, 2, 0, 0, 0), listOf(0, 2, 3, 0, 0, 0), null, listOf("E2", "B2", "E3", "G3", "B3", "E4")),
        GuitarChord("Dm", "Dm", "D Minor", ChordCategory.MINOR, false, 1, listOf(-1, -1, 0, 2, 3, 1), listOf(0, 0, 0, 2, 3, 1), null, listOf("X", "X", "D3", "A3", "D4", "F4")),
        GuitarChord("Bm", "Bm", "B Minor (Barre)", ChordCategory.BARRE, true, 2, listOf(-1, 2, 4, 4, 3, 2), listOf(0, 1, 3, 4, 2, 1), 2, listOf("X", "B2", "F#3", "B3", "D4", "F#4")),
        GuitarChord("F#m", "F#m", "F# Minor (Barre)", ChordCategory.BARRE, true, 2, listOf(2, 4, 4, 2, 2, 2), listOf(1, 3, 4, 1, 1, 1), 2, listOf("F#2", "C#3", "F#3", "A3", "C#4", "F#4")),
        GuitarChord("C7", "C7", "C Dominant 7", ChordCategory.SEVENTH, false, 1, listOf(-1, 3, 2, 3, 1, 0), listOf(0, 3, 2, 4, 1, 0), null, listOf("X", "C3", "E3", "Bb3", "C4", "E4")),
        GuitarChord("D7", "D7", "D Dominant 7", ChordCategory.SEVENTH, false, 1, listOf(-1, -1, 0, 2, 1, 2), listOf(0, 0, 0, 2, 1, 3), null, listOf("X", "X", "D3", "A3", "C4", "F#4")),
        GuitarChord("E7", "E7", "E Dominant 7", ChordCategory.SEVENTH, false, 1, listOf(0, 2, 0, 1, 0, 0), listOf(0, 2, 0, 1, 0, 0), null, listOf("E2", "B2", "D3", "G#3", "B3", "E4")),
        GuitarChord("G7", "G7", "G Dominant 7", ChordCategory.SEVENTH, false, 1, listOf(3, 2, 0, 0, 0, 1), listOf(3, 2, 0, 0, 0, 1), null, listOf("G2", "B2", "D3", "G3", "B3", "F4")),
        GuitarChord("A7", "A7", "A Dominant 7", ChordCategory.SEVENTH, false, 1, listOf(-1, 0, 2, 0, 2, 0), listOf(0, 0, 2, 0, 3, 0), null, listOf("X", "A2", "E3", "G3", "C#4", "E4")),
        GuitarChord("Cmaj7", "Cmaj7", "C Major 7", ChordCategory.SEVENTH, false, 1, listOf(-1, 3, 2, 0, 0, 0), listOf(0, 3, 2, 0, 0, 0), null, listOf("X", "C3", "E3", "G3", "B3", "E4")),
        GuitarChord("Am7", "Am7", "A Minor 7", ChordCategory.SEVENTH, false, 1, listOf(-1, 0, 2, 0, 1, 0), listOf(0, 0, 2, 0, 1, 0), null, listOf("X", "A2", "E3", "G3", "C4", "E4")),
        GuitarChord("Em7", "Em7", "E Minor 7", ChordCategory.SEVENTH, false, 1, listOf(0, 2, 2, 0, 3, 0), listOf(0, 1, 2, 0, 4, 0), null, listOf("E2", "B2", "E3", "G3", "D4", "E4"))
    )

    val progressions: List<ChordProgressionPreset> = listOf(
        ChordProgressionPreset("pop_g", "Classic Axis", "Pop / Indie", listOf("G", "D", "Em", "C"), 92, 4),
        ChordProgressionPreset("ballad_c", "Warm Ballad", "Acoustic", listOf("C", "G", "Am", "F"), 80, 4),
        ChordProgressionPreset("minor_loop", "Midnight Minor", "Lo-Fi / Rock", listOf("Am", "F", "C", "G"), 88, 4),
        ChordProgressionPreset("blues_a", "12-Bar Blues Groove", "Blues", listOf("A7", "D7", "A7", "E7"), 100, 4),
        ChordProgressionPreset("jazz_soft", "Velvet Sevenths", "Neo-Soul", listOf("Cmaj7", "Am7", "Dm", "G7"), 76, 4)
    )

    val exercises: List<GuitarExercise> = listOf(
        GuitarExercise(
            id = "spider",
            title = "1-2-3-4 Spider Walk",
            level = "Beginner",
            durationMinutes = 5,
            targetBpm = 80,
            description = "Builds left-hand finger independence and clean fretting near the fret wire.",
            patternSteps = listOf(
                "Frets 1-2-3-4 on Low E string (down-up alternate picking)",
                "Shift cleanly up to A, D, G, B, High e strings",
                "Keep thumb centered behind neck; keep unused fingers hovering close",
                "Descend 4-3-2-1 from High e back to Low E"
            )
        ),
        GuitarExercise(
            id = "chord_switch",
            title = "Clean Open Chord Switches",
            level = "Beginner",
            durationMinutes = 8,
            targetBpm = 72,
            description = "Trains muscle memory for landing all fingers simultaneously on beat 1.",
            patternSteps = listOf(
                "Strum G Major on beat 1, relax hand during beats 2-4",
                "Land C Major cleanly on next bar beat 1",
                "Move to D Major and Em without pausing the strumming wrist",
                "Increase BPM by +5 once zero buzz occurs"
            )
        ),
        GuitarExercise(
            id = "pentatonic",
            title = "A Minor Pentatonic Box 1",
            level = "Intermediate",
            durationMinutes = 10,
            targetBpm = 100,
            description = "Essential lead guitar scale shape with strict alternate picking.",
            patternSteps = listOf(
                "6th string: Frets 5 - 8 (Index, Pinky)",
                "5th, 4th, 3rd strings: Frets 5 - 7 (Index, Ring)",
                "2nd & 1st strings: Frets 5 - 8 (Index, Pinky)",
                "Practice with eighth notes synced to the Metronome"
            )
        )
    )

    fun chordFrequenciesHz(chord: GuitarChord): List<Double> {
        // Standard E2=82.41, A2=110, D3=146.83, G3=196, B3=246.94, E4=329.63
        val openHz = listOf(82.41, 110.00, 146.83, 196.00, 246.94, 329.63)
        return chord.frets.mapIndexedNotNull { idx, fret ->
            if (fret < 0) null
            else openHz[idx] * 2.0.pow(fret / 12.0)
        }
    }

    private val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    data class DetectedPitchInfo(
        val frequencyHz: Double,
        val noteName: String,
        val octave: Int,
        val centsOffset: Double,
        val confidence: Float
    )

    fun frequencyToNoteInfo(hz: Double, confidence: Float): DetectedPitchInfo? {
        if (hz < 55.0 || hz > 1200.0) return null
        val midiFloat = 69.0 + 12.0 * (ln(hz / 440.0) / ln(2.0))
        val midiNearest = midiFloat.roundToInt()
        val cents = (midiFloat - midiNearest) * 100.0
        val noteIdx = ((midiNearest % 12) + 12) % 12
        val octave = (midiNearest / 12) - 1
        return DetectedPitchInfo(
            frequencyHz = hz,
            noteName = noteNames[noteIdx],
            octave = octave,
            centsOffset = cents.coerceIn(-50.0, 50.0),
            confidence = confidence
        )
    }
}
