package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LyricsData
import com.example.ui.theme.LocalVybeStyle
import com.example.util.LyricsParser
import com.example.util.TimeFormatter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Real-time synchronized lyric display that automatically keeps the active timestamped line
 * centered in the viewport, highlights it with smooth scale/color/progress animations,
 * and allows tapping any line to seek or scrolling freely with one-tap re-centering.
 */
@Composable
fun SynchronizedLyricsView(
    lyricsData: LyricsData,
    positionMs: Long,
    durationMs: Long,
    syncOffsetMs: Long = 0L,
    fadeEdgeColor: Color? = null,
    compactMode: Boolean = false,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val scrimBase = fadeEdgeColor ?: vybe.bgDeep

    val activeIdx = remember(lyricsData, positionMs, syncOffsetMs) {
        LyricsParser.activeLineIndex(
            lines = lyricsData.lines,
            positionMs = positionMs,
            isSynchronized = lyricsData.isSynchronized,
            syncOffsetMs = syncOffsetMs
        )
    }

    val lineProgress = remember(lyricsData, activeIdx, positionMs, durationMs, syncOffsetMs) {
        if (lyricsData.isSynchronized && activeIdx >= 0) {
            LyricsParser.activeLineProgress(
                lines = lyricsData.lines,
                activeIndex = activeIdx,
                positionMs = positionMs,
                trackDurationMs = durationMs,
                syncOffsetMs = syncOffsetMs
            )
        } else 0f
    }

    // Track user touch scrolling separately from programmatic centering scrolls
    var userScrolledManually by remember(lyricsData.songId) { mutableStateOf(false) }
    var lastManualScrollTimestamp by remember { mutableStateOf(0L) }

    val userScrollDetector = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (source == NestedScrollSource.UserInput) {
                    userScrolledManually = true
                    lastManualScrollTimestamp = System.currentTimeMillis()
                }
                return Offset.Zero
            }
        }
    }

    // Auto-resume centering 3.5 seconds after user stops dragging
    LaunchedEffect(userScrolledManually, lastManualScrollTimestamp) {
        if (userScrolledManually) {
            delay(3500L)
            userScrolledManually = false
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val centerPadding = (maxHeight / 2f - if (compactMode) 26.dp else 32.dp).coerceAtLeast(16.dp)
        val centerPaddingPx = with(density) { centerPadding.roundToPx() }
        val viewportHeightPx = with(density) { maxHeight.roundToPx() }

        suspend fun scrollActiveToCenter(index: Int, animate: Boolean) {
            if (index !in lyricsData.lines.indices) return
            val measuredItemPx = listState.layoutInfo.visibleItemsInfo
                .firstOrNull { it.index == index }?.size
                ?: with(density) { (if (compactMode) 48.dp else 62.dp).roundToPx() }
            val desiredTopPx = ((viewportHeightPx - measuredItemPx) / 2).coerceAtLeast(0)
            val scrollOffset = (centerPaddingPx - desiredTopPx).coerceAtLeast(0)
            if (animate) {
                listState.animateScrollToItem(index = index, scrollOffset = scrollOffset)
            } else {
                listState.scrollToItem(index = index, scrollOffset = scrollOffset)
            }
        }

        // Keep the active line smoothly centered whenever timestamp advances
        LaunchedEffect(activeIdx, lyricsData.songId, userScrolledManually) {
            if (lyricsData.isSynchronized && activeIdx >= 0 && !userScrolledManually) {
                scrollActiveToCenter(activeIdx, animate = true)
            }
        }

        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(
                top = if (lyricsData.isSynchronized) centerPadding else 18.dp,
                bottom = if (lyricsData.isSynchronized) centerPadding else 28.dp,
                start = if (compactMode) 8.dp else 12.dp,
                end = if (compactMode) 8.dp else 12.dp
            ),
            verticalArrangement = Arrangement.spacedBy(if (compactMode) 10.dp else 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(userScrollDetector)
                .testTag("synchronized_lyrics_list")
        ) {
            itemsIndexed(
                items = lyricsData.lines,
                key = { idx, line -> "${lyricsData.songId}_${idx}_${line.timestampMs ?: -1L}" }
            ) { idx, line ->
                val isActive = lyricsData.isSynchronized && idx == activeIdx
                val isPast = lyricsData.isSynchronized && activeIdx >= 0 && idx < activeIdx

                val lineScale by animateFloatAsState(
                    targetValue = when {
                        !lyricsData.isSynchronized -> 1f
                        isActive -> if (compactMode) 1.05f else 1.07f
                        else -> 0.96f
                    },
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioNoBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    ),
                    label = "lyricScale"
                )
                val lineAlpha by animateFloatAsState(
                    targetValue = when {
                        !lyricsData.isSynchronized -> 0.92f
                        isActive -> 1f
                        isPast -> 0.36f
                        else -> 0.62f
                    },
                    animationSpec = tween(260),
                    label = "lyricAlpha"
                )
                val textColor by animateColorAsState(
                    targetValue = when {
                        !lyricsData.isSynchronized -> vybe.textPrimary
                        isActive -> Color.White
                        isPast -> vybe.textMuted
                        else -> vybe.textPrimary
                    },
                    animationSpec = tween(240),
                    label = "lyricTextColor"
                )

                val effectiveTs = line.timestampMs?.let { (it - syncOffsetMs).coerceAtLeast(0L) }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .scale(lineScale)
                        .alpha(lineAlpha)
                        .clip(RoundedCornerShape(18.dp))
                        .then(
                            if (isActive) {
                                Modifier
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(
                                                vybe.accentPrimary.copy(alpha = 0.24f),
                                                vybe.accentSecondary.copy(alpha = 0.18f)
                                            )
                                        )
                                    )
                                    .border(
                                        1.dp,
                                        vybe.accentSecondary.copy(alpha = 0.55f),
                                        RoundedCornerShape(18.dp)
                                    )
                            } else {
                                Modifier
                            }
                        )
                        .clickable(enabled = effectiveTs != null) {
                            if (effectiveTs != null) {
                                userScrolledManually = false
                                onSeekTo(effectiveTs)
                            }
                        }
                        .padding(
                            horizontal = if (compactMode) 14.dp else 18.dp,
                            vertical = if (isActive) (if (compactMode) 10.dp else 14.dp) else 6.dp
                        )
                        .testTag(if (isActive) "lyric_line_active" else "lyric_line_$idx"),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = line.text,
                        style = when {
                            isActive && compactMode -> MaterialTheme.typography.titleMedium
                            isActive -> MaterialTheme.typography.headlineSmall
                            compactMode -> MaterialTheme.typography.bodyMedium
                            else -> MaterialTheme.typography.titleMedium
                        },
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                        color = if (vybe.isLight && isActive) vybe.accentPrimary else textColor,
                        textAlign = TextAlign.Center,
                        lineHeight = if (isActive && !compactMode) 30.sp else 24.sp
                    )

                    if (isActive && effectiveTs != null) {
                        Spacer(Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth(0.62f)
                        ) {
                            Text(
                                text = TimeFormatter.formatDuration(effectiveTs),
                                style = MaterialTheme.typography.labelSmall,
                                color = vybe.accentSecondary,
                                fontSize = 10.sp
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(Color.White.copy(alpha = 0.16f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(lineProgress.coerceIn(0.03f, 1f))
                                        .clip(RoundedCornerShape(50))
                                        .background(
                                            Brush.horizontalGradient(
                                                listOf(vybe.accentPrimary, vybe.accentSecondary)
                                            )
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Top & bottom soft gradient edge fade when synchronized
        if (lyricsData.isSynchronized) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(if (compactMode) 30.dp else 48.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(scrimBase, scrimBase.copy(alpha = 0.55f), Color.Transparent)
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(if (compactMode) 34.dp else 52.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, scrimBase.copy(alpha = 0.6f), scrimBase)
                        )
                    )
            )
        }

        // Floating Re-center Sync pill when user scrolled manually
        AnimatedVisibility(
            visible = lyricsData.isSynchronized && userScrolledManually && activeIdx >= 0,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(180)),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp)
        ) {
            Surface(
                modifier = Modifier
                    .clickable {
                        userScrolledManually = false
                        scope.launch { scrollActiveToCenter(activeIdx, animate = true) }
                    }
                    .testTag("lyrics_recenter_btn"),
                shape = RoundedCornerShape(50),
                color = vybe.accentPrimary.copy(alpha = 0.92f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.MyLocation,
                        contentDescription = "Re-center lyrics",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Sync to Current",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
