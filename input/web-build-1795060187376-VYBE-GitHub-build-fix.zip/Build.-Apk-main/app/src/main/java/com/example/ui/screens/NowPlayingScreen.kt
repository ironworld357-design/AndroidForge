package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode as AnimRepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.BluetoothAudio
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.PlaybackUiState
import com.example.audio.VybeDspAudioProcessor
import com.example.data.local.VybeSettings
import com.example.model.ArtworkStyle
import com.example.model.CrossfadeCurve
import com.example.model.DisplayRefreshInfo
import com.example.model.LyricsData
import com.example.model.PlayerBackgroundStyle
import com.example.model.PlayerLayoutStyle
import com.example.model.RepeatMode
import com.example.model.Song
import com.example.model.VisualizerStyle
import com.example.ui.components.AnimatedEqBars
import com.example.ui.components.AuroraMeshBackground
import com.example.ui.components.GroovedVinylRecordDisc
import com.example.ui.components.HaloCarouselDeck
import com.example.ui.components.OrbitalArcDeck
import com.example.ui.components.RetroCassetteDeck
import com.example.ui.components.SynchronizedLyricsView
import com.example.ui.components.VinylTurntableView
import com.example.ui.components.VybeArtwork
import com.example.ui.components.VybeVisualizerCanvas
import com.example.ui.components.WaveformCoverflowDeck
import com.example.ui.theme.LocalVybeStyle
import com.example.util.LyricsParser
import com.example.util.TimeFormatter
import com.example.util.rememberVybeHaptics

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    playbackState: PlaybackUiState,
    settings: VybeSettings,
    dspProcessor: VybeDspAudioProcessor,
    displayRefreshInfo: DisplayRefreshInfo,
    currentLyrics: LyricsData? = null,
    onBack: () -> Unit,
    onToggleThemeMode: () -> Unit,
    onOpenVinylMode: () -> Unit,
    onOpenLyrics: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSeekBy: (Long) -> Unit,
    onToggleAbLoop: () -> Unit,
    onClearAbLoop: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onSetSpeed: (Float) -> Unit,
    onSetVolume: (Float) -> Unit,
    onStartSleepTimer: (Int) -> Unit,
    onJumpToQueue: (Int) -> Unit,
    onRemoveFromQueue: (Int) -> Unit,
    onMoveQueueItem: (Int, Int) -> Unit,
    onSelectVisualizerStyle: (VisualizerStyle) -> Unit,
    onToggleVisualizer: (Boolean) -> Unit,
    onSetSkipSilence: (Boolean) -> Unit,
    onSetFadeInOut: (Boolean) -> Unit,
    onSetAutoPauseDisconnect: (Boolean) -> Unit,
    onSetShowNotifications: (Boolean) -> Unit,
    onSelectPlayerLayout: (PlayerLayoutStyle) -> Unit,
    onShareSong: (Song) -> Unit,
    onSetCrossfadeMs: (Int) -> Unit = {},
    onSetCrossfadeCurve: (CrossfadeCurve) -> Unit = {},
    onSetCrossfadeOnManualSkip: (Boolean) -> Unit = {},
    onSetHapticFeedback: (Boolean) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val haptics = rememberVybeHaptics(settings.hapticFeedbackEnabled)
    val song = playbackState.currentSong

    LaunchedEffect(playbackState.isCrossfading) {
        if (playbackState.isCrossfading) {
            haptics.crossfadeCue()
        }
    }

    var showQueueSheet by remember { mutableStateOf(false) }
    var showSpeedVolumeSheet by remember { mutableStateOf(false) }
    var showSleepTimerSheet by remember { mutableStateOf(false) }
    var showVisualizerPicker by remember { mutableStateOf(false) }
    var showServiceSessionSheet by remember { mutableStateOf(false) }
    var showInlineLyricsStage by remember { mutableStateOf(false) }

    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPosMs by remember { mutableFloatStateOf(0f) }

    val duration = playbackState.durationMs.coerceAtLeast(1L)
    val displayPos = if (isScrubbing) scrubPosMs.toLong() else playbackState.positionMs.coerceIn(0L, duration)
    val remainingMs = (duration - displayPos).coerceAtLeast(0L)

    // Smooth ambient breathing animation when playing
    val infiniteTransition = rememberInfiniteTransition(label = "npAmbient")
    val ambientPulse by infiniteTransition.animateFloat(
        initialValue = 0.86f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = AnimRepeatMode.Reverse
        ),
        label = "ambientHaloScale"
    )
    val haloAlpha by animateFloatAsState(
        targetValue = if (playbackState.isPlaying && settings.animationsEnabled) 0.42f else 0.14f,
        animationSpec = tween(420),
        label = "ambientHaloAlpha"
    )
    val playBtnScale by animateFloatAsState(
        targetValue = if (playbackState.isPlaying) 1.05f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "playBtnSpring"
    )
    val favScale by animateFloatAsState(
        targetValue = if (song?.isFavorite == true) 1.18f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
        label = "favBounce"
    )

    val bgBrush = when (settings.playerBackgroundStyle) {
        PlayerBackgroundStyle.PURE_BLACK -> Brush.verticalGradient(listOf(Color.Black, Color.Black))
        PlayerBackgroundStyle.ARTWORK_GLOW -> Brush.verticalGradient(
            listOf(vybe.accentPrimary.copy(alpha = 0.28f), vybe.bgDeep, vybe.bgDeep)
        )
        PlayerBackgroundStyle.AURORA_MESH -> Brush.verticalGradient(
            listOf(vybe.meshTopColor.copy(alpha = 0.6f), vybe.bgDeep)
        )
        PlayerBackgroundStyle.FROSTED_FULL_BLEED -> Brush.verticalGradient(
            listOf(vybe.bgDeep.copy(alpha = 0.65f), vybe.bgDeep.copy(alpha = 0.92f))
        )
        PlayerBackgroundStyle.DYNAMIC_GRADIENT -> vybe.heroGradient
    }

    Box(modifier = modifier.fillMaxSize()) {
        if (settings.playerBackgroundStyle == PlayerBackgroundStyle.FROSTED_FULL_BLEED && song != null) {
            VybeArtwork(
                model = song.artworkModel,
                contentDescription = null,
                cornerRadius = 0.dp,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.35f)
            )
        } else if (settings.playerBackgroundStyle == PlayerBackgroundStyle.AURORA_MESH || vybe.isGlassAddon) {
            AuroraMeshBackground(animationsEnabled = settings.animationsEnabled)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(
                    if (settings.playerBackgroundStyle == PlayerBackgroundStyle.AURORA_MESH ||
                        (vybe.isGlassAddon && settings.playerBackgroundStyle != PlayerBackgroundStyle.FROSTED_FULL_BLEED)
                    ) {
                        Modifier
                    } else {
                        Modifier.background(bgBrush)
                    }
                )
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("now_playing_back_btn")) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Minimize player", tint = vybe.textPrimary, modifier = Modifier.size(30.dp))
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (vybe.isRetro) "RETRO CASSETTE DECK" else "NOW PLAYING",
                    style = MaterialTheme.typography.labelMedium,
                    color = vybe.accentSecondary
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val outIcon = when {
                        playbackState.audioOutputInfo.isBluetooth -> Icons.Filled.BluetoothAudio
                        playbackState.audioOutputInfo.isWiredHeadset -> Icons.Filled.Headphones
                        else -> Icons.Filled.Speaker
                    }
                    Icon(outIcon, contentDescription = null, tint = vybe.textMuted, modifier = Modifier.size(13.dp))
                    Text(
                        text = playbackState.audioOutputInfo.deviceName,
                        style = MaterialTheme.typography.labelSmall,
                        color = vybe.textMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (playbackState.isClipping) {
                        Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.error) {
                            Text(
                                "CLIP",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
            }

            IconButton(onClick = onToggleThemeMode, modifier = Modifier.testTag("now_playing_theme_btn")) {
                Icon(
                    imageVector = if (vybe.isRetro) Icons.Filled.AutoAwesome else Icons.Filled.Radio,
                    contentDescription = "Switch Theme Mode",
                    tint = vybe.accentPrimary
                )
            }
        }

        // Interactive Foreground Service & Lock-Screen Session Badge + Addon Layout Cycle Chip
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val dotColor by animateColorAsState(
                targetValue = if (playbackState.isPlaying) Color(0xFF4ADE80)
                else if (playbackState.isServiceConnected) vybe.accentSecondary
                else vybe.textMuted,
                label = "serviceDotColor"
            )
            Surface(
                modifier = Modifier
                    .testTag("np_service_session_pill")
                    .clickable { showServiceSessionSheet = true },
                shape = RoundedCornerShape(50),
                color = vybe.surfaceCard.copy(alpha = 0.85f),
                border = BorderStroke(0.8.dp, vybe.cardBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(dotColor)
                    )
                    Icon(Icons.Filled.Lock, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(12.dp))
                    Text(
                        text = when {
                            playbackState.isPlaying -> "FG SERVICE • LOCK SCREEN"
                            playbackState.isServiceConnected -> "MEDIA3 READY"
                            else -> "CONNECTING..."
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = vybe.textMuted,
                        fontSize = 10.sp
                    )
                }
            }

            AnimatedVisibility(visible = playbackState.isCrossfading) {
                Surface(
                    modifier = Modifier.testTag("np_crossfading_pill"),
                    shape = RoundedCornerShape(50),
                    color = vybe.accentSecondary.copy(alpha = 0.24f),
                    border = BorderStroke(0.8.dp, vybe.accentSecondary)
                ) {
                    Text(
                        text = "CROSSFADING",
                        style = MaterialTheme.typography.labelSmall,
                        color = vybe.accentSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                    )
                }
            }

            if (!vybe.isRetro) {
                Surface(
                    modifier = Modifier
                        .testTag("np_cycle_layout_pill")
                        .clickable {
                            haptics.toggle()
                            showInlineLyricsStage = false
                            val all = PlayerLayoutStyle.entries
                            val next = all[(all.indexOf(settings.playerLayoutStyle) + 1) % all.size]
                            onSelectPlayerLayout(next)
                        },
                    shape = RoundedCornerShape(50),
                    color = vybe.accentPrimary.copy(alpha = 0.22f),
                    border = BorderStroke(0.8.dp, vybe.accentSecondary.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "Deck: ${settings.playerLayoutStyle.displayName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = vybe.accentSecondary,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            if (currentLyrics != null && currentLyrics.lines.isNotEmpty()) {
                Surface(
                    modifier = Modifier
                        .testTag("np_live_lyrics_toggle")
                        .clickable {
                            haptics.toggle()
                            showInlineLyricsStage = !showInlineLyricsStage
                        },
                    shape = RoundedCornerShape(50),
                    color = if (showInlineLyricsStage) vybe.accentSecondary.copy(alpha = 0.26f) else vybe.surfaceCard.copy(alpha = 0.85f),
                    border = BorderStroke(
                        0.8.dp,
                        if (showInlineLyricsStage) vybe.accentSecondary else vybe.cardBorder
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Filled.Lyrics,
                            contentDescription = null,
                            tint = if (showInlineLyricsStage) vybe.accentSecondary else vybe.textMuted,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = if (showInlineLyricsStage) "Artwork" else if (currentLyrics.isSynchronized) "Live Lyrics" else "Lyrics",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (showInlineLyricsStage) vybe.accentSecondary else vybe.textMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Main Center Visual: Modern Album Artwork OR Retro Cassette Deck with Breathing Glow Halo & Track Slide Animation
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            if (settings.animationsEnabled) {
                Box(
                    modifier = Modifier
                        .size(270.dp)
                        .scale(if (playbackState.isPlaying) ambientPulse else 0.94f)
                        .alpha(haloAlpha)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    vybe.accentPrimary.copy(alpha = 0.65f),
                                    vybe.accentSecondary.copy(alpha = 0.25f),
                                    Color.Transparent
                                )
                            )
                        )
                )
            }

            AnimatedContent(
                targetState = Pair(showInlineLyricsStage && currentLyrics?.lines?.isNotEmpty() == true, Triple(vybe.isRetro, settings.playerLayoutStyle, song?.id ?: -1L)),
                transitionSpec = {
                    val dir = playbackState.skipDirection
                    if (initialState.first != targetState.first || initialState.second.first != targetState.second.first || initialState.second.second != targetState.second.second) {
                        (fadeIn(tween(260)) + scaleIn(initialScale = 0.94f)) togetherWith
                            (fadeOut(tween(200)) + scaleOut(targetScale = 0.94f))
                    } else {
                        (slideInHorizontally(tween(280)) { it * dir / 2 } + fadeIn(tween(260)) + scaleIn(initialScale = 0.95f)) togetherWith
                            (slideOutHorizontally(tween(220)) { -it * dir / 2 } + fadeOut(tween(200)))
                    }
                },
                label = "nowPlayingDualVisual"
            ) { (lyricsStage, visualKey) ->
                val (isRetro, layoutStyle, _) = visualKey
                when {
                    lyricsStage && currentLyrics != null -> {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(296.dp)
                                .testTag("np_inline_lyrics_stage"),
                            shape = RoundedCornerShape(24.dp),
                            color = vybe.surfaceCard.copy(alpha = 0.78f),
                            border = BorderStroke(1.dp, vybe.accentSecondary.copy(alpha = 0.32f))
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                SynchronizedLyricsView(
                                    lyricsData = currentLyrics,
                                    positionMs = displayPos,
                                    durationMs = duration,
                                    fadeEdgeColor = vybe.surfaceCard,
                                    compactMode = true,
                                    onSeekTo = { ms -> haptics.toggle(); onSeekTo(ms) },
                                    modifier = Modifier.fillMaxSize()
                                )
                                Text(
                                    text = "Full Screen",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = vybe.accentSecondary,
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(10.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(vybe.surfaceElevated.copy(alpha = 0.85f))
                                        .clickable(onClick = onOpenLyrics)
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                    isRetro -> {
                        RetroCassetteDeck(
                            song = song,
                            isPlaying = playbackState.isPlaying,
                            positionMs = displayPos,
                            durationMs = duration,
                            playbackSpeed = playbackState.playbackSpeed,
                            animationsEnabled = settings.animationsEnabled
                        )
                    }
                    layoutStyle == PlayerLayoutStyle.VINYL_RECORD -> {
                        VinylTurntableView(
                            artworkModel = song?.artworkModel,
                            isPlaying = playbackState.isPlaying && settings.animationsEnabled,
                            playbackSpeed = playbackState.playbackSpeed,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp)
                                .testTag("np_vinyl_record_deck")
                        )
                    }
                    layoutStyle == PlayerLayoutStyle.ORBITAL_ARC -> {
                        OrbitalArcDeck(
                            playbackState = playbackState,
                            artworkStyle = settings.artworkStyle,
                            displayPosMs = displayPos,
                            durationMs = duration,
                            animationsEnabled = settings.animationsEnabled,
                            onPlayPause = { haptics.playPause(); onPlayPause() },
                            onNext = { haptics.skip(); onNext() },
                            onPrevious = { haptics.skip(); onPrevious() },
                            onSeekTo = { haptics.tick(); onSeekTo(it) },
                            onToggleShuffle = { haptics.toggle(); onToggleShuffle() },
                            onCycleRepeat = { haptics.toggle(); onCycleRepeat() },
                            onToggleFavorite = { s -> haptics.favorite(); onToggleFavorite(s) }
                        )
                    }
                    layoutStyle == PlayerLayoutStyle.HALO_CAROUSEL -> {
                        HaloCarouselDeck(
                            playbackState = playbackState,
                            displayPosMs = displayPos,
                            durationMs = duration,
                            animationsEnabled = settings.animationsEnabled,
                            onPrevious = { haptics.skip(); onPrevious() },
                            onNext = { haptics.skip(); onNext() }
                        )
                    }
                    layoutStyle == PlayerLayoutStyle.WAVEFORM_COVERFLOW -> {
                        WaveformCoverflowDeck(
                            playbackState = playbackState,
                            artworkStyle = settings.artworkStyle,
                            displayPosMs = displayPos,
                            durationMs = duration,
                            animationsEnabled = settings.animationsEnabled,
                            onPrevious = { haptics.skip(); onPrevious() },
                            onNext = { haptics.skip(); onNext() },
                            onSeekTo = { haptics.tick(); onSeekTo(it) }
                        )
                    }
                    else -> {
                        val isCircularDisc = settings.artworkStyle == ArtworkStyle.VINYL_DISC ||
                            settings.artworkStyle == ArtworkStyle.HALO_RING
                        if (isCircularDisc) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                VybeArtwork(
                                    model = song?.artworkModel,
                                    contentDescription = song?.title ?: "Album Artwork",
                                    style = settings.artworkStyle,
                                    cornerRadius = 140.dp,
                                    isPlaying = playbackState.isPlaying && settings.animationsEnabled,
                                    playbackSpeed = playbackState.playbackSpeed,
                                    spinEnabled = true,
                                    modifier = Modifier.size(272.dp)
                                )
                            }
                        } else {
                            val vinylPeekX by animateFloatAsState(
                                targetValue = if (playbackState.isPlaying) 60f else 34f,
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessLow
                                ),
                                label = "vinylPeekOffset"
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(276.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                // Peeking spinning vinyl record behind the album jacket
                                GroovedVinylRecordDisc(
                                    artworkModel = song?.artworkModel,
                                    isPlaying = playbackState.isPlaying,
                                    playbackSpeed = playbackState.playbackSpeed,
                                    animationsEnabled = settings.animationsEnabled,
                                    modifier = Modifier
                                        .size(218.dp)
                                        .offset(x = vinylPeekX.dp)
                                        .clickable { onSelectPlayerLayout(PlayerLayoutStyle.VINYL_RECORD) }
                                        .testTag("np_peeking_vinyl_disc")
                                )

                                // Foreground album sleeve
                                VybeArtwork(
                                    model = song?.artworkModel,
                                    contentDescription = song?.title ?: "Album Artwork",
                                    style = settings.artworkStyle,
                                    cornerRadius = 24.dp,
                                    modifier = Modifier
                                        .size(234.dp)
                                        .offset(x = (-24).dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live Real-Time Synchronized Lyric Ticker (visible whenever synced lyrics exist and inline lyrics stage is collapsed)
        if (!showInlineLyricsStage && currentLyrics != null && currentLyrics.isSynchronized && currentLyrics.lines.isNotEmpty()) {
            val activeIdx = remember(currentLyrics, displayPos) {
                LyricsParser.activeLineIndex(currentLyrics.lines, displayPos, true)
            }
            val activeLineText = currentLyrics.lines.getOrNull(activeIdx)?.text
                ?: currentLyrics.lines.firstOrNull()?.text.orEmpty()
            if (activeLineText.isNotBlank()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showInlineLyricsStage = true }
                        .testTag("np_lyric_ticker"),
                    shape = RoundedCornerShape(14.dp),
                    color = vybe.surfaceCard.copy(alpha = 0.72f),
                    border = BorderStroke(0.8.dp, vybe.accentSecondary.copy(alpha = 0.32f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Filled.Lyrics,
                            contentDescription = "Synchronized lyric",
                            tint = vybe.accentSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        AnimatedContent(
                            targetState = activeLineText,
                            transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(140)) },
                            modifier = Modifier.weight(1f),
                            label = "npLyricTicker"
                        ) { line ->
                            Text(
                                text = line,
                                style = MaterialTheme.typography.bodyMedium,
                                color = vybe.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = "LRC",
                            style = MaterialTheme.typography.labelSmall,
                            color = vybe.accentSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Live Audio Visualizer
        if (settings.visualizerEnabled) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = settings.visualizerStyle.displayName.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = vybe.textMuted
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (settings.eqEnabled) "10-Band EQ On" else "EQ Off",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (settings.eqEnabled) vybe.accentPrimary else vybe.textMuted,
                            modifier = Modifier.clickable(onClick = onOpenEqualizer)
                        )
                        Text(
                            text = "Change Style",
                            style = MaterialTheme.typography.labelSmall,
                            color = vybe.accentSecondary,
                            modifier = Modifier.clickable { showVisualizerPicker = true }
                        )
                        Text(
                            text = "Hide",
                            style = MaterialTheme.typography.labelSmall,
                            color = vybe.textMuted,
                            modifier = Modifier
                                .clickable { onToggleVisualizer(false) }
                                .testTag("np_hide_visualizer_btn")
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                VybeVisualizerCanvas(
                    dspProcessor = dspProcessor,
                    isPlaying = playbackState.isPlaying,
                    style = if (vybe.isRetro && settings.visualizerStyle == VisualizerStyle.SPECTRUM_ANALYZER) {
                        VisualizerStyle.RETRO_ANALOG
                    } else {
                        settings.visualizerStyle
                    },
                    intensity = settings.visualizerIntensity,
                    sizePreset = settings.visualizerSize,
                    customColorHex = settings.visualizerCustomColorHex,
                    performanceMode = settings.performanceMode,
                    displayRefreshInfo = displayRefreshInfo
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Surface(
                    modifier = Modifier
                        .clickable { onToggleVisualizer(true) }
                        .testTag("np_enable_visualizer_btn"),
                    shape = RoundedCornerShape(50),
                    color = vybe.surfaceCard,
                    border = BorderStroke(0.8.dp, vybe.cardBorder)
                ) {
                    Text(
                        text = "Show Live Audio Visualizer",
                        style = MaterialTheme.typography.labelSmall,
                        color = vybe.accentSecondary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        val isOrbitalArc = !vybe.isRetro && settings.playerLayoutStyle == PlayerLayoutStyle.ORBITAL_ARC
        val isWaveCoverflow = !vybe.isRetro && settings.playerLayoutStyle == PlayerLayoutStyle.WAVEFORM_COVERFLOW

        // Song Info + Animated EQ Bars + Favorite + Share (hidden when OrbitalArc renders it inside card)
        if (!isOrbitalArc) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                AnimatedContent(
                    targetState = song?.id ?: -1L,
                    transitionSpec = {
                        val dir = playbackState.skipDirection
                        (slideInHorizontally(tween(240)) { it * dir / 3 } + fadeIn(tween(220))) togetherWith
                            (slideOutHorizontally(tween(180)) { -it * dir / 3 } + fadeOut(tween(160)))
                    },
                    modifier = Modifier.weight(1f),
                    label = "songTitleMeta"
                ) { _ ->
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = song?.title ?: "No Track Selected",
                                style = MaterialTheme.typography.headlineSmall,
                                color = vybe.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (playbackState.isPlaying && song != null) {
                                AnimatedEqBars(
                                    isPlaying = true,
                                    color = vybe.accentSecondary,
                                    modifier = Modifier.size(width = 16.dp, height = 14.dp),
                                    barCount = 3
                                )
                            }
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = if (song != null) "${song.artist} • ${song.album}" else "Select a song from Library",
                            style = MaterialTheme.typography.bodyMedium,
                            color = vybe.textMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (song != null) {
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = vybe.accentSecondary.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "${song.formatBadge} • ${if (song.bitrateKbps > 0) "${song.bitrateKbps} kbps" else "Offline"}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = vybe.accentSecondary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                                if (playbackState.sleepTimerRemainingMs > 0L) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = vybe.accentPrimary.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = "Sleep ${TimeFormatter.formatDuration(playbackState.sleepTimerRemainingMs)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = vybe.accentPrimary,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (song != null) {
                    Row {
                        IconButton(
                            onClick = {
                                haptics.favorite()
                                onToggleFavorite(song)
                            },
                            modifier = Modifier
                                .scale(favScale)
                                .testTag("now_playing_fav_btn")
                        ) {
                            Icon(
                                imageVector = if (song.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (song.isFavorite) vybe.accentSecondary else vybe.textMuted
                            )
                        }
                        IconButton(onClick = { onShareSong(song) }) {
                            Icon(Icons.Filled.Share, contentDescription = "Share track", tint = vybe.textMuted)
                        }
                    }
                }
            }
        }

        // Progress Bar + Current & Remaining Time + Quick -10s / A-B Loop / +10s
        Column {
            if (!isOrbitalArc && !isWaveCoverflow) {
                Slider(
                    value = displayPos.toFloat(),
                    onValueChange = {
                        isScrubbing = true
                        scrubPosMs = it
                        haptics.tick()
                    },
                    onValueChangeFinished = {
                        haptics.toggle()
                        onSeekTo(scrubPosMs.toLong())
                        isScrubbing = false
                    },
                    valueRange = 0f..duration.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = vybe.accentSecondary,
                        activeTrackColor = vybe.accentPrimary,
                        inactiveTrackColor = vybe.surfaceElevated
                    ),
                    modifier = Modifier.testTag("now_playing_seekbar")
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(TimeFormatter.formatDuration(displayPos), style = MaterialTheme.typography.labelMedium, color = vybe.textMuted)

                // Quick Scrub & A-B Loop Controls
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        modifier = Modifier
                            .clickable { haptics.toggle(); onSeekBy(-10_000L) }
                            .testTag("np_replay_10_btn"),
                        shape = RoundedCornerShape(8.dp),
                        color = vybe.surfaceCard,
                        border = BorderStroke(0.7.dp, vybe.cardBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(Icons.Filled.Replay10, contentDescription = "Rewind 10 seconds", tint = vybe.textPrimary, modifier = Modifier.size(14.dp))
                            Text("-10s", style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                        }
                    }

                    val loopActive = playbackState.abLoopStartMs != null
                    val loopLabel = when {
                        playbackState.abLoopStartMs == null -> "A-B Loop"
                        playbackState.abLoopEndMs == null -> "A: ${TimeFormatter.formatDuration(playbackState.abLoopStartMs)} • Set B"
                        else -> "Loop ${TimeFormatter.formatDuration(playbackState.abLoopStartMs)}–${TimeFormatter.formatDuration(playbackState.abLoopEndMs)}"
                    }
                    Surface(
                        modifier = Modifier
                            .clickable { haptics.toggle(); onToggleAbLoop() }
                            .testTag("np_ab_loop_btn"),
                        shape = RoundedCornerShape(8.dp),
                        color = if (loopActive) vybe.accentPrimary.copy(alpha = 0.24f) else vybe.surfaceCard,
                        border = BorderStroke(0.8.dp, if (loopActive) vybe.accentSecondary else vybe.cardBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = loopLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (loopActive) vybe.accentSecondary else vybe.textMuted,
                                fontWeight = if (loopActive) FontWeight.Bold else FontWeight.Normal
                            )
                            if (playbackState.abLoopEndMs != null) {
                                Icon(
                                    Icons.Filled.Close,
                                    contentDescription = "Clear A-B loop",
                                    tint = vybe.accentSecondary,
                                    modifier = Modifier
                                        .size(13.dp)
                                        .clickable { haptics.toggle(); onClearAbLoop() }
                                )
                            }
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .clickable { haptics.toggle(); onSeekBy(10_000L) }
                            .testTag("np_forward_10_btn"),
                        shape = RoundedCornerShape(8.dp),
                        color = vybe.surfaceCard,
                        border = BorderStroke(0.7.dp, vybe.cardBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text("+10s", style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                            Icon(Icons.Filled.Forward10, contentDescription = "Forward 10 seconds", tint = vybe.textPrimary, modifier = Modifier.size(14.dp))
                        }
                    }
                }

                Text("-${TimeFormatter.formatDuration(remainingMs)}", style = MaterialTheme.typography.labelMedium, color = vybe.textMuted)
            }
        }

        // Primary Transport Controls with Animated Play Halo & Spring Physics (when not rendered inside OrbitalArcDeck)
        if (!isOrbitalArc) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { haptics.toggle(); onToggleShuffle() }, modifier = Modifier.testTag("now_playing_shuffle_btn")) {
                    Icon(
                        Icons.Filled.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (playbackState.shuffleEnabled) vybe.accentSecondary else vybe.textMuted
                    )
                }

                Surface(
                    modifier = Modifier
                        .size(54.dp)
                        .clickable { haptics.skip(); onPrevious() }
                        .testTag("now_playing_prev_btn"),
                    shape = if (vybe.isRetro) RoundedCornerShape(10.dp) else CircleShape,
                    color = vybe.surfaceElevated,
                    border = BorderStroke(1.dp, vybe.cardBorder)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = vybe.textPrimary, modifier = Modifier.size(28.dp))
                    }
                }

                Box(
                    contentAlignment = Alignment.Center
                ) {
                    if (playbackState.isPlaying && settings.animationsEnabled) {
                        val ringShape = if (vybe.isRetro) RoundedCornerShape(18.dp) else CircleShape
                        Box(
                            modifier = Modifier
                                .size(82.dp)
                                .scale(ambientPulse)
                                .border(1.5.dp, vybe.accentSecondary.copy(alpha = 0.45f), ringShape)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .scale(playBtnScale)
                            .clip(if (vybe.isRetro) RoundedCornerShape(14.dp) else CircleShape)
                            .background(vybe.accentGradient)
                            .clickable { haptics.playPause(); onPlayPause() }
                            .testTag("now_playing_play_pause_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        AnimatedContent(
                            targetState = playbackState.isPlaying,
                            transitionSpec = {
                                (scaleIn(initialScale = 0.72f) + fadeIn(tween(150))) togetherWith
                                    (scaleOut(targetScale = 0.72f) + fadeOut(tween(130)))
                            },
                            label = "npPlayPauseIcon"
                        ) { playing ->
                            Icon(
                                imageVector = if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (playing) "Pause" else "Play",
                                tint = if (vybe.isRetro) Color(0xFF1D1309) else Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }

                Surface(
                    modifier = Modifier
                        .size(54.dp)
                        .clickable { haptics.skip(); onNext() }
                        .testTag("now_playing_next_btn"),
                    shape = if (vybe.isRetro) RoundedCornerShape(10.dp) else CircleShape,
                    color = vybe.surfaceElevated,
                    border = BorderStroke(1.dp, vybe.cardBorder)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = vybe.textPrimary, modifier = Modifier.size(28.dp))
                    }
                }

                IconButton(onClick = { haptics.toggle(); onCycleRepeat() }, modifier = Modifier.testTag("now_playing_repeat_btn")) {
                    Icon(
                        imageVector = if (playbackState.repeatMode == RepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        contentDescription = "Repeat",
                        tint = if (playbackState.repeatMode != RepeatMode.OFF) vybe.accentSecondary else vybe.textMuted
                    )
                }
            }
        }

        // Studio Action Shortcuts
        Surface(
            shape = RoundedCornerShape(vybe.cardRadius),
            color = vybe.surfaceCard,
            border = BorderStroke(0.8.dp, vybe.cardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp, horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                PlayerActionChip(Icons.Filled.Album, "Vinyl", onOpenVinylMode, Modifier.testTag("np_vinyl_btn"))
                PlayerActionChip(Icons.Filled.Lyrics, "Lyrics", onOpenLyrics, Modifier.testTag("np_lyrics_btn"))
                PlayerActionChip(Icons.Filled.Equalizer, "EQ", onOpenEqualizer, Modifier.testTag("np_eq_btn"))
                PlayerActionChip(Icons.AutoMirrored.Filled.QueueMusic, "Queue (${playbackState.queue.size})", { showQueueSheet = true }, Modifier.testTag("np_queue_btn"))
                PlayerActionChip(Icons.Filled.Speed, "${playbackState.playbackSpeed}x", { showSpeedVolumeSheet = true }, Modifier.testTag("np_speed_btn"))
                PlayerActionChip(Icons.Filled.Bedtime, "Sleep", { showSleepTimerSheet = true }, Modifier.testTag("np_sleep_btn"))
            }
        }

        Spacer(Modifier.height(24.dp))
        }
    }

    // Foreground Service & Lock-Screen MediaSession Sheet
    if (showServiceSessionSheet) {
        ModalBottomSheet(
            onDismissRequest = { showServiceSessionSheet = false },
            containerColor = vybe.surfaceCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, tint = vybe.accentSecondary)
                    Column {
                        Text("Media3 Foreground Service & Lock Screen", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
                        Text("Background ExoPlayer • Dual-Deck Crossfade • System Media Session", style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = vybe.surfaceElevated,
                    border = BorderStroke(0.8.dp, vybe.cardBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("Lock-Screen & Notification Actions Active", style = MaterialTheme.typography.titleSmall, color = vybe.accentSecondary)
                        Text(
                            "Play/Pause, Next, Previous, Seek Scrubbing, Favorite Heart, Shuffle, Repeat, +/-10s Quick Skip, and SystemUI Playback Resumption are bound to the MediaSession.",
                            style = MaterialTheme.typography.bodySmall,
                            color = vybe.textMuted
                        )
                        Text(
                            "Output Route: ${playbackState.audioOutputInfo.deviceName} (${playbackState.audioOutputInfo.deviceTypeLabel})",
                            style = MaterialTheme.typography.labelMedium,
                            color = vybe.textPrimary
                        )
                    }
                }

                // Quick Media3 Crossfade Settings right inside Playback Session Sheet
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = vybe.surfaceElevated,
                    border = BorderStroke(0.8.dp, vybe.cardBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Media3 Crossfade (${if (settings.crossfadeDurationMs == 0) "Off" else "${settings.crossfadeDurationMs / 1000}s"})",
                            style = MaterialTheme.typography.titleSmall,
                            color = vybe.accentSecondary
                        )
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(0, 2000, 4000, 6000, 8000, 12000).forEach { ms ->
                                FilterChip(
                                    selected = settings.crossfadeDurationMs == ms,
                                    onClick = {
                                        haptics.toggle()
                                        onSetCrossfadeMs(ms)
                                    },
                                    label = {
                                        Text(
                                            text = if (ms == 0) "Off" else "${ms / 1000}s",
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    modifier = Modifier.testTag("sheet_crossfade_${ms / 1000}s")
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CrossfadeCurve.entries.forEach { curve ->
                                FilterChip(
                                    selected = settings.crossfadeCurve == curve,
                                    onClick = {
                                        haptics.toggle()
                                        onSetCrossfadeCurve(curve)
                                    },
                                    label = { Text(curve.displayName, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }
                }

                SessionToggleItem(
                    title = "Crossfade on Manual Skip",
                    subtitle = "Blend tracks smoothly when tapping Next or Previous",
                    checked = settings.crossfadeOnManualSkip,
                    onCheckedChange = {
                        haptics.toggle()
                        onSetCrossfadeOnManualSkip(it)
                    }
                )
                SessionToggleItem(
                    title = "Tactile Haptic Feedback",
                    subtitle = "Physical feedback on transport, faders & crossfade cues",
                    checked = settings.hapticFeedbackEnabled,
                    onCheckedChange = {
                        if (it) haptics.toggle()
                        onSetHapticFeedback(it)
                    }
                )
                SessionToggleItem(
                    title = "Lock-Screen & Notification Controls",
                    subtitle = "Show artwork & custom buttons in Android notification shade",
                    checked = settings.showNotifications,
                    onCheckedChange = {
                        haptics.toggle()
                        onSetShowNotifications(it)
                    }
                )
                SessionToggleItem(
                    title = "Skip Silence",
                    subtitle = "Automatically skip extended silent segments in ExoPlayer",
                    checked = settings.skipSilenceEnabled,
                    onCheckedChange = {
                        haptics.toggle()
                        onSetSkipSilence(it)
                    }
                )
                SessionToggleItem(
                    title = "Fade In / Fade Out",
                    subtitle = "Smooth volume ramp on play & pause transitions",
                    checked = settings.fadeInOutEnabled,
                    onCheckedChange = {
                        haptics.toggle()
                        onSetFadeInOut(it)
                    }
                )
                SessionToggleItem(
                    title = "Auto-Pause on Headphone Disconnect",
                    subtitle = "BECOMING_NOISY protection for wired & Bluetooth audio",
                    checked = settings.autoPauseOnDisconnect,
                    onCheckedChange = {
                        haptics.toggle()
                        onSetAutoPauseDisconnect(it)
                    }
                )
            }
        }
    }

    // Queue Management Sheet
    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = vybe.surfaceCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 28.dp)
            ) {
                Text("Playing Queue (${playbackState.queue.size})", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    modifier = Modifier.height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    itemsIndexed(playbackState.queue, key = { idx, s -> "${s.id}_$idx" }) { idx, qSong ->
                        val isCur = idx == playbackState.currentIndex
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onJumpToQueue(idx) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isCur) vybe.accentPrimary.copy(alpha = 0.2f) else vybe.surfaceElevated
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(qSong.title, color = if (isCur) vybe.accentSecondary else vybe.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(qSong.artist, style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                                }
                                IconButton(onClick = { if (idx > 0) onMoveQueueItem(idx, idx - 1) }, enabled = idx > 0) {
                                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Move up", modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { if (idx < playbackState.queue.lastIndex) onMoveQueueItem(idx, idx + 1) }, enabled = idx < playbackState.queue.lastIndex) {
                                    Icon(Icons.Filled.ArrowDownward, contentDescription = "Move down", modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onRemoveFromQueue(idx) }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Remove", modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Speed & Volume Sheet
    if (showSpeedVolumeSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSpeedVolumeSheet = false },
            containerColor = vybe.surfaceCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Playback Speed & Volume", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, tint = vybe.accentSecondary)
                    Spacer(Modifier.width(10.dp))
                    Text("Player Volume (${(playbackState.volume * 100).toInt()}%)", modifier = Modifier.weight(1f))
                }
                Slider(
                    value = playbackState.volume,
                    onValueChange = onSetVolume,
                    valueRange = 0f..1f
                )

                Text("Playback Speed (${String.format("%.2fx", playbackState.playbackSpeed)})", style = MaterialTheme.typography.titleMedium)
                Slider(
                    value = playbackState.playbackSpeed,
                    onValueChange = onSetSpeed,
                    valueRange = 0.5f..2.0f
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                        TextButton(onClick = { onSetSpeed(spd) }) {
                            Text("${spd}x", color = if (playbackState.playbackSpeed == spd) vybe.accentSecondary else vybe.textMuted)
                        }
                    }
                }
            }
        }
    }

    // Sleep Timer Sheet
    if (showSleepTimerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSleepTimerSheet = false },
            containerColor = vybe.surfaceCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Sleep Timer", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
                Text("Audio gently fades out before pausing.", style = MaterialTheme.typography.bodyMedium, color = vybe.textMuted)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(10, 15, 30, 45, 60).forEach { mins ->
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    onStartSleepTimer(mins)
                                    showSleepTimerSheet = false
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = vybe.surfaceElevated
                        ) {
                            Box(modifier = Modifier.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                                Text("${mins}m", color = vybe.textPrimary)
                            }
                        }
                    }
                }
                if (playbackState.sleepTimerRemainingMs > 0L) {
                    TextButton(onClick = {
                        onStartSleepTimer(0)
                        showSleepTimerSheet = false
                    }) {
                        Text("Turn Off Timer", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    // Visualizer Style Picker
    if (showVisualizerPicker) {
        ModalBottomSheet(
            onDismissRequest = { showVisualizerPicker = false },
            containerColor = vybe.surfaceCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Choose Visualizer Style", style = MaterialTheme.typography.titleLarge)
                VisualizerStyle.entries.forEach { style ->
                    val selected = settings.visualizerStyle == style
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectVisualizerStyle(style)
                                showVisualizerPicker = false
                            },
                        shape = RoundedCornerShape(10.dp),
                        color = if (selected) vybe.accentPrimary.copy(alpha = 0.2f) else vybe.surfaceElevated
                    ) {
                        Text(
                            style.displayName,
                            color = if (selected) vybe.accentSecondary else vybe.textPrimary,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SessionToggleItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val vybe = LocalVybeStyle.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = vybe.textPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = vybe.textMuted)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun PlayerActionChip(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = vybe.accentSecondary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = vybe.textMuted, maxLines = 1)
    }
}
