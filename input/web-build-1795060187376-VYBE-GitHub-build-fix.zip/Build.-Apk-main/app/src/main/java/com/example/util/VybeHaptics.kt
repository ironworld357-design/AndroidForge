package com.example.util

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView

/**
 * Tactile haptic feedback helper providing distinct physical cues for playback transport,
 * seekbar/slider detents, favorite toggles, and smooth crossfade transitions.
 */
class VybeHaptics(
    private val context: Context,
    private val view: View,
    val enabled: Boolean
) {
    private var lastTickNs: Long = 0L

    private val vibrator: Vibrator? by lazy {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        }.getOrNull()
    }

    fun playPause() {
        if (!enabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vibrateEffect(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
        } else {
            performViewHaptic(HapticFeedbackConstants.KEYBOARD_TAP)
        }
    }

    fun skip() {
        if (!enabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vibrateEffect(VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK))
        } else {
            performViewHaptic(HapticFeedbackConstants.CONTEXT_CLICK)
        }
    }

    fun tick() {
        if (!enabled) return
        val now = System.nanoTime()
        if (now - lastTickNs < 45_000_000L) return // Throttle continuous slider drags cleanly
        lastTickNs = now
        val constant = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            HapticFeedbackConstants.TEXT_HANDLE_MOVE
        } else {
            HapticFeedbackConstants.CLOCK_TICK
        }
        performViewHaptic(constant)
    }

    fun toggle() {
        if (!enabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vibrateEffect(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
        } else {
            performViewHaptic(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    fun favorite() {
        if (!enabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vibrateEffect(VibrationEffect.createPredefined(VibrationEffect.EFFECT_DOUBLE_CLICK))
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrateEffect(VibrationEffect.createWaveform(longArrayOf(0L, 14L, 38L, 22L), -1))
        } else {
            performViewHaptic(HapticFeedbackConstants.KEYBOARD_TAP)
        }
    }

    fun crossfadeCue() {
        if (!enabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrateEffect(VibrationEffect.createOneShot(18L, 70))
        } else {
            performViewHaptic(HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    private fun performViewHaptic(constant: Int) {
        runCatching {
            view.performHapticFeedback(constant)
        }
    }

    private fun vibrateEffect(effect: VibrationEffect) {
        val vib = vibrator
        if (vib != null && vib.hasVibrator()) {
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib.vibrate(effect)
                }
            }.onFailure {
                performViewHaptic(HapticFeedbackConstants.KEYBOARD_TAP)
            }
        } else {
            performViewHaptic(HapticFeedbackConstants.KEYBOARD_TAP)
        }
    }
}

@Composable
fun rememberVybeHaptics(enabled: Boolean): VybeHaptics {
    val context = LocalContext.current
    val view = LocalView.current
    return remember(context, view, enabled) {
        VybeHaptics(context = context, view = view, enabled = enabled)
    }
}
