package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.ArtworkStyle
import com.example.model.Song
import com.example.ui.theme.LocalVybeStyle
import com.example.util.TimeFormatter

@Composable
fun SongRowItem(
    song: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    artworkStyle: ArtworkStyle,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onEditMetadata: () -> Unit,
    onShare: () -> Unit,
    onMoveToTrash: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    var menuExpanded by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(vybe.cardRadius * 0.75f),
        color = if (isCurrent) vybe.accentPrimary.copy(alpha = 0.14f) else vybe.surfaceCard,
        border = BorderStroke(
            width = if (isCurrent) 1.2.dp else 0.7.dp,
            color = if (isCurrent) vybe.accentSecondary.copy(alpha = 0.65f) else vybe.cardBorder.copy(alpha = 0.45f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(contentAlignment = Alignment.Center) {
                VybeArtwork(
                    model = song.artworkModel,
                    contentDescription = song.title,
                    style = artworkStyle,
                    cornerRadius = 10.dp,
                    modifier = Modifier.size(50.dp)
                )
                if (isCurrent) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(vybe.bgDeep.copy(alpha = 0.62f)),
                        contentAlignment = Alignment.Center
                    ) {
                        AnimatedEqBars(
                            isPlaying = isPlaying,
                            color = vybe.accentSecondary,
                            modifier = Modifier.size(20.dp),
                            barCount = 4
                        )
                    }
                }
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isCurrent) vybe.accentSecondary else vybe.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = song.artist,
                        style = MaterialTheme.typography.bodyMedium,
                        color = vybe.textMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Surface(
                        shape = RoundedCornerShape(5.dp),
                        color = if (song.isLossless) vybe.accentSecondary.copy(alpha = 0.16f) else vybe.surfaceElevated
                    ) {
                        Text(
                            text = song.formatBadge,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (song.isLossless) vybe.accentSecondary else vybe.textMuted,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Text(
                text = TimeFormatter.formatDuration(song.durationMs),
                style = MaterialTheme.typography.labelMedium,
                color = vybe.textMuted,
                modifier = Modifier.padding(horizontal = 6.dp)
            )

            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = if (song.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (song.isFavorite) vybe.accentSecondary else vybe.textMuted,
                    modifier = Modifier.size(20.dp)
                )
            }

            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.MoreVert,
                        contentDescription = "Song options",
                        tint = vybe.textMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    containerColor = vybe.surfaceElevated
                ) {
                    DropdownMenuItem(
                        text = { Text("Play Next", color = vybe.textPrimary) },
                        onClick = { menuExpanded = false; onPlayNext() }
                    )
                    DropdownMenuItem(
                        text = { Text("Add to Queue", color = vybe.textPrimary) },
                        onClick = { menuExpanded = false; onAddToQueue() }
                    )
                    DropdownMenuItem(
                        text = { Text("Add to Playlist", color = vybe.textPrimary) },
                        onClick = { menuExpanded = false; onAddToPlaylist() }
                    )
                    DropdownMenuItem(
                        text = { Text("Edit Info & Artwork", color = vybe.textPrimary) },
                        onClick = { menuExpanded = false; onEditMetadata() }
                    )
                    DropdownMenuItem(
                        text = { Text("Share Song Info", color = vybe.textPrimary) },
                        onClick = { menuExpanded = false; onShare() }
                    )
                    DropdownMenuItem(
                        text = { Text("Move to Recently Deleted", color = MaterialTheme.colorScheme.error) },
                        onClick = { menuExpanded = false; onMoveToTrash() }
                    )
                }
            }
        }
    }
}
