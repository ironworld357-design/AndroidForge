package com.example.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import com.example.model.EqPreset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToInt

data class AudioEffectsCapabilities(
    val isAttached: Boolean = false,
    val equalizerSupported: Boolean = false,
    val hardwareBandCount: Int = 5,
    val bassBoostSupported: Boolean = false,
    val virtualizerSupported: Boolean = false,
    val loudnessSupported: Boolean = false
)

class AudioEffectsEngine {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var currentSessionId: Int = 0

    private val _capabilities = MutableStateFlow(AudioEffectsCapabilities())
    val capabilities: StateFlow<AudioEffectsCapabilities> = _capabilities.asStateFlow()

    val bandLabels = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
    val bandCenterHz = listOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

    val builtInPresets: List<EqPreset> = listOf(
        EqPreset("normal", "Normal", listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)),
        EqPreset("bass_boost", "Bass Boost", listOf(6.5f, 5.5f, 4.5f, 2.5f, 1.0f, 0f, 0f, 0.5f, 1.0f, 1.0f)),
        EqPreset("rock", "Rock", listOf(4.5f, 3.5f, 2.0f, 0.5f, -1.0f, -0.5f, 1.5f, 3.5f, 4.5f, 4.5f)),
        EqPreset("pop", "Pop", listOf(-1.0f, 1.5f, 3.0f, 3.5f, 2.0f, 0f, -1.0f, -1.0f, 1.5f, 2.5f)),
        EqPreset("classical", "Classical", listOf(3.5f, 2.5f, 1.5f, 0.5f, -1.0f, -1.0f, 0.5f, 2.0f, 3.0f, 4.0f)),
        EqPreset("jazz", "Jazz", listOf(3.0f, 2.0f, 1.0f, 2.0f, -1.5f, -1.0f, 0.5f, 1.5f, 3.0f, 3.5f)),
        EqPreset("electronic", "Electronic", listOf(5.0f, 4.5f, 2.0f, 0f, -1.5f, 1.0f, 2.5f, 3.5f, 4.5f, 5.0f)),
        EqPreset("hiphop", "Hip-Hop", listOf(5.5f, 5.0f, 3.5f, 1.0f, -1.0f, -0.5f, 1.0f, 1.5f, 2.5f, 3.0f)),
        EqPreset("acoustic", "Acoustic", listOf(2.5f, 2.0f, 1.0f, 0.5f, 1.5f, 1.5f, 2.0f, 2.5f, 3.0f, 2.0f)),
        EqPreset("vocal", "Vocal", listOf(-2.0f, -1.5f, -0.5f, 1.5f, 4.0f, 4.5f, 3.5f, 2.0f, 0.5f, -0.5f))
    )

    fun attachToAudioSession(audioSessionId: Int) {
        if (audioSessionId == 0 || audioSessionId == currentSessionId) return
        release()
        currentSessionId = audioSessionId

        // 10-band EQ is processed deterministically in Media3's VybeDspAudioProcessor
        // so all 10 ISO bands (31Hz..16kHz) work identically across devices without 5-band downsampling.
        val eqOk = true
        val hwBands = 10

        var bassOk = false
        runCatching {
            bassBoost = BassBoost(0, audioSessionId).apply {
                bassOk = strengthSupported
                enabled = bassOk
            }
        }

        var virtOk = false
        runCatching {
            virtualizer = Virtualizer(0, audioSessionId).apply {
                virtOk = strengthSupported
                enabled = virtOk
            }
        }

        var loudOk = false
        runCatching {
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                loudOk = true
            }
        }

        _capabilities.value = AudioEffectsCapabilities(
            isAttached = true,
            equalizerSupported = eqOk,
            hardwareBandCount = hwBands,
            bassBoostSupported = bassOk,
            virtualizerSupported = virtOk,
            loudnessSupported = loudOk
        )
    }

    fun applyEqualizer(enabled: Boolean, bandsDb10: List<Float>) {
        // Ensure legacy hardware Equalizer stays disabled to prevent double-gain stacking;
        // VybeDspAudioProcessor applies the 10-band biquad EQ directly in Media3's AudioSink.
        equalizer?.let { eq ->
            runCatching { eq.enabled = false }
        }
    }

    fun applyBassBoost(enabled: Boolean, strength: Int) {
        val bb = bassBoost ?: return
        runCatching {
            val active = enabled && strength > 0 && bb.strengthSupported
            bb.enabled = active
            if (active) {
                bb.setStrength(strength.coerceIn(0, 1000).toShort())
            }
        }
    }

    fun applyVirtualizer(enabled: Boolean, strength: Int) {
        val virt = virtualizer ?: return
        runCatching {
            val active = enabled && strength > 0 && virt.strengthSupported
            virt.enabled = active
            if (active) {
                virt.setStrength(strength.coerceIn(0, 1000).toShort())
            }
        }
    }

    fun applyLoudnessEnhancer(enabled: Boolean, gainMb: Int) {
        val le = loudnessEnhancer ?: return
        runCatching {
            val active = enabled && gainMb > 0
            le.enabled = active
            if (active) {
                le.setTargetGain(gainMb.coerceIn(0, 1500))
            }
        }
    }

    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        runCatching { loudnessEnhancer?.release() }
        equalizer = null
        bassBoost = null
        virtualizer = null
        loudnessEnhancer = null
        currentSessionId = 0
        _capabilities.value = AudioEffectsCapabilities()
    }
}
