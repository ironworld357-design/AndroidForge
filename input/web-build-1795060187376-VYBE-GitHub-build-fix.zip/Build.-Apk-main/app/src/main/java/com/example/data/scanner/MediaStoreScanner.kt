package com.example.data.scanner

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.data.local.SongEntity
import com.example.model.Song
import com.example.util.AudioTagLyricsExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.sin

class MediaStoreScanner(private val context: Context) {

    suspend fun scanDeviceAudio(
        excludedFolderPaths: Set<String>,
        existingSongsMap: Map<Long, SongEntity>
    ): List<SongEntity> = withContext(Dispatchers.IO) {
        val scanned = mutableListOf<SongEntity>()
        val genreLookup = buildGenreLookupMap()

        val projection = mutableListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.IS_MUSIC
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            projection.add(MediaStore.Audio.Media.GENRE)
            projection.add(MediaStore.Audio.Media.BITRATE)
        }

        val selection = "${MediaStore.Audio.Media.DURATION} > 3000 AND (${MediaStore.Audio.Media.IS_MUSIC} != 0 OR ${MediaStore.Audio.Media.MIME_TYPE} LIKE 'audio/%')"

        runCatching {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection.toTypedArray(),
                selection,
                null,
                "${MediaStore.Audio.Media.TITLE} ASC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val genreCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.GENRE)
                } else -1
                val bitrateCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.BITRATE)
                } else -1

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val filePath = cursor.getString(dataCol) ?: ""
                    val parentFile = File(filePath).parentFile
                    val folderPath = parentFile?.absolutePath ?: "/Music"
                    val folderName = parentFile?.name ?: "Music"

                    if (folderPath in excludedFolderPaths) continue

                    val existing = existingSongsMap[id]
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    ).toString()

                    val rawTitle = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                        ?: File(filePath).nameWithoutExtension.ifBlank { "Track $id" }
                    val rawArtist = cursor.getString(artistCol)
                        ?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "Unknown Artist"
                    val rawAlbum = cursor.getString(albumCol)
                        ?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: folderName
                    val albumId = cursor.getLong(albumIdCol)
                    val durationMs = cursor.getLong(durationCol).coerceAtLeast(0L)
                    val dateAddedSec = cursor.getLong(dateAddedCol)
                    val sizeBytes = cursor.getLong(sizeCol)
                    val mimeType = cursor.getString(mimeCol) ?: "audio/mpeg"
                    val genre = if (genreCol >= 0) {
                        cursor.getString(genreCol)?.takeIf { it.isNotBlank() }
                            ?: genreLookup[id] ?: "Unknown Genre"
                    } else {
                        genreLookup[id] ?: "Unknown Genre"
                    }
                    val bitrateKbps = if (bitrateCol >= 0) {
                        (cursor.getInt(bitrateCol) / 1000).coerceAtLeast(0)
                    } else 0

                    scanned.add(
                        SongEntity(
                            id = id,
                            title = if (existing?.hasUserEditedMetadata == true) existing.title else rawTitle,
                            artist = if (existing?.hasUserEditedMetadata == true) existing.artist else rawArtist,
                            album = if (existing?.hasUserEditedMetadata == true) existing.album else rawAlbum,
                            albumId = albumId,
                            durationMs = durationMs,
                            contentUri = contentUri,
                            filePath = filePath,
                            folderName = folderName,
                            folderPath = folderPath,
                            genre = genre,
                            dateAddedSec = dateAddedSec,
                            sizeBytes = sizeBytes,
                            mimeType = mimeType,
                            bitrateKbps = bitrateKbps,
                            sampleRateHz = existing?.sampleRateHz ?: 44100,
                            customArtworkUri = existing?.customArtworkUri,
                            isFavorite = existing?.isFavorite ?: false,
                            playCount = existing?.playCount ?: 0,
                            lastPlayedAt = existing?.lastPlayedAt ?: 0L,
                            isDeleted = existing?.isDeleted ?: false,
                            deletedAt = existing?.deletedAt ?: 0L,
                            hasUserEditedMetadata = existing?.hasUserEditedMetadata ?: false
                        )
                    )
                }
            }
        }

        // Also scan any locally generated WAV practice/test tracks in filesDir/vybe_samples
        val samplesDir = File(context.filesDir, "vybe_samples")
        if (samplesDir.exists()) {
            val sampleFiles = samplesDir.listFiles { f -> f.extension.equals("wav", ignoreCase = true) }
                ?: emptyArray()
            sampleFiles.sortedBy { it.name }.forEachIndexed { idx, file ->
                if (samplesDir.absolutePath in excludedFolderPaths) return@forEachIndexed
                val syntheticId = -1000L - idx
                val existing = existingSongsMap[syntheticId]
                val meta = sampleTrackMeta(file.nameWithoutExtension)
                scanned.add(
                    SongEntity(
                        id = syntheticId,
                        title = if (existing?.hasUserEditedMetadata == true) existing.title else meta.first,
                        artist = if (existing?.hasUserEditedMetadata == true) existing.artist else meta.second,
                        album = if (existing?.hasUserEditedMetadata == true) existing.album else "VYBE Studio Sessions",
                        albumId = 0L,
                        durationMs = meta.third,
                        contentUri = Uri.fromFile(file).toString(),
                        filePath = file.absolutePath,
                        folderName = "VYBE Studio",
                        folderPath = samplesDir.absolutePath,
                        genre = meta.fourth,
                        dateAddedSec = file.lastModified() / 1000L,
                        sizeBytes = file.length(),
                        mimeType = "audio/wav",
                        bitrateKbps = 1411,
                        sampleRateHz = 44100,
                        customArtworkUri = existing?.customArtworkUri,
                        isFavorite = existing?.isFavorite ?: false,
                        playCount = existing?.playCount ?: 0,
                        lastPlayedAt = existing?.lastPlayedAt ?: 0L,
                        isDeleted = existing?.isDeleted ?: false,
                        deletedAt = existing?.deletedAt ?: 0L,
                        hasUserEditedMetadata = existing?.hasUserEditedMetadata ?: false
                    )
                )
            }
        }

        scanned
    }

    private data class Quad(val first: String, val second: String, val third: Long, val fourth: String)

    private fun sampleTrackMeta(baseName: String): Quad {
        return when (baseName) {
            "neon_horizon" -> Quad("Neon Horizon (Lossless)", "VYBE Synth Lab", 24_000L, "Electronic")
            "velvet_cassette" -> Quad("Velvet Cassette", "Analog Tape Trio", 24_000L, "Lo-Fi Jazz")
            "midnight_acoustic" -> Quad("Midnight Acoustic Jam", "Studio Fretwork", 24_000L, "Acoustic")
            else -> Quad(baseName.replace("_", " "), "VYBE Studio", 20_000L, "Instrumental")
        }
    }

    /**
     * Generates real playable lossless 16-bit 44.1kHz PCM WAV files in internal app storage
     * (plus matching .lrc files) so users on fresh devices/emulators can test playback, EQ,
     * visualizers, vinyl, cassette, and synchronized LRC lyrics immediately offline.
     */
    suspend fun generateLocalTestWavTracks(): Int = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, "vybe_samples").apply { mkdirs() }
        val specs = listOf(
            Triple("neon_horizon", doubleArrayOf(220.0, 277.18, 329.63, 440.0), true),
            Triple("velvet_cassette", doubleArrayOf(196.0, 246.94, 293.66, 369.99), false),
            Triple("midnight_acoustic", doubleArrayOf(164.81, 207.65, 246.94, 329.63), true)
        )
        var created = 0
        for ((name, chordFreqs, bright) in specs) {
            val wavFile = File(dir, "$name.wav")
            if (!wavFile.exists()) {
                writeSynthesizedWav(wavFile, chordFreqs, durationSec = 24, bright = bright)
                created++
            }
            val lrcFile = File(dir, "$name.lrc")
            if (!lrcFile.exists()) {
                lrcFile.writeText(buildSampleLrc(name))
            }
        }
        created
    }

    private fun buildSampleLrc(name: String): String {
        return when (name) {
            "neon_horizon" -> """
                [ti:Neon Horizon (Lossless)]
                [ar:VYBE Synth Lab]
                [00:00.50]Pulse awakens in the obsidian glow
                [00:04.50]Sub-bass harmonics begin to flow
                [00:09.00]Electric blue across the frequency line
                [00:13.50]120 frames in perfect time
                [00:18.00]Feel every beat inside the sound
                [00:21.50]Lossless clarity all around
            """.trimIndent()
            "velvet_cassette" -> """
                [ti:Velvet Cassette]
                [ar:Analog Tape Trio]
                [00:00.50]Magnetic reels begin to spin
                [00:04.50]Warm amber tape hiss drifting in
                [00:09.00]Nostalgic chords from ninety-four
                [00:13.50]Analog needles start to soar
                [00:18.00]Flip to side B in midnight light
                [00:21.50]Spinning cassettes through the night
            """.trimIndent()
            else -> """
                [ti:Midnight Acoustic Jam]
                [ar:Studio Fretwork]
                [00:00.50]Open strings ring clear and true
                [00:04.50]E A D G B E tuned anew
                [00:09.00]Warm wooden resonance fills the room
                [00:13.50]Fingerpicked chords in gentle bloom
                [00:18.00]Steady tempo, breath and tone
                [00:21.50]Acoustic soul, completely your own
            """.trimIndent()
        }
    }

    private fun writeSynthesizedWav(
        target: File,
        chordFreqs: DoubleArray,
        durationSec: Int,
        bright: Boolean
    ) {
        val sampleRate = 44100
        val numChannels = 2
        val bitsPerSample = 16
        val totalSamples = sampleRate * durationSec
        val dataSize = totalSamples * numChannels * (bitsPerSample / 8)
        val byteRate = sampleRate * numChannels * (bitsPerSample / 8)

        FileOutputStream(target).use { out ->
            // RIFF/WAV header (44 bytes)
            val header = ByteArray(44)
            fun writeAscii(offset: Int, text: String) {
                text.toByteArray(Charsets.US_ASCII).copyInto(header, offset)
            }
            fun writeIntLE(offset: Int, v: Int) {
                header[offset] = (v and 0xFF).toByte()
                header[offset + 1] = ((v ushr 8) and 0xFF).toByte()
                header[offset + 2] = ((v ushr 16) and 0xFF).toByte()
                header[offset + 3] = ((v ushr 24) and 0xFF).toByte()
            }
            fun writeShortLE(offset: Int, v: Int) {
                header[offset] = (v and 0xFF).toByte()
                header[offset + 1] = ((v ushr 8) and 0xFF).toByte()
            }

            writeAscii(0, "RIFF")
            writeIntLE(4, 36 + dataSize)
            writeAscii(8, "WAVE")
            writeAscii(12, "fmt ")
            writeIntLE(16, 16) // PCM chunk size
            writeShortLE(20, 1) // PCM format
            writeShortLE(22, numChannels)
            writeIntLE(24, sampleRate)
            writeIntLE(28, byteRate)
            writeShortLE(32, numChannels * (bitsPerSample / 8))
            writeShortLE(34, bitsPerSample)
            writeAscii(36, "data")
            writeIntLE(40, dataSize)
            out.write(header)

            val chunkFrames = 4096
            val buf = ByteArray(chunkFrames * 4)
            var frame = 0
            while (frame < totalSamples) {
                val count = minOf(chunkFrames, totalSamples - frame)
                for (i in 0 until count) {
                    val idx = frame + i
                    val t = idx.toDouble() / sampleRate.toDouble()
                    val beatPhase = (t * 2.0) % 1.0
                    val kickEnv = kotlin.math.exp(-beatPhase * 9.0)
                    val kickFreq = 55.0 + 70.0 * kotlin.math.exp(-beatPhase * 18.0)
                    val kick = sin(2.0 * PI * kickFreq * t) * kickEnv * 0.35

                    val noteIdx = ((t / 2.0).toInt()) % chordFreqs.size
                    val root = chordFreqs[noteIdx]
                    val arpPhase = (t * 4.0) % 1.0
                    val pluckEnv = kotlin.math.exp(-arpPhase * 4.5)
                    val pad = (
                        sin(2.0 * PI * root * t) * 0.28 +
                            sin(2.0 * PI * root * 1.5 * t) * 0.18 +
                            (if (bright) sin(2.0 * PI * root * 2.0 * t) * 0.14 else 0.0)
                        ) * (0.45 + 0.55 * pluckEnv)

                    val fadeEnv = when {
                        t < 0.25 -> t / 0.25
                        t > durationSec - 0.5 -> ((durationSec - t) / 0.5).coerceAtLeast(0.0)
                        else -> 1.0
                    }

                    val stereoPan = sin(2.0 * PI * 0.25 * t) * 0.18
                    val left = ((kick + pad * (1.0 - stereoPan)) * fadeEnv).coerceIn(-0.95, 0.95)
                    val right = ((kick + pad * (1.0 + stereoPan)) * fadeEnv).coerceIn(-0.95, 0.95)

                    val lSample = (left * 32767.0).toInt().toShort().toInt()
                    val rSample = (right * 32767.0).toInt().toShort().toInt()

                    val off = i * 4
                    buf[off] = (lSample and 0xFF).toByte()
                    buf[off + 1] = ((lSample ushr 8) and 0xFF).toByte()
                    buf[off + 2] = (rSample and 0xFF).toByte()
                    buf[off + 3] = ((rSample ushr 8) and 0xFF).toByte()
                }
                out.write(buf, 0, count * 4)
                frame += count
            }
        }
    }

    private fun buildGenreLookupMap(): Map<Long, String> {
        val result = mutableMapOf<Long, String>()
        runCatching {
            context.contentResolver.query(
                MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Genres._ID, MediaStore.Audio.Genres.NAME),
                null,
                null,
                null
            )?.use { gCursor ->
                val gidCol = gCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres._ID)
                val gNameCol = gCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.NAME)
                while (gCursor.moveToNext()) {
                    val genreId = gCursor.getLong(gidCol)
                    val genreName = gCursor.getString(gNameCol)?.takeIf { it.isNotBlank() } ?: continue
                    val membersUri = MediaStore.Audio.Genres.Members.getContentUri("external", genreId)
                    context.contentResolver.query(
                        membersUri,
                        arrayOf(MediaStore.Audio.Genres.Members.AUDIO_ID),
                        null,
                        null,
                        null
                    )?.use { mCursor ->
                        val audioIdCol = mCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.Members.AUDIO_ID)
                        while (mCursor.moveToNext()) {
                            result[mCursor.getLong(audioIdCol)] = genreName
                        }
                    }
                }
            }
        }
        return result
    }

    suspend fun readSidecarLyrics(song: Song): String? = withContext(Dispatchers.IO) {
        if (song.filePath.isBlank()) return@withContext null
        val audioFile = File(song.filePath)
        val parent = audioFile.parentFile ?: return@withContext null
        val baseName = audioFile.nameWithoutExtension

        val exactCandidates = listOf(
            File(parent, "$baseName.lrc"),
            File(parent, "$baseName.LRC"),
            File(parent, "$baseName.txt"),
            File(parent, "$baseName.TXT")
        )
        exactCandidates.firstOrNull { it.exists() && it.canRead() }?.let { candidate ->
            return@withContext runCatching { candidate.readText() }.getOrNull()
        }

        // Case-insensitive directory match fallback (e.g. .Lrc)
        val matched = parent.listFiles()?.firstOrNull { f ->
            f.isFile && f.canRead() &&
                f.nameWithoutExtension.equals(baseName, ignoreCase = true) &&
                (f.extension.equals("lrc", ignoreCase = true) || f.extension.equals("txt", ignoreCase = true))
        }
        matched?.let { runCatching { it.readText() }.getOrNull() }
    }

    suspend fun readEmbeddedLyricsTag(song: Song): AudioTagLyricsExtractor.ExtractedTagLyrics? =
        withContext(Dispatchers.IO) {
            if (song.filePath.isNotBlank()) {
                val file = File(song.filePath)
                AudioTagLyricsExtractor.extractFromFile(file)?.let { return@withContext it }
            }
            if (song.contentUri.isNotBlank()) {
                runCatching {
                    context.contentResolver.openInputStream(Uri.parse(song.contentUri))?.buffered()?.use { stream ->
                        AudioTagLyricsExtractor.extractFromStream(stream)
                    }
                }.getOrNull()?.let { return@withContext it }
            }
            null
        }

    suspend fun extractAudioSpecs(contentUri: String): Pair<Int, Int>? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, Uri.parse(contentUri))
            val bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
                ?.toIntOrNull()?.div(1000) ?: 0
            val sampleRate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)
                    ?.toIntOrNull() ?: 44100
            } else 44100
            bitrate to sampleRate
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }
}
