package com.example.guitar

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

object GuitarToneSynthesizer {

    private const val SAMPLE_RATE = 44100

    fun playReferenceTone(scope: CoroutineScope, frequencyHz: Double, durationMs: Int = 1100) {
        scope.launch(Dispatchers.Default) {
            playPluckedPcm(listOf(frequencyHz), durationMs, strumDelayMs = 0)
        }
    }

    fun playChordArpeggio(scope: CoroutineScope, chord: GuitarChord) {
        val freqs = ChordLibraryData.chordFrequenciesHz(chord)
        if (freqs.isEmpty()) return
        scope.launch(Dispatchers.Default) {
            playPluckedPcm(freqs, totalDurationMs = 1500, strumDelayMs = 45)
        }
    }

    private fun playPluckedPcm(
        frequencies: List<Double>,
        totalDurationMs: Int,
        strumDelayMs: Int
    ) {
        val totalSamples = (SAMPLE_RATE * totalDurationMs) / 1000
        val mixed = DoubleArray(totalSamples)

        frequencies.forEachIndexed { idx, freq ->
            val startSample = (idx * strumDelayMs * SAMPLE_RATE) / 1000
            for (i in startSample until totalSamples) {
                val t = (i - startSample).toDouble() / SAMPLE_RATE.toDouble()
                val env = exp(-t * 3.4) * (1.0 - exp(-t * 220.0))
                val sample = (
                    sin(2.0 * PI * freq * t) * 0.65 +
                        sin(2.0 * PI * freq * 2.0 * t) * 0.25 +
                        sin(2.0 * PI * freq * 3.0 * t) * 0.12
                    ) * env * 0.35
                mixed[i] += sample
            }
        }

        val pcm = ShortArray(totalSamples) { i ->
            (mixed[i].coerceIn(-0.95, 0.95) * 32767.0).toInt().toShort()
        }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        runCatching {
            track.write(pcm, 0, pcm.size)
            track.play()
            Thread.sleep(totalDurationMs.toLong() + 80L)
            track.stop()
            track.release()
        }
    }
}
