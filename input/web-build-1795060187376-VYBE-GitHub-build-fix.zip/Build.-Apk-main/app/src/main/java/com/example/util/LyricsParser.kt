package com.example.util

import com.example.model.LyricLine
import com.example.model.LyricsData

object LyricsParser {

    private val lrcLineRegex = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?](.*)""")
    private val timeTagRegex = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private val inlineWordTagRegex = Regex("""<\d{1,3}:\d{2}(?:[.:]\d{1,3})?>""")
    private val metadataTagRegex = Regex("""^\[(ti|ar|al|by|offset|length|re|ve):(.*)]$""", RegexOption.IGNORE_CASE)

    fun parse(songId: Long, rawText: String, sourceLabel: String): LyricsData {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) {
            return LyricsData(
                songId = songId,
                rawText = "",
                lines = emptyList(),
                isSynchronized = false,
                sourceLabel = sourceLabel
            )
        }

        var metaTitle: String? = null
        var metaArtist: String? = null
        var offsetMs = 0L

        val timedEntries = mutableListOf<Pair<Long, String>>()
        var hasTimestamps = false

        trimmed.lines().forEach { line ->
            val cleanLine = line.trim()
            if (cleanLine.isEmpty()) return@forEach

            val metaMatch = metadataTagRegex.matchEntire(cleanLine)
            if (metaMatch != null) {
                val key = metaMatch.groupValues[1].lowercase()
                val value = metaMatch.groupValues[2].trim()
                when (key) {
                    "ti" -> if (value.isNotEmpty()) metaTitle = value
                    "ar" -> if (value.isNotEmpty()) metaArtist = value
                    "offset" -> offsetMs = value.toLongOrNull() ?: 0L
                }
                return@forEach
            }

            val matches = lrcLineRegex.findAll(cleanLine).toList()
            if (matches.isNotEmpty()) {
                hasTimestamps = true
                // Extract actual lyric text after the last [mm:ss.xx] tag and clean enhanced <mm:ss.xx> tags
                val lastMatch = matches.last()
                val textPart = lastMatch.groupValues[4]
                    .replace(inlineWordTagRegex, "")
                    .trim()
                // Support multi-timestamp lines like [00:12.00][01:02.00]Chorus
                val tagMatches = timeTagRegex.findAll(cleanLine)
                for (m in tagMatches) {
                    val minutes = m.groupValues[1].toLongOrNull() ?: 0L
                    val seconds = m.groupValues[2].toLongOrNull() ?: 0L
                    val fractionStr = m.groupValues[3]
                    val millis = when (fractionStr.length) {
                        0 -> 0L
                        1 -> (fractionStr.toLongOrNull() ?: 0L) * 100L
                        2 -> (fractionStr.toLongOrNull() ?: 0L) * 10L
                        else -> fractionStr.take(3).toLongOrNull() ?: 0L
                    }
                    val totalMs = minutes * 60_000L + seconds * 1_000L + millis
                    if (textPart.isNotEmpty()) {
                        timedEntries.add(totalMs to textPart)
                    }
                }
            }
        }

        return if (hasTimestamps && timedEntries.isNotEmpty()) {
            // Apply [offset:+/-ms] tag (+ shifts timestamps earlier by subtracting offset, standard LRC convention)
            val sorted = timedEntries
                .map { (rawTs, text) ->
                    LyricLine(
                        timestampMs = (rawTs - offsetMs).coerceAtLeast(0L),
                        text = text
                    )
                }
                .sortedBy { it.timestampMs ?: 0L }

            LyricsData(
                songId = songId,
                rawText = trimmed,
                lines = sorted,
                isSynchronized = true,
                sourceLabel = sourceLabel,
                offsetMs = offsetMs,
                metadataTitle = metaTitle,
                metadataArtist = metaArtist
            )
        } else {
            // Strictly mark as NOT synchronized when timing info is unavailable
            val allPlain = trimmed.lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !metadataTagRegex.matches(it) }
                .map { LyricLine(timestampMs = null, text = it) }
            LyricsData(
                songId = songId,
                rawText = trimmed,
                lines = allPlain,
                isSynchronized = false,
                sourceLabel = sourceLabel,
                offsetMs = offsetMs,
                metadataTitle = metaTitle,
                metadataArtist = metaArtist
            )
        }
    }

    fun activeLineIndex(
        lines: List<LyricLine>,
        positionMs: Long,
        isSynchronized: Boolean,
        syncOffsetMs: Long = 0L
    ): Int {
        if (!isSynchronized || lines.isEmpty()) return -1
        val adjustedPos = positionMs + syncOffsetMs
        var active = -1
        for (i in lines.indices) {
            val ts = lines[i].timestampMs ?: continue
            if (ts <= adjustedPos + 120L) {
                active = i
            } else {
                break
            }
        }
        return active
    }

    /**
     * Normalized 0..1 progress within the active lyric line's duration window.
     */
    fun activeLineProgress(
        lines: List<LyricLine>,
        activeIndex: Int,
        positionMs: Long,
        trackDurationMs: Long,
        syncOffsetMs: Long = 0L
    ): Float {
        if (activeIndex !in lines.indices) return 0f
        val start = lines[activeIndex].timestampMs ?: return 0f
        val next = lines.getOrNull(activeIndex + 1)?.timestampMs ?: trackDurationMs.coerceAtLeast(start + 3500L)
        val span = (next - start).coerceAtLeast(400L)
        val elapsed = ((positionMs + syncOffsetMs) - start).coerceIn(0L, span)
        return (elapsed.toFloat() / span.toFloat()).coerceIn(0f, 1f)
    }
}
