package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode as AnimRepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.PlaybackUiState
import com.example.model.ArtworkStyle
import com.example.model.RepeatMode
import com.example.model.Song
import com.example.ui.theme.LocalVybeStyle
import com.example.util.TimeFormatter
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Frosted Aurora multi-orb mesh background inspired by the Aurora Glass, Liquid Smoke & Halo Orchid themes.
 */
@Composable
fun AuroraMeshBackground(
    animationsEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val inf = rememberInfiniteTransition(label = "auroraMesh")
    val drift by inf.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 7500, easing = FastOutSlowInEasing),
            repeatMode = AnimRepeatMode.Reverse
        ),
        label = "meshDrift"
    )
    val t = if (animationsEnabled) drift else 0.35f

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(color = vybe.bgDeep)

        // Top primary aurora bloom
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    vybe.meshTopColor.copy(alpha = 0.72f),
                    vybe.meshTopColor.copy(alpha = 0.22f),
                    Color.Transparent
                ),
                center = Offset(size.width * (0.28f + 0.16f * t), size.height * 0.14f),
                radius = size.width * 0.95f
            ),
            radius = size.width * 0.95f,
            center = Offset(size.width * (0.28f + 0.16f * t), size.height * 0.14f)
        )

        // Mid electric mist bloom
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    vybe.meshMidColor.copy(alpha = 0.52f),
                    vybe.accentSecondary.copy(alpha = 0.16f),
                    Color.Transparent
                ),
                center = Offset(size.width * (0.78f - 0.14f * t), size.height * 0.44f),
                radius = size.width * 0.85f
            ),
            radius = size.width * 0.85f,
            center = Offset(size.width * (0.78f - 0.14f * t), size.height * 0.44f)
        )

        // Lower accent wash
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    vybe.accentPrimary.copy(alpha = 0.26f),
                    Color.Transparent
                ),
                center = Offset(size.width * 0.5f, size.height * 0.86f),
                radius = size.width * 0.9f
            ),
            radius = size.width * 0.9f,
            center = Offset(size.width * 0.5f, size.height * 0.86f)
        )
    }
}

/**
 * Screenshot 1 Addon Layout: Full-bleed frosted artwork + Curved Orbital Arc Scrubber + Plasma Play Core.
 */
@Composable
fun OrbitalArcDeck(
    playbackState: PlaybackUiState,
    artworkStyle: ArtworkStyle,
    displayPosMs: Long,
    durationMs: Long,
    animationsEnabled: Boolean,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val song = playbackState.currentSong
    val progress = (displayPosMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)

    val inf = rememberInfiniteTransition(label = "orbitalCore")
    val corePulse by inf.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), AnimRepeatMode.Reverse),
        label = "orbitalPulse"
    )
    val playScale by animateFloatAsState(
        targetValue = if (playbackState.isPlaying) 1.06f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "orbitalPlayScale"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Full-bleed frosted art frame with title overlay
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
                .clip(RoundedCornerShape(28.dp))
                .border(1.2.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(28.dp))
        ) {
            VybeArtwork(
                model = song?.artworkModel,
                contentDescription = song?.title ?: "Album Art",
                style = artworkStyle,
                cornerRadius = 28.dp,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Transparent,
                                vybe.bgDeep.copy(alpha = 0.35f),
                                vybe.bgDeep.copy(alpha = 0.88f)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(18.dp)
            ) {
                Text(
                    text = song?.title ?: "Select a Track",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (song != null) "${song.artist} • ${song.album}" else "Offline Studio Ready",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.78f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Curved Semi-Circular Orbital Arc & Plasma Play Core
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("orbital_arc_scrubber")
                    .pointerInput(durationMs) {
                        detectTapGestures { tap ->
                            val cx = size.width / 2f
                            val cy = size.height * 0.92f
                            val angleRad = atan2(cy - tap.y, tap.x - cx)
                            val degFromLeft = Math.toDegrees(PI - angleRad).toFloat().coerceIn(22f, 158f)
                            val frac = ((degFromLeft - 22f) / 136f).coerceIn(0f, 1f)
                            onSeekTo((frac * durationMs).toLong())
                        }
                    }
            ) {
                val radius = size.minDimension * 0.78f
                val topLeft = Offset(size.width / 2f - radius, size.height * 0.92f - radius)
                val arcSize = Size(radius * 2f, radius * 2f)

                // Outer frosted glass dome arc backdrop
                drawArc(
                    brush = Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.14f),
                            vybe.accentPrimary.copy(alpha = 0.08f),
                            Color.Transparent
                        )
                    ),
                    startAngle = 195f,
                    sweepAngle = 150f,
                    useCenter = true,
                    topLeft = topLeft,
                    size = arcSize
                )

                // Track arc (202° to 338° = 136° sweep across top)
                drawArc(
                    color = Color.White.copy(alpha = 0.22f),
                    startAngle = 202f,
                    sweepAngle = 136f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                )

                // Active progress arc
                drawArc(
                    brush = Brush.horizontalGradient(listOf(vybe.accentSecondary, Color.White, vybe.accentPrimary)),
                    startAngle = 202f,
                    sweepAngle = 136f * progress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = 4.5.dp.toPx(), cap = StrokeCap.Round)
                )

                // Glowing Orbital Thumb Dot
                val thumbAngleRad = Math.toRadians((202f + 136f * progress).toDouble())
                val cx = size.width / 2f
                val cy = size.height * 0.92f
                val thumbPos = Offset(
                    cx + (radius * cos(thumbAngleRad)).toFloat(),
                    cy + (radius * sin(thumbAngleRad)).toFloat()
                )
                drawCircle(color = vybe.accentSecondary.copy(alpha = 0.35f), radius = 12.dp.toPx(), center = thumbPos)
                drawCircle(color = Color.White, radius = 6.dp.toPx(), center = thumbPos)
            }

            // Heart badge tucked under the top of the arc
            if (song != null) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 42.dp)
                        .clickable { onToggleFavorite(song) },
                    shape = CircleShape,
                    color = vybe.surfaceCard.copy(alpha = 0.8f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
                ) {
                    Icon(
                        imageVector = if (song.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (song.isFavorite) vybe.accentSecondary else Color.White,
                        modifier = Modifier.padding(8.dp).size(18.dp)
                    )
                }
            }

            // Curved Floating Transport Controls + Glowing Orbital Play/Pause Core
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onToggleShuffle,
                    modifier = Modifier.testTag("orbital_shuffle_btn")
                ) {
                    Icon(
                        Icons.Filled.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (playbackState.shuffleEnabled) vybe.accentSecondary else vybe.textPrimary.copy(alpha = 0.72f)
                    )
                }
                Surface(
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("orbital_prev_btn")
                        .clickable(onClick = onPrevious),
                    shape = CircleShape,
                    color = vybe.surfaceCard.copy(alpha = 0.75f),
                    border = BorderStroke(1.dp, vybe.cardBorder)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = vybe.textPrimary)
                    }
                }

                // Glowing Plasma Play/Pause Orb
                Box(contentAlignment = Alignment.Center) {
                    if (animationsEnabled) {
                        Box(
                            modifier = Modifier
                                .size(92.dp)
                                .scale(if (playbackState.isPlaying) corePulse else 0.92f)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(
                                            vybe.accentPrimary.copy(alpha = 0.8f),
                                            vybe.accentSecondary.copy(alpha = 0.35f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                    }
                    Surface(
                        modifier = Modifier
                            .size(66.dp)
                            .scale(playScale)
                            .testTag("orbital_play_pause_btn")
                            .clickable(onClick = onPlayPause),
                        shape = CircleShape,
                        color = Color.White,
                        shadowElevation = 10.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (playbackState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (playbackState.isPlaying) "Pause" else "Play",
                                tint = vybe.accentPrimary,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    }
                }

                Surface(
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("orbital_next_btn")
                        .clickable(onClick = onNext),
                    shape = CircleShape,
                    color = vybe.surfaceCard.copy(alpha = 0.75f),
                    border = BorderStroke(1.dp, vybe.cardBorder)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = vybe.textPrimary)
                    }
                }
                IconButton(
                    onClick = onCycleRepeat,
                    modifier = Modifier.testTag("orbital_repeat_btn")
                ) {
                    Icon(
                        imageVector = if (playbackState.repeatMode == RepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        contentDescription = "Repeat",
                        tint = if (playbackState.repeatMode != RepeatMode.OFF) vybe.accentSecondary else vybe.textPrimary.copy(alpha = 0.72f)
                    )
                }
            }
        }
    }
}

/**
 * Screenshots 3 & 5 Addon Layout: Concentric Halo Rings + Peeking Adjacent Discs + Circular Radial Progress Ring.
 */
@Composable
fun HaloCarouselDeck(
    playbackState: PlaybackUiState,
    displayPosMs: Long,
    durationMs: Long,
    animationsEnabled: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val queue = playbackState.queue
    val curIdx = playbackState.currentIndex
    val prevSong = if (curIdx > 0) queue.getOrNull(curIdx - 1) else null
    val nextSong = if (curIdx >= 0) queue.getOrNull(curIdx + 1) else null
    val curSong = playbackState.currentSong
    val progress = (displayPosMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)

    val inf = rememberInfiniteTransition(label = "haloRing")
    val ringScale by inf.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), AnimRepeatMode.Reverse),
        label = "haloRingScale"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(276.dp),
            contentAlignment = Alignment.Center
        ) {
            // Left peeking previous track disc
            if (prevSong != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .size(110.dp)
                        .alpha(0.55f)
                        .clickable(onClick = onPrevious)
                ) {
                    VybeArtwork(
                        model = prevSong.artworkModel,
                        contentDescription = prevSong.title,
                        style = ArtworkStyle.VINYL_DISC,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Right peeking next track disc
            if (nextSong != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .size(110.dp)
                        .alpha(0.55f)
                        .clickable(onClick = onNext)
                ) {
                    VybeArtwork(
                        model = nextSong.artworkModel,
                        contentDescription = nextSong.title,
                        style = ArtworkStyle.VINYL_DISC,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Concentric Halo Rings + Curved Radial Progress Ring around Central Artwork
            Canvas(
                modifier = Modifier
                    .size(258.dp)
                    .scale(if (playbackState.isPlaying && animationsEnabled) ringScale else 1f)
            ) {
                val r = size.minDimension / 2f
                val center = Offset(size.width / 2f, size.height / 2f)

                drawCircle(
                    color = Color.White.copy(alpha = 0.10f),
                    radius = r * 0.98f,
                    center = center,
                    style = Stroke(width = 1.dp.toPx())
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(
                            vybe.accentPrimary.copy(alpha = 0.22f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = r * 0.95f
                    ),
                    radius = r * 0.95f,
                    center = center
                )

                val arcPad = 14.dp.toPx()
                val arcSize = Size(size.width - arcPad * 2, size.height - arcPad * 2)
                drawArc(
                    color = Color.White.copy(alpha = 0.18f),
                    startAngle = -210f,
                    sweepAngle = 240f,
                    useCenter = false,
                    topLeft = Offset(arcPad, arcPad),
                    size = arcSize,
                    style = Stroke(width = 2.8.dp.toPx(), cap = StrokeCap.Round)
                )
                drawArc(
                    brush = Brush.sweepGradient(listOf(vybe.accentPrimary, vybe.accentSecondary, Color.White)),
                    startAngle = -210f,
                    sweepAngle = 240f * progress,
                    useCenter = false,
                    topLeft = Offset(arcPad, arcPad),
                    size = arcSize,
                    style = Stroke(width = 3.6.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Central Circular Artwork
            VybeArtwork(
                model = curSong?.artworkModel,
                contentDescription = curSong?.title ?: "Track Artwork",
                style = ArtworkStyle.HALO_RING,
                isPlaying = playbackState.isPlaying && animationsEnabled,
                playbackSpeed = playbackState.playbackSpeed,
                spinEnabled = true,
                modifier = Modifier.size(182.dp)
            )

            // Remaining duration badge at bottom of halo
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 8.dp),
                shape = RoundedCornerShape(50),
                color = vybe.surfaceCard.copy(alpha = 0.9f),
                border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.2f))
            ) {
                Text(
                    text = TimeFormatter.formatDuration(displayPosMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = vybe.textPrimary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                )
            }
        }
    }
}

/**
 * Screenshots 2 & 4 Addon Layout: Coverflow Peek Cards + Interactive Live Soundwave Seekbar.
 */
@Composable
fun WaveformCoverflowDeck(
    playbackState: PlaybackUiState,
    artworkStyle: ArtworkStyle,
    displayPosMs: Long,
    durationMs: Long,
    animationsEnabled: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val queue = playbackState.queue
    val curIdx = playbackState.currentIndex
    val prevSong = if (curIdx > 0) queue.getOrNull(curIdx - 1) else null
    val nextSong = if (curIdx >= 0) queue.getOrNull(curIdx + 1) else null
    val curSong = playbackState.currentSong
    val progress = (displayPosMs.toFloat() / durationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)

    // Deterministic per-song waveform envelope so every track displays a distinct soundwave silhouette
    val waveHeights = remember(curSong?.id) {
        val seed = (curSong?.id ?: 7L).toInt()
        List(44) { i ->
            val v = sin(i * 0.42 + seed * 0.7) * 0.4 + cos(i * 0.91 - seed * 0.3) * 0.35 + 0.55
            v.toFloat().coerceIn(0.18f, 1.0f)
        }
    }

    val inf = rememberInfiniteTransition(label = "waveBarPulse")
    val pulsePhase by inf.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(2000)),
        label = "wavePhase"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Coverflow Peek Showcase
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp),
            contentAlignment = Alignment.Center
        ) {
            if (prevSong != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .size(width = 76.dp, height = 185.dp)
                        .alpha(0.5f)
                        .clickable(onClick = onPrevious)
                ) {
                    VybeArtwork(
                        model = prevSong.artworkModel,
                        contentDescription = prevSong.title,
                        style = artworkStyle,
                        cornerRadius = 18.dp,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
            if (nextSong != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .size(width = 76.dp, height = 185.dp)
                        .alpha(0.5f)
                        .clickable(onClick = onNext)
                ) {
                    VybeArtwork(
                        model = nextSong.artworkModel,
                        contentDescription = nextSong.title,
                        style = artworkStyle,
                        cornerRadius = 18.dp,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            VybeArtwork(
                model = curSong?.artworkModel,
                contentDescription = curSong?.title ?: "Cover",
                style = artworkStyle,
                cornerRadius = 26.dp,
                isPlaying = playbackState.isPlaying && animationsEnabled,
                playbackSpeed = playbackState.playbackSpeed,
                spinEnabled = true,
                modifier = Modifier.size(236.dp)
            )
        }

        // Interactive Soundwave Seekbar (tap or drag across bars to scrub track)
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("wave_coverflow_scrubber")
                .pointerInput(durationMs) {
                    detectTapGestures { offset ->
                        val frac = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                        onSeekTo((frac * durationMs).toLong())
                    }
                }
                .pointerInput(durationMs) {
                    detectHorizontalDragGestures { change, _ ->
                        change.consume()
                        val frac = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                        onSeekTo((frac * durationMs).toLong())
                    }
                }
        ) {
            val count = waveHeights.size
            val slotW = size.width / count
            val barW = (slotW * 0.56f).coerceAtLeast(2.dp.toPx())
            val midY = size.height / 2f

            for (i in 0 until count) {
                val frac = i / count.toFloat()
                val isPlayed = frac <= progress
                val liveBoost = if (playbackState.isPlaying && animationsEnabled) {
                    1f + 0.14f * sin(pulsePhase + i * 0.65f)
                } else 1f
                val h = (size.height * 0.86f * waveHeights[i] * liveBoost).coerceIn(6.dp.toPx(), size.height)
                val x = i * slotW + (slotW - barW) / 2f
                drawRoundRect(
                    color = if (isPlayed) vybe.accentSecondary else vybe.textMuted.copy(alpha = 0.35f),
                    topLeft = Offset(x, midY - h / 2f),
                    size = Size(barW, h),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
            }
        }
    }
}
