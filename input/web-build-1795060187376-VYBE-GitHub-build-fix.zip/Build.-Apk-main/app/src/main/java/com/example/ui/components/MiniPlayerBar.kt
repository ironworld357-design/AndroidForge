package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.PlaybackUiState
import com.example.model.ArtworkStyle
import com.example.ui.theme.LocalVybeStyle
import com.example.ui.theme.RetroAmber
import com.example.ui.theme.RetroCream
import com.example.util.rememberVybeHaptics
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun MiniPlayerBar(
    playbackState: PlaybackUiState,
    artworkStyle: ArtworkStyle,
    onOpenNowPlaying: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    hapticsEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val song = playbackState.currentSong
    val vybe = LocalVybeStyle.current
    val haptics = rememberVybeHaptics(hapticsEnabled)

    AnimatedVisibility(
        visible = song != null,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(tween(220)),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(tween(180))
    ) {
        if (song == null) return@AnimatedVisibility

        val progress = if (playbackState.durationMs > 0L) {
            (playbackState.positionMs.toFloat() / playbackState.durationMs.toFloat()).coerceIn(0f, 1f)
        } else 0f

        var dragOffsetX by remember { mutableFloatStateOf(0f) }
        val animatedDragX by animateFloatAsState(
            targetValue = dragOffsetX,
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
            label = "miniPlayerSwipe"
        )

        val playScale by animateFloatAsState(
            targetValue = if (playbackState.isPlaying) 1.06f else 1.0f,
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
            label = "miniPlayScale"
        )

        val reelRotation = rememberVinylRotationAngle(
            isPlaying = playbackState.isPlaying,
            playbackSpeed = playbackState.playbackSpeed,
            enabled = true,
            baseDegPerSec = 100f
        )
        val infiniteTransition = rememberInfiniteTransition(label = "miniGlow")
        val glowPulse by infiniteTransition.animateFloat(
            initialValue = 0.35f,
            targetValue = 0.85f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 1400),
                repeatMode = RepeatMode.Reverse
            ),
            label = "miniGlowPulse"
        )

        Surface(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .offset { IntOffset(animatedDragX.roundToInt(), 0) }
                .pointerInput(song.id) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            if (dragOffsetX < -90f) {
                                haptics.skip()
                                onNext()
                            } else if (dragOffsetX > 90f) {
                                haptics.skip()
                                onPrevious()
                            }
                            dragOffsetX = 0f
                        },
                        onDragCancel = { dragOffsetX = 0f },
                        onHorizontalDrag = { _, dragAmount ->
                            dragOffsetX = (dragOffsetX + dragAmount * 0.65f).coerceIn(-150f, 150f)
                        }
                    )
                }
                .testTag("mini_player_bar")
                .clickable(onClick = onOpenNowPlaying),
            shape = RoundedCornerShape(vybe.cardRadius),
            color = vybe.surfaceCard.copy(alpha = 0.96f),
            border = BorderStroke(
                width = if (playbackState.isPlaying) 1.25.dp else 1.dp,
                color = if (playbackState.isPlaying) {
                    vybe.accentSecondary.copy(alpha = glowPulse * 0.7f)
                } else vybe.cardBorder
            ),
            shadowElevation = 10.dp
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (vybe.isRetro) {
                                Brush.horizontalGradient(
                                    listOf(vybe.surfaceElevated, vybe.surfaceCard)
                                )
                            } else {
                                Brush.horizontalGradient(
                                    listOf(
                                        vybe.accentPrimary.copy(alpha = if (playbackState.isPlaying) 0.20f else 0.12f),
                                        vybe.surfaceCard
                                    )
                                )
                            }
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (vybe.isRetro) {
                        Canvas(modifier = Modifier.size(44.dp)) {
                            val c = Offset(size.width / 2f, size.height / 2f)
                            val r = size.minDimension / 2f
                            drawCircle(color = Color(0xFF1A1410), radius = r, center = c)
                            drawCircle(color = RetroCream, radius = r * 0.65f, center = c)
                            drawCircle(color = Color(0xFF1A1410), radius = r * 0.42f, center = c)
                            rotate(reelRotation, pivot = c) {
                                for (i in 0 until 3) {
                                    val a = i * 120.0 * PI / 180.0
                                    drawLine(
                                        color = RetroAmber,
                                        start = Offset(c.x + cos(a).toFloat() * r * 0.25f, c.y + sin(a).toFloat() * r * 0.25f),
                                        end = Offset(c.x + cos(a).toFloat() * r * 0.62f, c.y + sin(a).toFloat() * r * 0.62f),
                                        strokeWidth = 2.dp.toPx()
                                    )
                                }
                            }
                        }
                    } else {
                        VybeArtwork(
                            model = song.artworkModel,
                            contentDescription = song.title,
                            style = artworkStyle,
                            cornerRadius = 10.dp,
                            isPlaying = playbackState.isPlaying,
                            playbackSpeed = playbackState.playbackSpeed,
                            spinEnabled = true,
                            modifier = Modifier.size(44.dp)
                        )
                    }

                    Spacer(Modifier.width(12.dp))

                    AnimatedContent(
                        targetState = song.id,
                        transitionSpec = {
                            val dir = playbackState.skipDirection
                            (slideInHorizontally(tween(240)) { it * dir / 2 } + fadeIn(tween(200))) togetherWith
                                (slideOutHorizontally(tween(200)) { -it * dir / 2 } + fadeOut(tween(150)))
                        },
                        modifier = Modifier.weight(1f),
                        label = "miniSongInfo"
                    ) { _ ->
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = song.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = vybe.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                if (playbackState.isPlaying) {
                                    AnimatedEqBars(
                                        isPlaying = true,
                                        color = vybe.accentSecondary,
                                        modifier = Modifier.size(width = 14.dp, height = 11.dp),
                                        barCount = 3
                                    )
                                }
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = song.artist,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = vybe.textMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                Text(
                                    text = "• ${song.formatBadge}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = vybe.accentSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = {
                            haptics.skip()
                            onPrevious()
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("mini_prev_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SkipPrevious,
                            contentDescription = "Previous track",
                            tint = vybe.textPrimary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .scale(playScale)
                            .clip(CircleShape)
                            .background(vybe.accentGradient)
                            .testTag("mini_play_pause_button")
                            .clickable {
                                haptics.playPause()
                                onPlayPause()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        AnimatedContent(
                            targetState = playbackState.isPlaying,
                            transitionSpec = { fadeIn(tween(150)) togetherWith fadeOut(tween(150)) },
                            label = "miniPlayIcon"
                        ) { playing ->
                            Icon(
                                imageVector = if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (playing) "Pause" else "Play",
                                tint = if (vybe.isRetro) Color(0xFF1D1309) else Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            haptics.skip()
                            onNext()
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("mini_next_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SkipNext,
                            contentDescription = "Next track",
                            tint = vybe.textPrimary
                        )
                    }
                }

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.5.dp),
                    color = vybe.accentSecondary,
                    trackColor = vybe.surfaceElevated
                )
            }
        }
    }
}
