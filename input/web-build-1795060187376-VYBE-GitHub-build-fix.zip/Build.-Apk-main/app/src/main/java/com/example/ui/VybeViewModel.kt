package com.example.ui

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.VybeApplication
import com.example.audio.AudioEffectsCapabilities
import com.example.audio.PlaybackUiState
import com.example.data.local.ExcludedFolderEntity
import com.example.data.local.VybeSettings
import com.example.guitar.ChordCategory
import com.example.guitar.ChordLibraryData
import com.example.guitar.GuitarChord
import com.example.guitar.GuitarToneSynthesizer
import com.example.guitar.MetronomeEngine
import com.example.guitar.MetronomeState
import com.example.guitar.PitchDetector
import com.example.guitar.TimeSignature
import com.example.guitar.TunerState
import com.example.model.AccentPreset
import com.example.model.AlbumGroup
import com.example.model.AppearanceMode
import com.example.model.ArtistGroup
import com.example.model.ArtworkStyle
import com.example.model.CrossfadeCurve
import com.example.model.DisplayRefreshInfo
import com.example.model.DuplicateGroup
import com.example.model.EqPreset
import com.example.model.FolderGroup
import com.example.model.GenreGroup
import com.example.model.HeadphoneProfile
import com.example.model.ListeningStatSummary
import com.example.model.LyricsData
import com.example.model.NavDockStyle
import com.example.model.PerformanceMode
import com.example.model.PlayerBackgroundStyle
import com.example.model.PlayerLayoutStyle
import com.example.model.Playlist
import com.example.model.Song
import com.example.model.SongSortOrder
import com.example.model.VisualizerSize
import com.example.model.VisualizerStyle
import com.example.model.VybeThemeMode
import com.example.util.DisplayRefreshRateManager
import com.example.util.TimeFormatter
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.URLEncoder

data class StorageSummary(
    val totalLibraryBytes: Long = 0L,
    val availableDeviceBytes: Long = 0L,
    val totalDeviceBytes: Long = 0L,
    val trackCount: Int = 0,
    val losslessCount: Int = 0
)

data class PracticeToolsState(
    val timerRunning: Boolean = false,
    val timerElapsedSec: Int = 0,
    val bpmTrainerActive: Boolean = false,
    val bpmTrainerStart: Int = 70,
    val bpmTrainerTarget: Int = 120,
    val bpmTrainerStepBars: Int = 4,
    val selectedProgressionId: String = "pop_g",
    val activeProgressionIndex: Int = 0
)

class VybeViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as VybeApplication
    val musicRepository = app.musicRepository
    val settingsDataStore = app.settingsDataStore
    val playerController = app.playerController
    val dspProcessor = app.dspProcessor
    val audioEffectsEngine = app.audioEffectsEngine

    private val pitchDetector = PitchDetector()
    private val metronomeEngine = MetronomeEngine()

    val settings: StateFlow<VybeSettings> = settingsDataStore.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, VybeSettings())

    val playbackState: StateFlow<PlaybackUiState> = playerController.playbackState
    val eqCapabilities: StateFlow<AudioEffectsCapabilities> = audioEffectsEngine.capabilities
    val tunerState: StateFlow<TunerState> = pitchDetector.tunerState
    val metronomeState: StateFlow<MetronomeState> = metronomeEngine.state

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _currentLyrics = MutableStateFlow<LyricsData?>(null)
    val currentLyrics: StateFlow<LyricsData?> = _currentLyrics.asStateFlow()

    private val _displayRefreshInfo = MutableStateFlow(DisplayRefreshRateManager.queryDisplayInfo(app))
    val displayRefreshInfo: StateFlow<DisplayRefreshInfo> = _displayRefreshInfo.asStateFlow()

    private val _practiceTools = MutableStateFlow(PracticeToolsState())
    val practiceTools: StateFlow<PracticeToolsState> = _practiceTools.asStateFlow()

    private var practiceTimerJob: Job? = null

    val allSongs: StateFlow<List<Song>> = combine(
        musicRepository.songsFlow,
        settings
    ) { songs, prefs ->
        val sorted = when (prefs.sortOrder) {
            SongSortOrder.TITLE -> songs.sortedBy { it.title.lowercase() }
            SongSortOrder.ARTIST -> songs.sortedBy { it.artist.lowercase() }
            SongSortOrder.ALBUM -> songs.sortedBy { it.album.lowercase() }
            SongSortOrder.DURATION -> songs.sortedBy { it.durationMs }
            SongSortOrder.DATE_ADDED -> songs.sortedBy { it.dateAddedSec }
        }
        if (prefs.sortAscending) sorted else sorted.reversed()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredSongs: StateFlow<List<Song>> = combine(allSongs, _searchQuery) { songs, q ->
        val query = q.trim()
        if (query.isEmpty()) songs
        else songs.filter {
            it.title.contains(query, ignoreCase = true) ||
                it.artist.contains(query, ignoreCase = true) ||
                it.album.contains(query, ignoreCase = true) ||
                it.genre.contains(query, ignoreCase = true) ||
                it.folderName.contains(query, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val albums: StateFlow<List<AlbumGroup>> = combine(allSongs, _searchQuery) { songs, q ->
        val list = musicRepository.buildAlbums(songs)
        if (q.isBlank()) list else list.filter {
            it.name.contains(q, true) || it.artist.contains(q, true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val artists: StateFlow<List<ArtistGroup>> = combine(allSongs, _searchQuery) { songs, q ->
        val list = musicRepository.buildArtists(songs)
        if (q.isBlank()) list else list.filter { it.name.contains(q, true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val folders: StateFlow<List<FolderGroup>> = allSongs.combine(_searchQuery) { songs, q ->
        val list = musicRepository.buildFolders(songs)
        if (q.isBlank()) list else list.filter { it.folderName.contains(q, true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val genres: StateFlow<List<GenreGroup>> = allSongs.combine(_searchQuery) { songs, q ->
        val list = musicRepository.buildGenres(songs)
        if (q.isBlank()) list else list.filter { it.name.contains(q, true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deletedSongs: StateFlow<List<Song>> = musicRepository.deletedSongsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val excludedFolders: StateFlow<List<ExcludedFolderEntity>> = musicRepository.excludedFoldersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customPlaylists: StateFlow<List<Playlist>> = musicRepository.customPlaylistsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val smartPlaylists: StateFlow<List<Playlist>> = musicRepository.smartPlaylistsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customEqPresets: StateFlow<List<EqPreset>> = musicRepository.customEqPresetsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val statsSummary: StateFlow<ListeningStatSummary> = musicRepository.statsSummaryFlow
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            ListeningStatSummary(0, 0L, emptyList(), emptyList(), emptyList(), emptyList(), emptyList())
        )

    val storageSummary: StateFlow<StorageSummary> = allSongs.combine(_isScanning) { songs, _ ->
        val stat = runCatching { StatFs(Environment.getDataDirectory().path) }.getOrNull()
        StorageSummary(
            totalLibraryBytes = songs.sumOf { it.sizeBytes },
            availableDeviceBytes = stat?.availableBytes ?: 0L,
            totalDeviceBytes = stat?.totalBytes ?: 0L,
            trackCount = songs.size,
            losslessCount = songs.count { it.isLossless }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StorageSummary())

    init {
        playerController.connect()

        // Sync initial & persisted EQ + DSP state immediately into Media3 AudioProcessor
        viewModelScope.launch {
            settingsDataStore.settingsFlow.collect { prefs ->
                dspProcessor.setEqBands(prefs.eqEnabled, prefs.eqBandsDb)
                dspProcessor.preampDb = prefs.preampDb
                dspProcessor.channelBalance = prefs.channelBalance
                dspProcessor.normalizationEnabled = prefs.volumeNormalization
            }
        }

        // Auto-load lyrics whenever current song changes
        viewModelScope.launch {
            var lastSongId = -1L
            playbackState.collect { state ->
                val song = state.currentSong
                if (song != null && song.id != lastSongId) {
                    lastSongId = song.id
                    _currentLyrics.value = musicRepository.loadLyricsForSong(song)
                } else if (song == null) {
                    lastSongId = -1L
                    _currentLyrics.value = null
                }
            }
        }

        // Sync metronome bars with BPM Trainer & Chord Progression Trainer
        viewModelScope.launch {
            var lastBarHandled = -1
            metronomeState.collect { mState ->
                if (!mState.isRunning) {
                    lastBarHandled = -1
                    return@collect
                }
                if (mState.completedBars != lastBarHandled) {
                    lastBarHandled = mState.completedBars
                    val pt = _practiceTools.value
                    val prog = ChordLibraryData.progressions.firstOrNull { it.id == pt.selectedProgressionId }
                    if (prog != null && prog.chordIds.isNotEmpty()) {
                        _practiceTools.update {
                            it.copy(activeProgressionIndex = mState.completedBars % prog.chordIds.size)
                        }
                    }
                    if (pt.bpmTrainerActive && mState.completedBars > 0 && mState.completedBars % pt.bpmTrainerStepBars == 0) {
                        val nextBpm = (mState.bpm + 5).coerceAtMost(pt.bpmTrainerTarget)
                        metronomeEngine.setBpm(nextBpm)
                    }
                }
            }
        }
    }

    fun scanLibrary() {
        viewModelScope.launch {
            _isScanning.value = true
            val found = musicRepository.refreshLibrary()
            _isScanning.value = false
            _statusBanner.value = "Library synced: ${found.size} tracks ready offline"
        }
    }

    fun createSampleOfflineTracks() {
        viewModelScope.launch {
            _isScanning.value = true
            musicRepository.generateTestTracksAndRefresh()
            _isScanning.value = false
            _statusBanner.value = "Added 3 lossless 44.1kHz WAV tracks with synced LRC lyrics"
        }
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun showMessage(msg: String) {
        _statusBanner.value = msg
    }

    fun setSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun updateSort(order: SongSortOrder, ascending: Boolean) {
        viewModelScope.launch { settingsDataStore.setSort(order, ascending) }
    }

    // Dual Theme & Customization (Zero playback interruption)
    fun toggleThemeMode() {
        viewModelScope.launch {
            val next = if (settings.value.themeMode == VybeThemeMode.MODERN) {
                VybeThemeMode.RETRO
            } else {
                VybeThemeMode.MODERN
            }
            settingsDataStore.setThemeMode(next)
        }
    }

    fun setThemeMode(mode: VybeThemeMode) = viewModelScope.launch { settingsDataStore.setThemeMode(mode) }
    fun setAppearanceMode(mode: AppearanceMode) = viewModelScope.launch { settingsDataStore.setAppearanceMode(mode) }
    fun setAccentPreset(preset: AccentPreset) = viewModelScope.launch { settingsDataStore.setAccentPreset(preset) }
    fun setArtworkStyle(style: ArtworkStyle) = viewModelScope.launch { settingsDataStore.setArtworkStyle(style) }
    fun setPlayerBackgroundStyle(style: PlayerBackgroundStyle) = viewModelScope.launch { settingsDataStore.setPlayerBackgroundStyle(style) }
    fun setPlayerLayoutStyle(style: PlayerLayoutStyle) = viewModelScope.launch { settingsDataStore.setPlayerLayoutStyle(style) }
    fun setNavDockStyle(style: NavDockStyle) = viewModelScope.launch { settingsDataStore.setNavDockStyle(style) }
    fun setAnimationsEnabled(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setAnimationsEnabled(enabled) }

    fun setPerformanceMode(mode: PerformanceMode, activity: Activity?) {
        viewModelScope.launch {
            settingsDataStore.setPerformanceMode(mode)
            if (activity != null) {
                DisplayRefreshRateManager.applyPerformanceMode(activity, mode)
                _displayRefreshInfo.value = DisplayRefreshRateManager.queryDisplayInfo(activity)
            }
        }
    }

    fun refreshDisplayInfo(activity: Activity?) {
        if (activity != null) {
            DisplayRefreshRateManager.applyPerformanceMode(activity, settings.value.performanceMode)
            _displayRefreshInfo.value = DisplayRefreshRateManager.queryDisplayInfo(activity)
        } else {
            _displayRefreshInfo.value = DisplayRefreshRateManager.queryDisplayInfo(app)
        }
    }

    // Visualizers
    fun setVisualizerEnabled(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setVisualizerEnabled(enabled) }
    fun setVisualizerStyle(style: VisualizerStyle) = viewModelScope.launch { settingsDataStore.setVisualizerStyle(style) }
    fun setVisualizerIntensity(intensity: Float) = viewModelScope.launch { settingsDataStore.setVisualizerIntensity(intensity) }
    fun setVisualizerSize(size: VisualizerSize) = viewModelScope.launch { settingsDataStore.setVisualizerSize(size) }
    fun setVisualizerCustomColor(hex: Long?) = viewModelScope.launch { settingsDataStore.setVisualizerCustomColor(hex) }

    // Audio & Equalizer
    fun setEqEnabled(enabled: Boolean) {
        val s = settings.value
        dspProcessor.setEqBands(enabled, s.eqBandsDb)
        audioEffectsEngine.applyEqualizer(enabled, s.eqBandsDb)
        audioEffectsEngine.applyBassBoost(enabled, s.bassBoostStrength)
        audioEffectsEngine.applyVirtualizer(enabled, s.virtualizerStrength)
        audioEffectsEngine.applyLoudnessEnhancer(enabled, s.loudnessGainMb)
        viewModelScope.launch {
            settingsDataStore.setEqState(enabled, s.eqPresetId, s.eqBandsDb)
        }
    }

    fun updateEqBand(index: Int, valueDb: Float) {
        val s = settings.value
        val updated = s.eqBandsDb.toMutableList().apply {
            if (index in indices) this[index] = valueDb.coerceIn(-12f, 12f)
        }
        dspProcessor.setEqBands(s.eqEnabled, updated)
        audioEffectsEngine.applyEqualizer(s.eqEnabled, updated)
        viewModelScope.launch {
            settingsDataStore.setEqState(s.eqEnabled, "custom", updated)
        }
    }

    fun applyEqPreset(preset: EqPreset) {
        dspProcessor.setEqBands(true, preset.bandLevelsDb)
        audioEffectsEngine.applyEqualizer(true, preset.bandLevelsDb)
        viewModelScope.launch {
            settingsDataStore.setEqState(true, preset.id, preset.bandLevelsDb)
        }
    }

    fun resetEqFlat() {
        val flat = List(10) { 0f }
        dspProcessor.setEqBands(true, flat)
        audioEffectsEngine.applyEqualizer(true, flat)
        viewModelScope.launch {
            settingsDataStore.setEqState(true, "normal", flat)
        }
    }

    fun saveCustomEqPreset(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            musicRepository.saveCustomEqPreset(name, settings.value.eqBandsDb)
            _statusBanner.value = "Saved EQ preset \"$name\""
        }
    }

    fun deleteCustomEqPreset(id: String) = viewModelScope.launch {
        musicRepository.deleteCustomEqPreset(id)
    }

    fun setBassBoost(strength: Int) = viewModelScope.launch {
        settingsDataStore.setBassBoost(strength)
        audioEffectsEngine.applyBassBoost(settings.value.eqEnabled, strength)
    }

    fun setVirtualizer(strength: Int) = viewModelScope.launch {
        settingsDataStore.setVirtualizer(strength)
        audioEffectsEngine.applyVirtualizer(settings.value.eqEnabled, strength)
    }

    fun setLoudnessGain(gainMb: Int) = viewModelScope.launch {
        settingsDataStore.setLoudnessGain(gainMb)
        audioEffectsEngine.applyLoudnessEnhancer(settings.value.eqEnabled, gainMb)
    }

    fun setPreampDb(db: Float) = viewModelScope.launch {
        settingsDataStore.setPreampDb(db)
        dspProcessor.preampDb = db
    }

    fun setChannelBalance(balance: Float) = viewModelScope.launch {
        settingsDataStore.setChannelBalance(balance)
        dspProcessor.channelBalance = balance
    }

    fun setVolumeNormalization(enabled: Boolean) = viewModelScope.launch {
        settingsDataStore.setVolumeNormalization(enabled)
        dspProcessor.normalizationEnabled = enabled
    }

    fun applyHeadphoneProfile(profile: HeadphoneProfile) {
        dspProcessor.setEqBands(true, profile.bandOffsetsDb)
        audioEffectsEngine.applyEqualizer(true, profile.bandOffsetsDb)
        audioEffectsEngine.applyBassBoost(true, profile.bassBoost)
        audioEffectsEngine.applyVirtualizer(true, profile.virtualizer)
        viewModelScope.launch {
            settingsDataStore.setHeadphoneProfile(profile)
            settingsDataStore.setEqState(true, "profile_${profile.name}", profile.bandOffsetsDb)
            settingsDataStore.setBassBoost(profile.bassBoost)
            settingsDataStore.setVirtualizer(profile.virtualizer)
        }
    }

    fun setGaplessPlayback(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setGaplessPlayback(enabled) }
    fun setCrossfadeMs(ms: Int) = viewModelScope.launch { settingsDataStore.setCrossfadeDurationMs(ms) }
    fun setCrossfadeCurve(curve: CrossfadeCurve) = viewModelScope.launch { settingsDataStore.setCrossfadeCurve(curve) }
    fun setCrossfadeOnManualSkip(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setCrossfadeOnManualSkip(enabled) }
    fun setHapticFeedbackEnabled(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setHapticFeedbackEnabled(enabled) }
    fun setFadeInOut(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setFadeInOutEnabled(enabled) }
    fun setAutoPauseDisconnect(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setAutoPauseOnDisconnect(enabled) }
    fun setShowNotifications(show: Boolean) = viewModelScope.launch { settingsDataStore.setShowNotifications(show) }
    fun setSkipSilence(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setSkipSilenceEnabled(enabled) }

    // Library Management
    fun toggleFavorite(song: Song) = viewModelScope.launch {
        musicRepository.toggleFavorite(song.id, song.isFavorite)
    }

    fun updateSongMetadata(songId: Long, title: String, artist: String, album: String, customArtUri: String?) {
        viewModelScope.launch {
            musicRepository.updateSongMetadata(songId, title, artist, album, customArtUri)
            _statusBanner.value = "Updated metadata for \"$title\""
        }
    }

    fun moveToTrash(song: Song) = viewModelScope.launch {
        musicRepository.softDeleteSong(song.id)
        _statusBanner.value = "Moved \"${song.title}\" to Recently Deleted"
    }

    fun restoreFromTrash(song: Song) = viewModelScope.launch {
        musicRepository.restoreSong(song.id)
        _statusBanner.value = "Restored \"${song.title}\""
    }

    fun detectDuplicates(): List<DuplicateGroup> = musicRepository.detectDuplicates(allSongs.value)

    fun excludeFolder(folder: FolderGroup) = viewModelScope.launch {
        musicRepository.excludeFolder(folder.folderPath, folder.folderName)
        _statusBanner.value = "Excluded folder \"${folder.folderName}\""
    }

    fun includeFolder(folder: ExcludedFolderEntity) = viewModelScope.launch {
        musicRepository.includeFolder(folder.folderPath)
    }

    // Playlists
    fun createPlaylist(name: String, songIds: List<Long> = emptyList()) {
        if (name.isBlank()) return
        viewModelScope.launch {
            musicRepository.createPlaylist(name, songIds)
            _statusBanner.value = "Created playlist \"$name\""
        }
    }

    fun renamePlaylist(playlistId: Long, newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch { musicRepository.renamePlaylist(playlistId, newName) }
    }

    fun updatePlaylistArtwork(playlistId: Long, uri: String?) = viewModelScope.launch {
        musicRepository.updatePlaylistArtwork(playlistId, uri)
    }

    fun deletePlaylist(playlistId: Long) = viewModelScope.launch {
        musicRepository.deletePlaylist(playlistId)
    }

    fun addSongToPlaylist(playlistId: Long, songId: Long) = viewModelScope.launch {
        musicRepository.addSongToPlaylist(playlistId, songId)
        _statusBanner.value = "Added track to playlist"
    }

    fun removeSongFromPlaylist(playlistId: Long, songId: Long) = viewModelScope.launch {
        musicRepository.removeSongFromPlaylist(playlistId, songId)
    }

    fun movePlaylistSong(playlist: Playlist, fromIndex: Int, toIndex: Int) {
        if (playlist.isSmart) return
        val mutable = playlist.songs.toMutableList()
        if (fromIndex !in mutable.indices || toIndex !in mutable.indices) return
        val item = mutable.removeAt(fromIndex)
        mutable.add(toIndex, item)
        viewModelScope.launch {
            musicRepository.reorderPlaylistSongs(playlist.id, mutable.map { it.id })
        }
    }

    fun exportPlaylistM3u(playlist: Playlist, uri: Uri) = viewModelScope.launch {
        val ok = musicRepository.exportPlaylistM3u(playlist, uri)
        _statusBanner.value = if (ok) "Exported ${playlist.name}.m3u" else "Failed to export playlist"
    }

    fun exportPlaylistJson(playlist: Playlist, uri: Uri) = viewModelScope.launch {
        val ok = musicRepository.exportPlaylistJson(playlist, uri)
        _statusBanner.value = if (ok) "Exported ${playlist.name}.json" else "Failed to export playlist"
    }

    fun importPlaylist(uri: Uri) = viewModelScope.launch {
        val importedName = musicRepository.importPlaylistFromUri(uri)
        _statusBanner.value = if (importedName != null) {
            "Imported playlist \"$importedName\""
        } else {
            "No matching local tracks found in playlist file"
        }
    }

    // Lyrics
    fun saveManualLyrics(songId: Long, rawText: String) = viewModelScope.launch {
        musicRepository.saveLyrics(songId, rawText, "Edited locally")
        val song = playbackState.value.currentSong
        if (song != null && song.id == songId) {
            _currentLyrics.value = musicRepository.loadLyricsForSong(song)
        }
        _statusBanner.value = "Lyrics saved offline"
    }

    fun importLrcFile(songId: Long, uri: Uri) = viewModelScope.launch {
        val ok = musicRepository.importLrcFromUri(songId, uri)
        if (ok) {
            val song = playbackState.value.currentSong
            if (song != null && song.id == songId) {
                _currentLyrics.value = musicRepository.loadLyricsForSong(song)
            }
            _statusBanner.value = "Imported LRC lyrics"
        } else {
            _statusBanner.value = "Could not read LRC file"
        }
    }

    fun rescanCurrentLyrics() = viewModelScope.launch {
        val song = playbackState.value.currentSong ?: return@launch
        val fresh = musicRepository.rescanLyricsFromSource(song)
        _currentLyrics.value = fresh
        _statusBanner.value = if (fresh.lines.isNotEmpty()) {
            "Loaded lyrics from ${fresh.sourceLabel}"
        } else {
            "No .lrc file or embedded lyric tags found"
        }
    }

    fun isNetworkConnected(): Boolean {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val active = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(active) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun openManualLyricsWebSearch(context: Context, song: Song) {
        if (!isNetworkConnected()) {
            _statusBanner.value = "Offline mode: connect to internet to search web lyrics, or edit/import LRC offline"
            return
        }
        val query = URLEncoder.encode("${song.artist} ${song.title} lyrics", "UTF-8")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$query"))
        context.startActivity(intent)
    }

    fun shareSongInfo(context: Context, song: Song) {
        val shareText = "Listening to \"${song.title}\" by ${song.artist} (${song.album}) • ${song.formatBadge} [${TimeFormatter.formatDuration(song.durationMs)}] on VYBE"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        context.startActivity(Intent.createChooser(intent, "Share Track Info"))
    }

    // Guitar Practice Studio
    fun startTuner() = pitchDetector.start(viewModelScope)
    fun stopTuner() = pitchDetector.stop()

    fun playReferenceTone(hz: Double) = GuitarToneSynthesizer.playReferenceTone(viewModelScope, hz)
    fun playChordPreview(chord: GuitarChord) = GuitarToneSynthesizer.playChordArpeggio(viewModelScope, chord)

    fun toggleMetronome() {
        if (metronomeState.value.isRunning) metronomeEngine.stop()
        else metronomeEngine.start(viewModelScope)
    }

    fun setMetronomeBpm(bpm: Int) = metronomeEngine.setBpm(bpm)
    fun tapTempo(): Int = metronomeEngine.registerTapTempo()
    fun setTimeSignature(sig: TimeSignature) = metronomeEngine.setTimeSignature(sig)
    fun setMetronomeAccent(accent: Boolean) = metronomeEngine.setAccentFirstBeat(accent)

    fun togglePracticeTimer() {
        val running = !_practiceTools.value.timerRunning
        _practiceTools.update { it.copy(timerRunning = running) }
        practiceTimerJob?.cancel()
        if (running) {
            practiceTimerJob = viewModelScope.launch {
                while (isActive && _practiceTools.value.timerRunning) {
                    delay(1000L)
                    _practiceTools.update { it.copy(timerElapsedSec = it.timerElapsedSec + 1) }
                }
            }
        }
    }

    fun resetPracticeTimer() {
        practiceTimerJob?.cancel()
        _practiceTools.update { it.copy(timerRunning = false, timerElapsedSec = 0) }
    }

    fun setBpmTrainer(active: Boolean, startBpm: Int = _practiceTools.value.bpmTrainerStart, targetBpm: Int = _practiceTools.value.bpmTrainerTarget) {
        _practiceTools.update {
            it.copy(
                bpmTrainerActive = active,
                bpmTrainerStart = startBpm.coerceIn(40, 220),
                bpmTrainerTarget = targetBpm.coerceIn(50, 240)
            )
        }
        if (active) {
            metronomeEngine.setBpm(startBpm.coerceIn(40, 220))
            if (!metronomeState.value.isRunning) metronomeEngine.start(viewModelScope)
        }
    }

    fun selectProgression(progressionId: String) {
        val prog = ChordLibraryData.progressions.firstOrNull { it.id == progressionId }
        _practiceTools.update { it.copy(selectedProgressionId = progressionId, activeProgressionIndex = 0) }
        if (prog != null) metronomeEngine.setBpm(prog.recommendedBpm)
    }

    fun clearStatsHistory() = viewModelScope.launch {
        musicRepository.clearListeningHistory()
        _statusBanner.value = "Listening statistics cleared"
    }

    override fun onCleared() {
        pitchDetector.stop()
        metronomeEngine.stop()
        practiceTimerJob?.cancel()
        super.onCleared()
    }
}
