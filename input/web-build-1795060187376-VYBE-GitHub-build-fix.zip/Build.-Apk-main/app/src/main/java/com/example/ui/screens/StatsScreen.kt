package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.ListeningStatSummary
import com.example.ui.components.VybeArtwork
import com.example.ui.theme.LocalVybeStyle
import com.example.util.TimeFormatter

@Composable
fun StatsScreen(
    stats: ListeningStatSummary,
    onBack: () -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    var chartPeriod by remember { mutableIntStateOf(0) } // 0=Daily, 1=Weekly, 2=Monthly

    val chartData = when (chartPeriod) {
        1 -> stats.weeklyMinutes
        2 -> stats.monthlyMinutes
        else -> stats.dailyMinutes
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("stats_back_btn")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = vybe.textPrimary)
                }
                Column {
                    Text("Listening Statistics", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
                    Text("Offline activity & top favorites", style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                }
            }
            IconButton(onClick = onClearHistory) {
                Icon(Icons.Filled.DeleteSweep, contentDescription = "Clear history", tint = vybe.textMuted)
            }
        }

        // KPI Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(vybe.cardRadius),
                color = vybe.surfaceCard,
                border = BorderStroke(0.8.dp, vybe.cardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Icon(Icons.Filled.MusicNote, contentDescription = null, tint = vybe.accentSecondary)
                    Spacer(Modifier.height(8.dp))
                    Text("${stats.totalSongsPlayed}", style = MaterialTheme.typography.headlineMedium, color = vybe.textPrimary)
                    Text("Total Plays", style = MaterialTheme.typography.labelMedium, color = vybe.textMuted)
                }
            }

            Surface(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(vybe.cardRadius),
                color = vybe.surfaceCard,
                border = BorderStroke(0.8.dp, vybe.cardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Icon(Icons.Filled.Headphones, contentDescription = null, tint = vybe.accentPrimary)
                    Spacer(Modifier.height(8.dp))
                    Text(TimeFormatter.formatListeningTime(stats.totalListeningMs), style = MaterialTheme.typography.headlineMedium, color = vybe.textPrimary)
                    Text("Listening Time", style = MaterialTheme.typography.labelMedium, color = vybe.textMuted)
                }
            }
        }

        // Listening Chart Card
        Surface(
            shape = RoundedCornerShape(vybe.cardRadius),
            color = vybe.surfaceCard,
            border = BorderStroke(0.8.dp, vybe.cardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Listening Minutes", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Daily", "Weekly", "Monthly").forEachIndexed { idx, label ->
                            FilterChip(
                                selected = chartPeriod == idx,
                                onClick = { chartPeriod = idx },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                val maxVal = (chartData.maxOfOrNull { it.second } ?: 1f).coerceAtLeast(1f)
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                ) {
                    if (chartData.isEmpty()) return@Canvas
                    val count = chartData.size
                    val gap = size.width * 0.04f
                    val barW = (size.width - gap * (count + 1)) / count
                    val brush = Brush.verticalGradient(listOf(vybe.accentSecondary, vybe.accentPrimary))

                    chartData.forEachIndexed { idx, (_, mins) ->
                        val ratio = (mins / maxVal).coerceIn(0.04f, 1f)
                        val barH = ratio * (size.height * 0.88f)
                        val x = gap + idx * (barW + gap)
                        val y = size.height - barH
                        drawRoundRect(
                            brush = brush,
                            topLeft = Offset(x, y),
                            size = Size(barW, barH),
                            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    chartData.forEach { (label, mins) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(String.format("%.0fm", mins), style = MaterialTheme.typography.labelSmall, color = vybe.accentSecondary)
                            Text(label, style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                        }
                    }
                }
            }
        }

        // Most Played Songs
        if (stats.topSongs.isNotEmpty()) {
            Text("Most Played Tracks", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
            stats.topSongs.forEachIndexed { idx, song ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = vybe.surfaceCard,
                    border = BorderStroke(0.7.dp, vybe.cardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("#${idx + 1}", style = MaterialTheme.typography.titleMedium, color = vybe.accentSecondary, modifier = Modifier.width(30.dp))
                        VybeArtwork(model = song.artworkModel, contentDescription = song.title, cornerRadius = 8.dp, modifier = Modifier.size(44.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(song.title, style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary, maxLines = 1)
                            Text(song.artist, style = MaterialTheme.typography.bodyMedium, color = vybe.textMuted, maxLines = 1)
                        }
                        Text("${song.playCount} plays", style = MaterialTheme.typography.labelMedium, color = vybe.accentSecondary)
                    }
                }
            }
        }

        // Most Played Artists
        if (stats.topArtists.isNotEmpty()) {
            Text("Top Artists", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
            stats.topArtists.forEach { (artist, plays) ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = vybe.surfaceCard,
                    border = BorderStroke(0.7.dp, vybe.cardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(artist, style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                        Text("$plays plays", style = MaterialTheme.typography.labelMedium, color = vybe.accentSecondary)
                    }
                }
            }
        }

        Spacer(Modifier.height(40.dp))
    }
}
