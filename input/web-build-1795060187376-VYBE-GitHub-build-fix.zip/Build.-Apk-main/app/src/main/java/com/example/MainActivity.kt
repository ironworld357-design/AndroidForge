package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.example.audio.VybeMediaService
import com.example.ui.VybeApp

class MainActivity : ComponentActivity() {
    private var openNowPlayingRequestId by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)
        setContent {
            VybeApp(openNowPlayingTrigger = openNowPlayingRequestId)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(VybeMediaService.EXTRA_OPEN_NOW_PLAYING, false) == true) {
            intent.removeExtra(VybeMediaService.EXTRA_OPEN_NOW_PLAYING)
            openNowPlayingRequestId++
        }
    }
}
