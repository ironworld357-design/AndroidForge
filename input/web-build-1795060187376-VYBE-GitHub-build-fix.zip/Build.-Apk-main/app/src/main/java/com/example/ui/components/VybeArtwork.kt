package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.R
import com.example.model.ArtworkStyle
import com.example.ui.theme.LocalVybeStyle
import kotlinx.coroutines.delay

/**
 * Physics-driven vinyl rotation state: accelerates smoothly to speed when [isPlaying] is true,
 * and coasts smoothly to a pause at its current angle (never snapping back to 0°) when paused.
 */
@Composable
fun rememberVinylRotationAngle(
    isPlaying: Boolean,
    playbackSpeed: Float = 1.0f,
    enabled: Boolean = true,
    baseDegPerSec: Float = 72f
): Float {
    var angle by remember { mutableFloatStateOf(0f) }
    var currentVel by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(isPlaying, playbackSpeed, enabled) {
        if (!enabled) {
            currentVel = 0f
            return@LaunchedEffect
        }
        var lastNs = 0L
        while (true) {
            withFrameNanos { nowNs ->
                if (lastNs == 0L) lastNs = nowNs
                val dt = ((nowNs - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastNs = nowNs

                val targetVel = if (isPlaying) baseDegPerSec * playbackSpeed.coerceIn(0.25f, 2.5f) else 0f
                val damping = if (isPlaying) 4.8f else 3.2f
                currentVel += (targetVel - currentVel) * (dt * damping).coerceIn(0f, 1f)
                angle = (angle + currentVel * dt) % 360f
            }
            if (!isPlaying && currentVel < 0.25f) {
                currentVel = 0f
                delay(150L)
            }
        }
    }

    return angle
}

@Composable
fun VybeArtwork(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    style: ArtworkStyle = ArtworkStyle.ROUNDED_CARD,
    cornerRadius: Dp = 16.dp,
    isPlaying: Boolean = false,
    playbackSpeed: Float = 1.0f,
    spinEnabled: Boolean = false
) {
    val vybe = LocalVybeStyle.current
    val context = LocalContext.current

    val shouldSpin = spinEnabled && (style == ArtworkStyle.VINYL_DISC || style == ArtworkStyle.HALO_RING)
    val rotationDeg = if (shouldSpin) {
        rememberVinylRotationAngle(
            isPlaying = isPlaying,
            playbackSpeed = playbackSpeed,
            enabled = true,
            baseDegPerSec = 68f
        )
    } else 0f

    val shape = when (style) {
        ArtworkStyle.VINYL_DISC, ArtworkStyle.HALO_RING -> CircleShape
        ArtworkStyle.RETRO_LABEL -> RoundedCornerShape(8.dp)
        else -> RoundedCornerShape(cornerRadius)
    }

    val imageRequest = ImageRequest.Builder(context)
        .data(model ?: R.drawable.img_default_album)
        .crossfade(true)
        .memoryCachePolicy(CachePolicy.ENABLED)
        .diskCachePolicy(CachePolicy.ENABLED)
        .error(R.drawable.img_default_album)
        .fallback(R.drawable.img_default_album)
        .build()

    Box(
        modifier = modifier
            .then(if (shouldSpin) Modifier.graphicsLayer { rotationZ = rotationDeg } else Modifier)
            .clip(shape)
            .background(vybe.surfaceElevated)
            .then(
                when (style) {
                    ArtworkStyle.GLASS_FRAME, ArtworkStyle.AURORA_COVERFLOW -> Modifier.border(
                        BorderStroke(
                            1.5.dp,
                            Brush.linearGradient(
                                listOf(
                                    Color.White.copy(alpha = 0.55f),
                                    vybe.accentSecondary.copy(alpha = 0.65f),
                                    vybe.accentPrimary.copy(alpha = 0.35f)
                                )
                            )
                        ),
                        shape
                    )
                    ArtworkStyle.RIBBED_GLASS -> Modifier.border(
                        BorderStroke(1.2.dp, Color.White.copy(alpha = 0.28f)),
                        shape
                    )
                    ArtworkStyle.HALO_RING -> Modifier.border(
                        BorderStroke(
                            2.2.dp,
                            Brush.sweepGradient(
                                listOf(
                                    vybe.accentPrimary,
                                    vybe.accentSecondary,
                                    Color.White.copy(alpha = 0.7f),
                                    vybe.accentPrimary
                                )
                            )
                        ),
                        shape
                    )
                    ArtworkStyle.RETRO_LABEL -> Modifier.border(
                        BorderStroke(2.dp, vybe.accentPrimary.copy(alpha = 0.55f)),
                        shape
                    )
                    ArtworkStyle.VINYL_DISC -> Modifier.border(
                        BorderStroke(2.dp, Color.White.copy(alpha = 0.14f)),
                        shape
                    )
                    else -> Modifier.border(
                        BorderStroke(0.8.dp, vybe.cardBorder),
                        shape
                    )
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = imageRequest,
            placeholder = painterResource(R.drawable.img_default_album),
            error = painterResource(R.drawable.img_default_album),
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Vertical fluted / ribbed frosted glass streaks overlay
        if (style == ArtworkStyle.RIBBED_GLASS) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val ribCount = 18
                val step = size.width / ribCount
                for (i in 0 until ribCount) {
                    val x = i * step
                    drawLine(
                        color = Color.White.copy(alpha = if (i % 2 == 0) 0.11f else 0.03f),
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = step * 0.42f
                    )
                }
            }
        }

        if (style == ArtworkStyle.VINYL_DISC) {
            // Subtle outer micro-grooves + center spindle hole
            Canvas(modifier = Modifier.fillMaxSize()) {
                val r = size.minDimension / 2f
                val center = Offset(size.width / 2f, size.height / 2f)
                for (g in 1..4) {
                    drawCircle(
                        color = Color.Black.copy(alpha = 0.22f),
                        radius = r * (0.64f + g * 0.08f),
                        center = center,
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(vybe.bgDeep)
                    .border(1.5.dp, Color.White.copy(alpha = 0.4f), CircleShape)
            )
        }

        if (style == ArtworkStyle.RETRO_LABEL) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(4.dp)
                    .border(0.75.dp, Color(0x66F4EBD9), RoundedCornerShape(5.dp))
            )
        }
    }
}

/**
 * Grooved black vinyl record disc with specular sheen & rotating center album label,
 * designed to spin smoothly when music plays and pause in place when playback stops.
 */
@Composable
fun GroovedVinylRecordDisc(
    artworkModel: Any?,
    isPlaying: Boolean,
    playbackSpeed: Float,
    animationsEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val vinylAngle = rememberVinylRotationAngle(
        isPlaying = isPlaying,
        playbackSpeed = playbackSpeed,
        enabled = animationsEnabled,
        baseDegPerSec = 90f
    )

    Box(
        modifier = modifier
            .graphicsLayer { rotationZ = vinylAngle }
            .clip(CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            val c = Offset(size.width / 2f, size.height / 2f)

            // Vinyl platter base
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF1A1A24), Color(0xFF0A0A0F), Color(0xFF161620)),
                    center = c,
                    radius = r
                ),
                radius = r,
                center = c
            )

            // Specular vinyl sheen reflection
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = 0.14f),
                        Color.Transparent,
                        Color.White.copy(alpha = 0.10f),
                        Color.Transparent
                    )
                ),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = true,
                topLeft = Offset(c.x - r, c.y - r),
                size = Size(r * 2f, r * 2f)
            )

            // Concentric vinyl micro-grooves
            for (g in 1..16) {
                val frac = 0.44f + (g / 16f) * 0.50f
                drawCircle(
                    color = Color.White.copy(alpha = if (g % 3 == 0) 0.10f else 0.04f),
                    radius = r * frac,
                    center = c,
                    style = Stroke(width = 0.9.dp.toPx())
                )
            }

            // Center label rim
            drawCircle(
                color = vybe.accentPrimary.copy(alpha = 0.75f),
                radius = r * 0.39f,
                center = c,
                style = Stroke(width = 1.6.dp.toPx())
            )
        }

        // Rotating center label artwork + spindle
        VybeArtwork(
            model = artworkModel,
            contentDescription = "Spinning Vinyl Label",
            style = ArtworkStyle.ROUNDED_CARD,
            cornerRadius = 60.dp,
            modifier = Modifier
                .fillMaxSize(0.38f)
                .clip(CircleShape)
        )
        Box(
            modifier = Modifier
                .size(14.dp)
                .clip(CircleShape)
                .background(Color(0xFF0A0A0F))
                .border(1.5.dp, Color(0xFFD4D4D8), CircleShape)
        )
    }
}
