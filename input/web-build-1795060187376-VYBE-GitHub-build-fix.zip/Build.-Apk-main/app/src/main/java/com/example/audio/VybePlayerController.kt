package com.example.audio

import android.content.ComponentName
import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import com.example.VybeApplication
import com.example.data.local.SettingsDataStore
import com.example.data.repo.MusicRepository
import com.example.model.AudioOutputInfo
import com.example.model.RepeatMode
import com.example.model.Song
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlaybackUiState(
    val currentSong: Song? = null,
    val queue: List<Song> = emptyList(),
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val playbackSpeed: Float = 1.0f,
    val volume: Float = 1.0f,
    val sleepTimerRemainingMs: Long = 0L,
    val isClipping: Boolean = false,
    val isCrossfading: Boolean = false,
    val isServiceConnected: Boolean = false,
    val skipDirection: Int = 1,
    val abLoopStartMs: Long? = null,
    val abLoopEndMs: Long? = null,
    val audioOutputInfo: AudioOutputInfo = AudioOutputInfo("Phone Speaker", "Built-in Speaker", false, false)
)

class VybePlayerController(
    private val context: Context,
    private val musicRepository: MusicRepository,
    private val settingsDataStore: SettingsDataStore,
    val dspProcessor: VybeDspAudioProcessor,
    val audioEffectsEngine: AudioEffectsEngine
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    private val _playbackState = MutableStateFlow(PlaybackUiState())
    val playbackState: StateFlow<PlaybackUiState> = _playbackState.asStateFlow()

    private var positionTickerJob: Job? = null
    private var sleepTimerJob: Job? = null
    private var fadeJob: Job? = null
    private var hasRestoredQueue = false
    private var crossfadeEnabledMs = 0
    private var crossfadeOnSkipEnabled = false

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = refreshOutputDevice()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = refreshOutputDevice()
    }

    init {
        refreshOutputDevice()
        audioManager.registerAudioDeviceCallback(deviceCallback, null)

        // Track crossfade settings & active dual-player transition state
        scope.launch {
            settingsDataStore.settingsFlow.collect { s ->
                crossfadeEnabledMs = s.crossfadeDurationMs
                crossfadeOnSkipEnabled = s.crossfadeOnManualSkip
            }
        }
        (context.applicationContext as? VybeApplication)?.let { vybeApp ->
            scope.launch {
                vybeApp.isCrossfadingFlow.collect { active ->
                    _playbackState.update { it.copy(isCrossfading = active) }
                }
            }
        }

        // Keep song metadata synced if favorite/edits change in Room
        scope.launch {
            musicRepository.songsFlow.collect { allSongs ->
                val map = allSongs.associateBy { it.id }
                _playbackState.update { state ->
                    val updatedQueue = state.queue.mapNotNull { map[it.id] }
                    val updatedCurrent = state.currentSong?.let { map[it.id] ?: it }
                    state.copy(
                        currentSong = updatedCurrent,
                        queue = if (updatedQueue.isNotEmpty()) updatedQueue else state.queue
                    )
                }
            }
        }
    }

    fun connect() {
        if (controllerFuture != null) return
        val sessionToken = SessionToken(context, ComponentName(context, VybeMediaService::class.java))
        val future = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture = future
        future.addListener({
            runCatching {
                val controller = future.get()
                mediaController = controller
                _playbackState.update { it.copy(isServiceConnected = true) }
                attachControllerListeners(controller)
                scope.launch { restoreLastSessionIfIdle(controller) }
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun attachControllerListeners(controller: MediaController) {
        controller.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _playbackState.update { it.copy(isPlaying = isPlaying) }
                if (isPlaying) startPositionTicker() else stopPositionTicker()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                _playbackState.update { it.copy(abLoopStartMs = null, abLoopEndMs = null) }
                syncStateFromController(controller)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                syncStateFromController(controller)
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                _playbackState.update { it.copy(shuffleEnabled = shuffleModeEnabled) }
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                _playbackState.update { it.copy(repeatMode = repeatMode.toVybeRepeat()) }
            }
        })
        syncStateFromController(controller)
        if (controller.isPlaying) startPositionTicker()
    }

    private suspend fun restoreLastSessionIfIdle(controller: MediaController) {
        if (hasRestoredQueue || controller.mediaItemCount > 0) {
            hasRestoredQueue = true
            syncStateFromController(controller)
            return
        }
        hasRestoredQueue = true

        val settings = settingsDataStore.settingsFlow.first()
        val songs = musicRepository.songsFlow.first()
        if (songs.isEmpty()) return

        val songMap = songs.associateBy { it.id }
        val restoredQueue = settings.lastQueueIds.mapNotNull { songMap[it] }.ifEmpty {
            listOfNotNull(songMap[settings.lastSongId])
        }
        if (restoredQueue.isEmpty()) return

        val startIdx = restoredQueue.indexOfFirst { it.id == settings.lastSongId }.coerceAtLeast(0)
        val items = restoredQueue.map { it.toMediaItem() }

        controller.setMediaItems(items, startIdx, settings.lastPositionMs.coerceAtLeast(0L))
        controller.shuffleModeEnabled = settings.shuffleEnabled
        controller.repeatMode = settings.repeatMode.toPlayerRepeat()
        controller.playbackParameters = PlaybackParameters(settings.playbackSpeed)
        controller.prepare()

        _playbackState.update {
            it.copy(
                queue = restoredQueue,
                currentIndex = startIdx,
                currentSong = restoredQueue[startIdx],
                positionMs = settings.lastPositionMs,
                durationMs = restoredQueue[startIdx].durationMs,
                shuffleEnabled = settings.shuffleEnabled,
                repeatMode = settings.repeatMode,
                playbackSpeed = settings.playbackSpeed
            )
        }
    }

    fun playSongs(songs: List<Song>, startIndex: Int = 0) {
        if (songs.isEmpty()) return
        val safeIdx = startIndex.coerceIn(0, songs.lastIndex)
        val controller = mediaController ?: return
        scope.launch {
            val settings = settingsDataStore.settingsFlow.first()
            val items = songs.map { it.toMediaItem() }
            controller.setMediaItems(items, safeIdx, 0L)
            controller.shuffleModeEnabled = settings.shuffleEnabled
            controller.repeatMode = settings.repeatMode.toPlayerRepeat()
            controller.playbackParameters = PlaybackParameters(settings.playbackSpeed)
            controller.prepare()

            if (settings.fadeInOutEnabled) {
                fadeVolume(controller, from = 0.05f, to = _playbackState.value.volume, durationMs = 280L)
            } else {
                controller.volume = _playbackState.value.volume
            }
            controller.play()

            _playbackState.update {
                it.copy(
                    queue = songs,
                    currentIndex = safeIdx,
                    currentSong = songs[safeIdx],
                    positionMs = 0L,
                    durationMs = songs[safeIdx].durationMs,
                    isPlaying = true
                )
            }
            settingsDataStore.savePlaybackResumption(songs[safeIdx].id, 0L, songs.map { s -> s.id })
        }
    }

    fun playNextInQueue(song: Song) {
        val controller = mediaController ?: return
        val currentQueue = _playbackState.value.queue.toMutableList()
        if (currentQueue.isEmpty()) {
            playSongs(listOf(song), 0)
            return
        }
        val insertIdx = (controller.currentMediaItemIndex + 1).coerceIn(0, currentQueue.size)
        currentQueue.add(insertIdx, song)
        controller.addMediaItem(insertIdx, song.toMediaItem())
        _playbackState.update { it.copy(queue = currentQueue) }
    }

    fun addToQueue(song: Song) {
        val controller = mediaController ?: return
        val currentQueue = _playbackState.value.queue.toMutableList()
        if (currentQueue.isEmpty()) {
            playSongs(listOf(song), 0)
            return
        }
        currentQueue.add(song)
        controller.addMediaItem(song.toMediaItem())
        _playbackState.update { it.copy(queue = currentQueue) }
    }

    fun jumpToQueueIndex(index: Int) {
        val controller = mediaController ?: return
        if (index in 0 until controller.mediaItemCount) {
            controller.seekToDefaultPosition(index)
            controller.play()
        }
    }

    fun removeFromQueue(index: Int) {
        val controller = mediaController ?: return
        val currentQueue = _playbackState.value.queue.toMutableList()
        if (index !in currentQueue.indices) return
        currentQueue.removeAt(index)
        controller.removeMediaItem(index)
        _playbackState.update { it.copy(queue = currentQueue) }
        syncStateFromController(controller)
    }

    fun moveQueueItem(fromIndex: Int, toIndex: Int) {
        val controller = mediaController ?: return
        val currentQueue = _playbackState.value.queue.toMutableList()
        if (fromIndex !in currentQueue.indices || toIndex !in currentQueue.indices || fromIndex == toIndex) return
        val item = currentQueue.removeAt(fromIndex)
        currentQueue.add(toIndex, item)
        controller.moveMediaItem(fromIndex, toIndex)
        _playbackState.update {
            it.copy(
                queue = currentQueue,
                currentIndex = controller.currentMediaItemIndex
            )
        }
    }

    fun togglePlayPause() {
        val controller = mediaController ?: return
        scope.launch {
            val settings = settingsDataStore.settingsFlow.first()
            if (controller.isPlaying) {
                if (settings.fadeInOutEnabled) {
                    fadeVolume(controller, from = _playbackState.value.volume, to = 0f, durationMs = 200L)
                }
                controller.pause()
                controller.volume = _playbackState.value.volume
            } else {
                if (controller.playbackState == Player.STATE_IDLE && controller.mediaItemCount > 0) {
                    controller.prepare()
                }
                if (settings.fadeInOutEnabled) {
                    fadeVolume(controller, from = 0.05f, to = _playbackState.value.volume, durationMs = 220L)
                } else {
                    controller.volume = _playbackState.value.volume
                }
                controller.play()
            }
        }
    }

    fun next() {
        mediaController?.let { c ->
            val nextIdx = c.nextMediaItemIndex
            if (nextIdx != C.INDEX_UNSET && c.hasNextMediaItem()) {
                _playbackState.update { s -> s.copy(skipDirection = 1) }
                if (c.isPlaying && crossfadeEnabledMs > 0 && crossfadeOnSkipEnabled) {
                    val args = Bundle().apply { putInt(VybeMediaService.ARG_TARGET_INDEX, nextIdx) }
                    c.sendCustomCommand(SessionCommand(VybeMediaService.CMD_CROSSFADE_SKIP_TO, Bundle.EMPTY), args)
                } else {
                    c.seekToNextMediaItem()
                    c.play()
                }
            }
        }
    }

    fun previous() {
        mediaController?.let { c ->
            val prevIdx = c.previousMediaItemIndex
            if (c.currentPosition > 3500L) {
                c.seekTo(0L)
            } else if (prevIdx != C.INDEX_UNSET && c.hasPreviousMediaItem()) {
                _playbackState.update { s -> s.copy(skipDirection = -1) }
                if (c.isPlaying && crossfadeEnabledMs > 0 && crossfadeOnSkipEnabled) {
                    val args = Bundle().apply { putInt(VybeMediaService.ARG_TARGET_INDEX, prevIdx) }
                    c.sendCustomCommand(SessionCommand(VybeMediaService.CMD_CROSSFADE_SKIP_TO, Bundle.EMPTY), args)
                } else {
                    c.seekToPreviousMediaItem()
                    c.play()
                }
            } else {
                c.seekTo(0L)
            }
        }
    }

    fun seekTo(positionMs: Long) {
        val dur = _playbackState.value.durationMs.takeIf { it > 0L } ?: Long.MAX_VALUE
        val target = positionMs.coerceIn(0L, dur)
        mediaController?.seekTo(target)
        _playbackState.update { it.copy(positionMs = target) }
    }

    fun seekBy(deltaMs: Long) {
        val current = mediaController?.currentPosition ?: _playbackState.value.positionMs
        seekTo(current + deltaMs)
    }

    fun toggleAbLoopMarker() {
        val state = _playbackState.value
        val pos = (mediaController?.currentPosition ?: state.positionMs).coerceAtLeast(0L)
        val start = state.abLoopStartMs
        val end = state.abLoopEndMs
        when {
            start == null -> {
                _playbackState.update { it.copy(abLoopStartMs = pos, abLoopEndMs = null) }
            }
            end == null -> {
                val loopStart = minOf(start, pos)
                val loopEnd = maxOf(start, pos).coerceAtLeast(loopStart + 800L)
                _playbackState.update { it.copy(abLoopStartMs = loopStart, abLoopEndMs = loopEnd) }
            }
            else -> {
                _playbackState.update { it.copy(abLoopStartMs = null, abLoopEndMs = null) }
            }
        }
    }

    fun clearAbLoop() {
        _playbackState.update { it.copy(abLoopStartMs = null, abLoopEndMs = null) }
    }

    fun toggleShuffle() {
        val controller = mediaController ?: return
        val nextShuffle = !controller.shuffleModeEnabled
        controller.shuffleModeEnabled = nextShuffle
        _playbackState.update { it.copy(shuffleEnabled = nextShuffle) }
        scope.launch { settingsDataStore.setShuffleEnabled(nextShuffle) }
    }

    fun cycleRepeatMode() {
        val controller = mediaController ?: return
        val next = when (_playbackState.value.repeatMode) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        controller.repeatMode = next.toPlayerRepeat()
        _playbackState.update { it.copy(repeatMode = next) }
        scope.launch { settingsDataStore.setRepeatMode(next) }
    }

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        mediaController?.playbackParameters = PlaybackParameters(clamped)
        _playbackState.update { it.copy(playbackSpeed = clamped) }
        scope.launch { settingsDataStore.setPlaybackSpeed(clamped) }
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        mediaController?.let { c ->
            c.volume = clamped
            val args = Bundle().apply { putFloat(VybeMediaService.ARG_VOLUME, clamped) }
            c.sendCustomCommand(SessionCommand(VybeMediaService.CMD_SET_BASE_VOLUME, Bundle.EMPTY), args)
        }
        _playbackState.update { it.copy(volume = clamped) }
    }

    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _playbackState.update { it.copy(sleepTimerRemainingMs = 0L) }
            return
        }
        val totalMs = minutes * 60_000L
        _playbackState.update { it.copy(sleepTimerRemainingMs = totalMs) }
        sleepTimerJob = scope.launch {
            var remaining = totalMs
            while (remaining > 0L && isActive) {
                delay(1000L)
                remaining = (remaining - 1000L).coerceAtLeast(0L)
                _playbackState.update { it.copy(sleepTimerRemainingMs = remaining) }
                if (remaining in 1L..5000L) {
                    val ratio = remaining / 5000f
                    mediaController?.volume = _playbackState.value.volume * ratio
                }
            }
            mediaController?.pause()
            mediaController?.volume = _playbackState.value.volume
            _playbackState.update { it.copy(sleepTimerRemainingMs = 0L) }
        }
    }

    fun cancelSleepTimer() = startSleepTimer(0)

    private fun startPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = scope.launch {
            while (isActive) {
                val controller = mediaController
                if (controller != null) {
                    val pos = controller.currentPosition.coerceAtLeast(0L)
                    val dur = controller.duration.takeIf { it > 0L }
                        ?: _playbackState.value.currentSong?.durationMs ?: 0L

                    // A-B Loop enforcement
                    val loopA = _playbackState.value.abLoopStartMs
                    val loopB = _playbackState.value.abLoopEndMs
                    if (loopA != null && loopB != null && pos >= loopB) {
                        controller.seekTo(loopA)
                    }

                    _playbackState.update {
                        it.copy(
                            positionMs = pos,
                            durationMs = dur,
                            isClipping = dspProcessor.isClippingActive()
                        )
                    }
                }
                delay(100L)
            }
        }
    }

    private fun stopPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = null
    }

    private fun fadeVolume(controller: MediaController, from: Float, to: Float, durationMs: Long) {
        fadeJob?.cancel()
        fadeJob = scope.launch {
            val steps = 10
            val stepDelay = (durationMs / steps).coerceAtLeast(12L)
            for (i in 1..steps) {
                val t = i / steps.toFloat()
                controller.volume = from + (to - from) * t
                delay(stepDelay)
            }
            controller.volume = to
        }
    }

    private fun syncStateFromController(controller: MediaController) {
        val currentIdx = controller.currentMediaItemIndex
        val currentQueue = _playbackState.value.queue
        val mediaId = controller.currentMediaItem?.mediaId?.toLongOrNull()
        val matched = currentQueue.getOrNull(currentIdx)
            ?: currentQueue.firstOrNull { it.id == mediaId }
            ?: _playbackState.value.currentSong

        val dur = controller.duration.takeIf { it > 0L } ?: matched?.durationMs ?: 0L
        _playbackState.update {
            it.copy(
                currentIndex = currentIdx,
                currentSong = matched,
                isPlaying = controller.isPlaying,
                positionMs = controller.currentPosition.coerceAtLeast(0L),
                durationMs = dur,
                shuffleEnabled = controller.shuffleModeEnabled,
                repeatMode = controller.repeatMode.toVybeRepeat()
            )
        }
    }

    private fun refreshOutputDevice() {
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val bt = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
        val wired = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_USB_DEVICE
        }
        val info = when {
            bt != null -> AudioOutputInfo(
                deviceName = bt.productName?.toString()?.takeIf { it.isNotBlank() } ?: "Bluetooth Audio",
                deviceTypeLabel = "Bluetooth",
                isWiredHeadset = false,
                isBluetooth = true
            )
            wired != null -> AudioOutputInfo(
                deviceName = wired.productName?.toString()?.takeIf { it.isNotBlank() } ?: "Wired Headphones",
                deviceTypeLabel = "Wired",
                isWiredHeadset = true,
                isBluetooth = false
            )
            else -> AudioOutputInfo("Phone Speaker", "Built-in Speaker", false, false)
        }
        _playbackState.update { it.copy(audioOutputInfo = info) }
    }

    private fun Song.toMediaItem(): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setDisplayTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setGenre(genre)
            .setIsBrowsable(false)
            .setIsPlayable(true)
            .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
            .setArtworkUri(Uri.parse(customArtworkUri ?: "content://media/external/audio/albumart/$albumId"))
            .build()
        return MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(contentUri)
            .setMediaMetadata(metadata)
            .build()
    }

    private fun RepeatMode.toPlayerRepeat(): Int = when (this) {
        RepeatMode.OFF -> Player.REPEAT_MODE_OFF
        RepeatMode.ALL -> Player.REPEAT_MODE_ALL
        RepeatMode.ONE -> Player.REPEAT_MODE_ONE
    }

    private fun Int.toVybeRepeat(): RepeatMode = when (this) {
        Player.REPEAT_MODE_ALL -> RepeatMode.ALL
        Player.REPEAT_MODE_ONE -> RepeatMode.ONE
        else -> RepeatMode.OFF
    }
}
