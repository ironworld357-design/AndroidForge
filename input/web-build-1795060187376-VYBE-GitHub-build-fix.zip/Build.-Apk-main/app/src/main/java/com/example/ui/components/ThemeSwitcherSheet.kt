package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BlurOn
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LensBlur
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.VybeSettings
import com.example.model.AccentPreset
import com.example.model.AppearanceMode
import com.example.model.ArtworkStyle
import com.example.model.NavDockStyle
import com.example.model.PlayerBackgroundStyle
import com.example.model.PlayerLayoutStyle
import com.example.model.VybeThemeMode
import com.example.ui.theme.AuroraBg
import com.example.ui.theme.AuroraOrbTop
import com.example.ui.theme.LiquidBg
import com.example.ui.theme.LiquidMistTop
import com.example.ui.theme.LocalVybeStyle
import com.example.ui.theme.ModernElectricBlue
import com.example.ui.theme.ModernObsidian
import com.example.ui.theme.ModernViolet
import com.example.ui.theme.OrchidBg
import com.example.ui.theme.OrchidPlumTop
import com.example.ui.theme.RetroAmber
import com.example.ui.theme.RetroCharcoal
import com.example.ui.theme.RetroCopper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeSwitcherSheet(
    settings: VybeSettings,
    onDismiss: () -> Unit,
    onSelectThemeMode: (VybeThemeMode) -> Unit,
    onSelectAppearance: (AppearanceMode) -> Unit,
    onSelectAccent: (AccentPreset) -> Unit,
    onSelectArtworkStyle: (ArtworkStyle) -> Unit,
    onSelectPlayerLayout: (PlayerLayoutStyle) -> Unit,
    onSelectPlayerBackground: (PlayerBackgroundStyle) -> Unit,
    onSelectNavDockStyle: (NavDockStyle) -> Unit
) {
    val vybe = LocalVybeStyle.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = vybe.surfaceCard,
        contentColor = vybe.textPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Text(
                    text = "VISUAL STUDIO & ADDON THEMES",
                    style = MaterialTheme.typography.labelMedium,
                    color = vybe.accentSecondary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Switch Visual Engine",
                    style = MaterialTheme.typography.headlineSmall,
                    color = vybe.textPrimary
                )
                Text(
                    text = "Music, queue, EQ, and playback position continue seamlessly.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = vybe.textMuted
                )
            }

            // All 5 Visual Engines (Modern + Retro + 3 Frosted/Aurora Addon Themes)
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    ThemePreviewCard(
                        title = VybeThemeMode.MODERN.displayName,
                        subtitle = VybeThemeMode.MODERN.tagline,
                        selected = settings.themeMode == VybeThemeMode.MODERN,
                        gradient = Brush.linearGradient(listOf(ModernObsidian, Color(0xFF28124D), ModernViolet.copy(alpha = 0.55f))),
                        badgeColor = ModernElectricBlue,
                        icon = Icons.Filled.AutoAwesome,
                        modifier = Modifier
                            .width(164.dp)
                            .testTag("theme_modern_card"),
                        onClick = { onSelectThemeMode(VybeThemeMode.MODERN) }
                    )
                }
                item {
                    ThemePreviewCard(
                        title = VybeThemeMode.RETRO.displayName,
                        subtitle = VybeThemeMode.RETRO.tagline,
                        selected = settings.themeMode == VybeThemeMode.RETRO,
                        gradient = Brush.linearGradient(listOf(RetroCharcoal, Color(0xFF3A2516), RetroCopper.copy(alpha = 0.55f))),
                        badgeColor = RetroAmber,
                        icon = Icons.Filled.Radio,
                        modifier = Modifier
                            .width(164.dp)
                            .testTag("theme_retro_card"),
                        onClick = { onSelectThemeMode(VybeThemeMode.RETRO) }
                    )
                }
                item {
                    ThemePreviewCard(
                        title = VybeThemeMode.AURORA_GLASS.displayName,
                        subtitle = VybeThemeMode.AURORA_GLASS.tagline,
                        selected = settings.themeMode == VybeThemeMode.AURORA_GLASS,
                        gradient = Brush.linearGradient(listOf(AuroraOrbTop, Color(0xFF5472D3), AuroraBg)),
                        badgeColor = Color(0xFF7DD3FC),
                        icon = Icons.Filled.BlurOn,
                        modifier = Modifier
                            .width(164.dp)
                            .testTag("theme_aurora_card"),
                        onClick = { onSelectThemeMode(VybeThemeMode.AURORA_GLASS) }
                    )
                }
                item {
                    ThemePreviewCard(
                        title = VybeThemeMode.LIQUID_SMOKE.displayName,
                        subtitle = VybeThemeMode.LIQUID_SMOKE.tagline,
                        selected = settings.themeMode == VybeThemeMode.LIQUID_SMOKE,
                        gradient = Brush.linearGradient(listOf(LiquidMistTop, Color(0xFF282A3A), LiquidBg)),
                        badgeColor = Color(0xFFE2E8F0),
                        icon = Icons.Filled.LensBlur,
                        modifier = Modifier
                            .width(164.dp)
                            .testTag("theme_liquid_card"),
                        onClick = { onSelectThemeMode(VybeThemeMode.LIQUID_SMOKE) }
                    )
                }
                item {
                    ThemePreviewCard(
                        title = VybeThemeMode.HALO_ORCHID.displayName,
                        subtitle = VybeThemeMode.HALO_ORCHID.tagline,
                        selected = settings.themeMode == VybeThemeMode.HALO_ORCHID,
                        gradient = Brush.linearGradient(listOf(OrchidPlumTop, Color(0xFF2A1645), OrchidBg)),
                        badgeColor = Color(0xFFF0ABFC),
                        icon = Icons.Filled.GraphicEq,
                        modifier = Modifier
                            .width(164.dp)
                            .testTag("theme_orchid_card"),
                        onClick = { onSelectThemeMode(VybeThemeMode.HALO_ORCHID) }
                    )
                }
            }

            // Now Playing Player Deck Layout Addon
            Column(
                modifier = Modifier.padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Now Playing Deck Layout", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PlayerLayoutStyle.entries.forEach { layout ->
                        val active = settings.playerLayoutStyle == layout
                        Surface(
                            modifier = Modifier
                                .width(142.dp)
                                .clickable { onSelectPlayerLayout(layout) }
                                .testTag("layout_${layout.name.lowercase()}"),
                            shape = RoundedCornerShape(12.dp),
                            color = if (active) vybe.accentPrimary.copy(alpha = 0.22f) else vybe.surfaceElevated,
                            border = BorderStroke(1.dp, if (active) vybe.accentSecondary else vybe.cardBorder)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = layout.displayName,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (active) vybe.accentSecondary else vybe.textPrimary
                                )
                                Text(
                                    text = layout.subtitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = vybe.textMuted,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }

            // Navigation Dock Style Addon
            Column(
                modifier = Modifier.padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Navigation Dock Style", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    NavDockStyle.entries.forEach { dock ->
                        val active = settings.navDockStyle == dock
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onSelectNavDockStyle(dock) }
                                .testTag("dock_${dock.name.lowercase()}"),
                            shape = RoundedCornerShape(12.dp),
                            color = if (active) vybe.accentPrimary.copy(alpha = 0.22f) else vybe.surfaceElevated,
                            border = BorderStroke(1.dp, if (active) vybe.accentSecondary else vybe.cardBorder)
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = dock.displayName,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (active) vybe.accentSecondary else vybe.textPrimary
                                )
                            }
                        }
                    }
                }
            }

            // Appearance Tone
            Column(
                modifier = Modifier.padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Appearance", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        AppearanceMode.DARK to "Studio Dark",
                        AppearanceMode.OLED_BLACK to "OLED Black",
                        AppearanceMode.LIGHT to "Daylight"
                    ).forEach { (mode, label) ->
                        val active = settings.appearanceMode == mode
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onSelectAppearance(mode) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (active) vybe.accentPrimary.copy(alpha = 0.2f) else vybe.surfaceElevated,
                            border = BorderStroke(1.dp, if (active) vybe.accentSecondary else vybe.cardBorder)
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (active) vybe.accentSecondary else vybe.textPrimary
                                )
                            }
                        }
                    }
                }
            }

            // Accent Color Selection (all 8 presets)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Accent Signature",
                    style = MaterialTheme.typography.titleMedium,
                    color = vybe.textPrimary,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(AccentPreset.entries) { preset ->
                        val active = settings.accentPreset == preset
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onSelectAccent(preset) }
                                .padding(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(preset.primaryColor, preset.secondaryColor)))
                                    .border(
                                        width = if (active) 2.5.dp else 1.dp,
                                        color = if (active) Color.White else Color.White.copy(alpha = 0.25f),
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (active) {
                                    Icon(
                                        Icons.Filled.Check,
                                        contentDescription = preset.displayName,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = preset.displayName.substringBefore(" "),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (active) vybe.textPrimary else vybe.textMuted
                            )
                        }
                    }
                }
            }

            // Album Artwork Frame (all 7 frames)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Album Artwork Frame",
                    style = MaterialTheme.typography.titleMedium,
                    color = vybe.textPrimary,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(ArtworkStyle.entries) { style ->
                        val active = settings.artworkStyle == style
                        Surface(
                            modifier = Modifier
                                .width(88.dp)
                                .clickable { onSelectArtworkStyle(style) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (active) vybe.accentPrimary.copy(alpha = 0.2f) else vybe.surfaceElevated,
                            border = BorderStroke(1.dp, if (active) vybe.accentSecondary else vybe.cardBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    Icons.Filled.Album,
                                    contentDescription = null,
                                    tint = if (active) vybe.accentSecondary else vybe.textMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    text = style.displayName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (active) vybe.textPrimary else vybe.textMuted,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // Player Background Backdrop
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Player Backdrop",
                    style = MaterialTheme.typography.titleMedium,
                    color = vybe.textPrimary,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(PlayerBackgroundStyle.entries) { bg ->
                        val active = settings.playerBackgroundStyle == bg
                        Surface(
                            modifier = Modifier.clickable { onSelectPlayerBackground(bg) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (active) vybe.accentPrimary.copy(alpha = 0.2f) else vybe.surfaceElevated,
                            border = BorderStroke(1.dp, if (active) vybe.accentSecondary else vybe.cardBorder)
                        ) {
                            Text(
                                text = bg.displayName,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (active) vybe.accentSecondary else vybe.textPrimary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemePreviewCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    gradient: Brush,
    badgeColor: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) badgeColor else Color.White.copy(alpha = 0.14f)
        ),
        shadowElevation = if (selected) 8.dp else 0.dp
    ) {
        Column(
            modifier = Modifier
                .background(gradient)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(22.dp))
                if (selected) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(badgeColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = "Active", tint = Color.Black, modifier = Modifier.size(14.dp))
                    }
                }
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.78f),
                maxLines = 2
            )
        }
    }
}
