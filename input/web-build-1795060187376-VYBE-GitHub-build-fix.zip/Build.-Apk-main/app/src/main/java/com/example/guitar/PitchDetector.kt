package com.example.guitar

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

data class TunerState(
    val isListening: Boolean = false,
    val detectedHz: Double = 0.0,
    val noteName: String = "--",
    val octave: Int = 0,
    val centsOffset: Double = 0.0,
    val isInTune: Boolean = false,
    val signalLevel: Float = 0f,
    val errorMessage: String? = null
)

class PitchDetector {

    private val _tunerState = MutableStateFlow(TunerState())
    val tunerState: StateFlow<TunerState> = _tunerState.asStateFlow()

    private var recordJob: Job? = null
    private var audioRecord: AudioRecord? = null

    @SuppressLint("MissingPermission")
    fun start(scope: CoroutineScope) {
        if (recordJob?.isActive == true) return
        val sampleRate = 44100
        val bufferSize = maxOf(
            AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT),
            4096 * 2
        )

        val recorder = runCatching {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        }.getOrNull()

        if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
            _tunerState.value = TunerState(
                isListening = false,
                errorMessage = "Microphone audio input unavailable on this device."
            )
            return
        }

        audioRecord = recorder
        recorder.startRecording()
        _tunerState.value = TunerState(isListening = true)

        recordJob = scope.launch(Dispatchers.Default) {
            val frameSize = 2048
            val shortBuf = ShortArray(frameSize)
            val floatBuf = FloatArray(frameSize)
            var smoothedHz = 0.0

            while (isActive) {
                val read = recorder.read(shortBuf, 0, frameSize)
                if (read > 0) {
                    var sumSq = 0.0
                    for (i in 0 until read) {
                        val f = shortBuf[i] / 32768f
                        floatBuf[i] = f
                        sumSq += f * f
                    }
                    val rms = sqrt(sumSq / read).toFloat()

                    if (rms > 0.008f) {
                        val pitchResult = detectYinPitch(floatBuf, read, sampleRate)
                        if (pitchResult != null) {
                            val (rawHz, confidence) = pitchResult
                            smoothedHz = if (smoothedHz <= 0.0 || kotlin.math.abs(rawHz - smoothedHz) > smoothedHz * 0.12) {
                                rawHz
                            } else {
                                smoothedHz * 0.65 + rawHz * 0.35
                            }
                            val info = ChordLibraryData.frequencyToNoteInfo(smoothedHz, confidence)
                            if (info != null) {
                                _tunerState.value = TunerState(
                                    isListening = true,
                                    detectedHz = info.frequencyHz,
                                    noteName = info.noteName,
                                    octave = info.octave,
                                    centsOffset = info.centsOffset,
                                    isInTune = kotlin.math.abs(info.centsOffset) <= 5.0,
                                    signalLevel = (rms * 4f).coerceIn(0f, 1f)
                                )
                            }
                        } else {
                            _tunerState.value = _tunerState.value.copy(
                                isListening = true,
                                signalLevel = (rms * 4f).coerceIn(0f, 1f)
                            )
                        }
                    } else {
                        _tunerState.value = _tunerState.value.copy(
                            isListening = true,
                            signalLevel = 0f
                        )
                    }
                }
            }
        }
    }

    fun stop() {
        recordJob?.cancel()
        recordJob = null
        runCatching {
            audioRecord?.stop()
            audioRecord?.release()
        }
        audioRecord = null
        _tunerState.value = TunerState(isListening = false)
    }

    /**
     * YIN fundamental frequency estimator tuned for guitar range (60 Hz .. 1000 Hz)
     */
    private fun detectYinPitch(buffer: FloatArray, size: Int, sampleRate: Int): Pair<Double, Float>? {
        val halfSize = size / 2
        val minTau = sampleRate / 1000 // ~44 samples
        val maxTau = minOf(halfSize - 1, sampleRate / 60) // ~735 samples
        if (maxTau <= minTau) return null

        val yinBuffer = FloatArray(maxTau + 1)
        for (tau in 1..maxTau) {
            var diffSum = 0f
            for (i in 0 until halfSize) {
                val delta = buffer[i] - buffer[i + tau]
                diffSum += delta * delta
            }
            yinBuffer[tau] = diffSum
        }

        // Cumulative mean normalized difference function
        yinBuffer[0] = 1f
        var runningSum = 0f
        for (tau in 1..maxTau) {
            runningSum += yinBuffer[tau]
            yinBuffer[tau] = if (runningSum == 0f) 1f else yinBuffer[tau] * tau / runningSum
        }

        val threshold = 0.15f
        var tauEstimate = -1
        var tau = minTau
        while (tau <= maxTau) {
            if (yinBuffer[tau] < threshold) {
                while (tau + 1 <= maxTau && yinBuffer[tau + 1] < yinBuffer[tau]) {
                    tau++
                }
                tauEstimate = tau
                break
            }
            tau++
        }

        if (tauEstimate == -1) return null

        // Parabolic interpolation for sub-sample frequency precision
        val betterTau = if (tauEstimate > 1 && tauEstimate < maxTau) {
            val s0 = yinBuffer[tauEstimate - 1]
            val s1 = yinBuffer[tauEstimate]
            val s2 = yinBuffer[tauEstimate + 1]
            val denom = 2f * (2f * s1 - s2 - s0)
            if (kotlin.math.abs(denom) > 1e-6f) {
                tauEstimate + (s2 - s0) / denom
            } else {
                tauEstimate.toFloat()
            }
        } else {
            tauEstimate.toFloat()
        }

        val hz = sampleRate.toDouble() / betterTau.toDouble()
        val confidence = (1f - yinBuffer[tauEstimate]).coerceIn(0f, 1f)
        return hz to confidence
    }
}
