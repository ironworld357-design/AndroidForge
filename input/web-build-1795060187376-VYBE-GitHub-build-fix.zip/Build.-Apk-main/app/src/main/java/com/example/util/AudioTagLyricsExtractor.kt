package com.example.util

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets

/**
 * Pure Kotlin binary audio metadata lyrics extractor.
 * Reads embedded synchronized & unsynchronized lyric tags offline from:
 *  - ID3v2 (v2.2 / v2.3 / v2.4): SYLT (synced), USLT (unsynced / LRC), TXXX (LYRICS / SYNCEDLYRICS)
 *  - FLAC: VORBIS_COMMENT (SYNCEDLYRICS / LYRICS / UNSYNCEDLYRICS)
 *  - OGG (Vorbis / Opus): comment packet (SYNCEDLYRICS / LYRICS / UNSYNCEDLYRICS)
 *  - MP4 / M4A: moov -> udta -> meta -> ilst -> ©lyr atom
 *  - RIFF / WAV: embedded "id3 " / "ID3 " chunk
 */
object AudioTagLyricsExtractor {

    data class ExtractedTagLyrics(
        val rawText: String,
        val sourceLabel: String,
        val isSynchronizedHint: Boolean
    )

    private const val MAX_SCAN_BYTES = 4 * 1024 * 1024 // 4 MB header cap for safe memory usage

    fun extractFromFile(file: File): ExtractedTagLyrics? {
        if (!file.exists() || !file.canRead()) return null
        return runCatching {
            file.inputStream().buffered().use { extractFromStream(it) }
        }.getOrNull()
    }

    fun extractFromStream(input: InputStream): ExtractedTagLyrics? {
        val header = readUpTo(input, 12)
        if (header.size < 10) return null

        // 1. ID3v2 tag at start of file (MP3, AAC-ADTS, etc.)
        if (header[0] == 'I'.code.toByte() &&
            header[1] == 'D'.code.toByte() &&
            header[2] == '3'.code.toByte()
        ) {
            val tagSize = decodeSynchsafeInt(header, 6)
            val totalSize = (10 + tagSize).coerceAtMost(MAX_SCAN_BYTES)
            val rest = readUpTo(input, (totalSize - header.size).coerceAtLeast(0))
            return parseId3v2(header + rest)
        }

        // 2. FLAC metadata blocks ("fLaC")
        if (header[0] == 'f'.code.toByte() &&
            header[1] == 'L'.code.toByte() &&
            header[2] == 'a'.code.toByte() &&
            header[3] == 'C'.code.toByte()
        ) {
            val rest = readUpTo(input, MAX_SCAN_BYTES - header.size)
            return parseFlac(header + rest)
        }

        // 3. OGG Vorbis / Opus ("OggS")
        if (header[0] == 'O'.code.toByte() &&
            header[1] == 'g'.code.toByte() &&
            header[2] == 'g'.code.toByte() &&
            header[3] == 'S'.code.toByte()
        ) {
            val rest = readUpTo(input, 256 * 1024)
            return parseOgg(header + rest)
        }

        // 4. MP4 / M4A container ("ftyp" at offset 4)
        if (header.size >= 8 &&
            header[4] == 'f'.code.toByte() &&
            header[5] == 't'.code.toByte() &&
            header[6] == 'y'.code.toByte() &&
            header[7] == 'p'.code.toByte()
        ) {
            val rest = readUpTo(input, MAX_SCAN_BYTES - header.size)
            return parseMp4(header + rest)
        }

        // 5. RIFF / WAVE embedded ID3 chunk
        if (header.size >= 12 &&
            header[0] == 'R'.code.toByte() &&
            header[1] == 'I'.code.toByte() &&
            header[2] == 'F'.code.toByte() &&
            header[3] == 'F'.code.toByte() &&
            header[8] == 'W'.code.toByte() &&
            header[9] == 'A'.code.toByte() &&
            header[10] == 'V'.code.toByte() &&
            header[11] == 'E'.code.toByte()
        ) {
            return parseWavId3Chunk(header, input)
        }

        return null
    }

    fun parseId3v2(bytes: ByteArray): ExtractedTagLyrics? {
        if (bytes.size < 10) return null
        if (bytes[0] != 'I'.code.toByte() || bytes[1] != 'D'.code.toByte() || bytes[2] != '3'.code.toByte()) {
            return null
        }

        val majorVersion = bytes[3].toInt() and 0xFF
        val flags = bytes[5].toInt() and 0xFF
        val tagSize = decodeSynchsafeInt(bytes, 6)
        val tagEnd = minOf(bytes.size, 10 + tagSize)
        var pos = 10

        // Skip optional extended header (v2.3 / v2.4)
        if ((flags and 0x40) != 0 && pos + 4 <= tagEnd) {
            val extSize = if (majorVersion >= 4) decodeSynchsafeInt(bytes, pos) else readInt32BE(bytes, pos)
            pos += if (majorVersion >= 4) extSize.coerceAtLeast(6) else (4 + extSize).coerceAtLeast(4)
        }

        var bestSynced: ExtractedTagLyrics? = null
        var bestPlain: ExtractedTagLyrics? = null

        val headerSize = if (majorVersion == 2) 6 else 10
        while (pos + headerSize <= tagEnd) {
            if (bytes[pos] == 0.toByte()) break // padding

            val frameId: String
            val frameSize: Int
            if (majorVersion == 2) {
                frameId = String(bytes, pos, 3, StandardCharsets.ISO_8859_1)
                frameSize = ((bytes[pos + 3].toInt() and 0xFF) shl 16) or
                    ((bytes[pos + 4].toInt() and 0xFF) shl 8) or
                    (bytes[pos + 5].toInt() and 0xFF)
                pos += 6
            } else {
                frameId = String(bytes, pos, 4, StandardCharsets.ISO_8859_1)
                frameSize = if (majorVersion >= 4) decodeSynchsafeInt(bytes, pos + 4) else readInt32BE(bytes, pos + 4)
                pos += 10
            }

            if (frameSize <= 0 || pos + frameSize > tagEnd) break

            when (frameId) {
                "SYLT", "SLT" -> {
                    val lrc = parseSyltFrame(bytes, pos, pos + frameSize)
                    if (!lrc.isNullOrBlank()) {
                        bestSynced = ExtractedTagLyrics(
                            rawText = lrc,
                            sourceLabel = "Embedded ID3 SYLT Tag",
                            isSynchronizedHint = true
                        )
                    }
                }
                "USLT", "ULT" -> {
                    val text = parseUsltFrame(bytes, pos, pos + frameSize)
                    if (!text.isNullOrBlank()) {
                        val hasLrcTimestamps = containsLrcTimestamp(text)
                        if (hasLrcTimestamps && bestSynced == null) {
                            bestSynced = ExtractedTagLyrics(
                                rawText = text,
                                sourceLabel = "Embedded ID3 USLT (Synced)",
                                isSynchronizedHint = true
                            )
                        } else if (bestPlain == null) {
                            bestPlain = ExtractedTagLyrics(
                                rawText = text,
                                sourceLabel = "Embedded ID3 USLT Tag",
                                isSynchronizedHint = false
                            )
                        }
                    }
                }
                "TXXX", "TXX" -> {
                    val (desc, value) = parseTxxxFrame(bytes, pos, pos + frameSize) ?: (null to null)
                    if (desc != null && !value.isNullOrBlank()) {
                        val key = desc.uppercase()
                        if (key in setOf("LYRICS", "SYNCEDLYRICS", "SYNCED LYRICS", "UNSYNCEDLYRICS", "UNSYNCED LYRICS", "LRC")) {
                            val hasLrc = containsLrcTimestamp(value)
                            if (hasLrc && bestSynced == null) {
                                bestSynced = ExtractedTagLyrics(value, "Embedded ID3 $desc Tag", true)
                            } else if (bestPlain == null) {
                                bestPlain = ExtractedTagLyrics(value, "Embedded ID3 $desc Tag", false)
                            }
                        }
                    }
                }
            }
            pos += frameSize
        }

        return bestSynced ?: bestPlain
    }

    private fun parseSyltFrame(bytes: ByteArray, start: Int, end: Int): String? {
        // ID3 SYLT: [encoding(1)] [lang(3)] [timestampFormat(1)] [contentType(1)] [descriptor + null] [entries...]
        if (end - start < 7) return null
        val encodingByte = bytes[start].toInt() and 0xFF
        val charset = id3Charset(encodingByte)
        val timeFormat = bytes[start + 4].toInt() and 0xFF // 1 = MPEG frames, 2 = milliseconds
        // Skip descriptor (null-terminated)
        val afterDesc = findNullTerminatorEnd(bytes, start + 6, end, isDoubleByte = isUtf16Encoding(encodingByte))
        var cursor = afterDesc
        val sb = StringBuilder()

        while (cursor < end) {
            val textEnd = findNullTerminatorStart(bytes, cursor, end, isDoubleByte = isUtf16Encoding(encodingByte))
            val nullLen = if (isUtf16Encoding(encodingByte)) 2 else 1
            val tsPos = textEnd + nullLen
            if (tsPos + 4 > end) break

            val rawLine = decodeId3Text(bytes, cursor, textEnd, charset, encodingByte).trim()
            val rawTimestamp = readUInt32BE(bytes, tsPos)
            // Timestamp format 2 = milliseconds; format 1 = MPEG frames (approx 26.12ms/frame at 44.1kHz)
            val ms = if (timeFormat == 1) (rawTimestamp * 26L) else rawTimestamp
            if (rawLine.isNotEmpty()) {
                sb.append(formatLrcTimestamp(ms)).append(rawLine).append('\n')
            }
            cursor = tsPos + 4
        }

        return sb.toString().trim().takeIf { it.isNotEmpty() }
    }

    private fun parseUsltFrame(bytes: ByteArray, start: Int, end: Int): String? {
        // ID3 USLT: [encoding(1)] [lang(3)] [descriptor + null] [lyrics...]
        if (end - start < 5) return null
        val encodingByte = bytes[start].toInt() and 0xFF
        val charset = id3Charset(encodingByte)
        val textStart = findNullTerminatorEnd(bytes, start + 4, end, isDoubleByte = isUtf16Encoding(encodingByte))
        if (textStart >= end) return null
        return decodeId3Text(bytes, textStart, end, charset, encodingByte).trim().takeIf { it.isNotEmpty() }
    }

    private fun parseTxxxFrame(bytes: ByteArray, start: Int, end: Int): Pair<String, String>? {
        if (end - start < 2) return null
        val encodingByte = bytes[start].toInt() and 0xFF
        val charset = id3Charset(encodingByte)
        val isUtf16 = isUtf16Encoding(encodingByte)
        val descEnd = findNullTerminatorStart(bytes, start + 1, end, isDoubleByte = isUtf16)
        val nullLen = if (isUtf16) 2 else 1
        val valStart = descEnd + nullLen
        if (valStart >= end) return null
        val desc = decodeId3Text(bytes, start + 1, descEnd, charset, encodingByte).trim()
        val value = decodeId3Text(bytes, valStart, end, charset, encodingByte).trim()
        return desc to value
    }

    fun parseFlac(bytes: ByteArray): ExtractedTagLyrics? {
        if (bytes.size < 8) return null
        if (bytes[0] != 'f'.code.toByte() || bytes[1] != 'L'.code.toByte() ||
            bytes[2] != 'a'.code.toByte() || bytes[3] != 'C'.code.toByte()
        ) return null

        var pos = 4
        while (pos + 4 <= bytes.size) {
            val headerByte = bytes[pos].toInt() and 0xFF
            val isLast = (headerByte and 0x80) != 0
            val blockType = headerByte and 0x7F
            val blockLen = ((bytes[pos + 1].toInt() and 0xFF) shl 16) or
                ((bytes[pos + 2].toInt() and 0xFF) shl 8) or
                (bytes[pos + 3].toInt() and 0xFF)
            pos += 4
            if (blockLen < 0 || pos + blockLen > bytes.size) break
            if (blockType == 4) { // VORBIS_COMMENT
                return parseVorbisCommentBlock(bytes, pos, pos + blockLen, "Embedded FLAC Tag")
            }
            pos += blockLen
            if (isLast) break
        }
        return null
    }

    private fun parseOgg(bytes: ByteArray): ExtractedTagLyrics? {
        val vorbisMarker = byteArrayOf(0x03, 'v'.code.toByte(), 'o'.code.toByte(), 'r'.code.toByte(), 'b'.code.toByte(), 'i'.code.toByte(), 's'.code.toByte())
        val opusMarker = "OpusTags".toByteArray(StandardCharsets.US_ASCII)

        val vIdx = indexOfSequence(bytes, vorbisMarker)
        if (vIdx >= 0) {
            return parseVorbisCommentBlock(bytes, vIdx + vorbisMarker.size, bytes.size, "Embedded OGG Tag")
        }
        val oIdx = indexOfSequence(bytes, opusMarker)
        if (oIdx >= 0) {
            return parseVorbisCommentBlock(bytes, oIdx + opusMarker.size, bytes.size, "Embedded Opus Tag")
        }
        return null
    }

    private fun parseVorbisCommentBlock(
        bytes: ByteArray,
        start: Int,
        end: Int,
        sourcePrefix: String
    ): ExtractedTagLyrics? {
        if (end - start < 8) return null
        var pos = start
        val vendorLen = readInt32LE(bytes, pos)
        pos += 4
        if (vendorLen < 0 || pos + vendorLen + 4 > end) return null
        pos += vendorLen

        val commentCount = readInt32LE(bytes, pos).coerceIn(0, 512)
        pos += 4

        var synced: ExtractedTagLyrics? = null
        var plain: ExtractedTagLyrics? = null

        for (i in 0 until commentCount) {
            if (pos + 4 > end) break
            val len = readInt32LE(bytes, pos)
            pos += 4
            if (len < 0 || pos + len > end) break
            val comment = String(bytes, pos, len, StandardCharsets.UTF_8)
            pos += len

            val eqIdx = comment.indexOf('=')
            if (eqIdx <= 0) continue
            val key = comment.substring(0, eqIdx).trim().uppercase()
            val value = comment.substring(eqIdx + 1).trim()
            if (value.isEmpty()) continue

            if (key in setOf("SYNCEDLYRICS", "LYRICS", "UNSYNCEDLYRICS", "LRC")) {
                val hasLrc = containsLrcTimestamp(value)
                if (hasLrc && synced == null) {
                    synced = ExtractedTagLyrics(value, "$sourcePrefix ($key)", true)
                } else if (plain == null) {
                    plain = ExtractedTagLyrics(value, "$sourcePrefix ($key)", false)
                }
            }
        }
        return synced ?: plain
    }

    fun parseMp4(bytes: ByteArray): ExtractedTagLyrics? {
        // Scan for ©lyr atom inside MP4/M4A moov/udta/meta/ilst hierarchy
        return findMp4LyricAtom(bytes, 0, bytes.size)
    }

    private fun findMp4LyricAtom(bytes: ByteArray, start: Int, end: Int): ExtractedTagLyrics? {
        var pos = start
        val containers = setOf("moov", "udta", "meta", "ilst")
        while (pos + 8 <= end) {
            var boxSize = readUInt32BE(bytes, pos).toInt()
            val boxType = String(bytes, pos + 4, 4, StandardCharsets.ISO_8859_1)
            if (boxSize <= 0) break
            if (pos + boxSize > end) boxSize = end - pos
            val contentStart = pos + 8
            val contentEnd = pos + boxSize

            if (boxType == "\u00A9lyr" || (bytes[pos + 4] == 0xA9.toByte() &&
                    bytes[pos + 5] == 'l'.code.toByte() &&
                    bytes[pos + 6] == 'y'.code.toByte() &&
                    bytes[pos + 7] == 'r'.code.toByte())
            ) {
                val dataText = extractMp4DataAtom(bytes, contentStart, contentEnd)
                if (!dataText.isNullOrBlank()) {
                    val hasLrc = containsLrcTimestamp(dataText)
                    return ExtractedTagLyrics(
                        rawText = dataText,
                        sourceLabel = "Embedded M4A ©lyr Tag",
                        isSynchronizedHint = hasLrc
                    )
                }
            } else if (boxType in containers) {
                // "meta" box has a 4-byte version/flags header before child atoms
                val childStart = if (boxType == "meta") contentStart + 4 else contentStart
                if (childStart < contentEnd) {
                    val found = findMp4LyricAtom(bytes, childStart, contentEnd)
                    if (found != null) return found
                }
            }
            pos += boxSize
        }
        return null
    }

    private fun extractMp4DataAtom(bytes: ByteArray, start: Int, end: Int): String? {
        var pos = start
        while (pos + 8 <= end) {
            val size = readUInt32BE(bytes, pos).toInt()
            val type = String(bytes, pos + 4, 4, StandardCharsets.ISO_8859_1)
            if (size <= 0 || pos + size > end) break
            if (type == "data" && size > 16) {
                val payloadStart = pos + 16 // 8 atom header + 4 type + 4 locale
                val payloadLen = (pos + size) - payloadStart
                return String(bytes, payloadStart, payloadLen, StandardCharsets.UTF_8).trim()
            }
            pos += size
        }
        return null
    }

    private fun parseWavId3Chunk(initialHeader: ByteArray, input: InputStream): ExtractedTagLyrics? {
        // Walk RIFF chunks after the 12-byte "RIFF....WAVE" header without buffering huge PCM "data" chunks
        var chunkHeader = readUpTo(input, 8)
        var chunksScanned = 0
        while (chunkHeader.size == 8 && chunksScanned < 32) {
            chunksScanned++
            val chunkId = String(chunkHeader, 0, 4, StandardCharsets.ISO_8859_1)
            val chunkSize = readInt32LE(chunkHeader, 4).toLong() and 0xFFFFFFFFL
            val paddedSize = chunkSize + (chunkSize and 1L)
            if (chunkId.equals("id3 ", ignoreCase = true) && chunkSize in 10L..MAX_SCAN_BYTES.toLong()) {
                val id3Bytes = readUpTo(input, chunkSize.toInt())
                return parseId3v2(id3Bytes)
            } else {
                var skipped = 0L
                while (skipped < paddedSize) {
                    val s = input.skip(paddedSize - skipped)
                    if (s <= 0L) break
                    skipped += s
                }
                if (skipped < paddedSize) break
            }
            chunkHeader = readUpTo(input, 8)
        }
        return null
    }

    private fun containsLrcTimestamp(text: String): Boolean =
        Regex("""\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?]""").containsMatchIn(text)

    private fun formatLrcTimestamp(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val min = safe / 60_000L
        val sec = (safe % 60_000L) / 1000L
        val centi = (safe % 1000L) / 10L
        return "[%02d:%02d.%02d]".format(min, sec, centi)
    }

    private fun isUtf16Encoding(enc: Int): Boolean = enc == 1 || enc == 2

    private fun id3Charset(enc: Int): Charset = when (enc) {
        1 -> StandardCharsets.UTF_16
        2 -> StandardCharsets.UTF_16BE
        3 -> StandardCharsets.UTF_8
        else -> StandardCharsets.ISO_8859_1
    }

    private fun decodeId3Text(
        bytes: ByteArray,
        start: Int,
        end: Int,
        charset: Charset,
        encodingByte: Int
    ): String {
        if (start >= end) return ""
        val raw = String(bytes, start, end - start, charset)
        return raw.trimEnd('\u0000')
    }

    private fun findNullTerminatorStart(bytes: ByteArray, start: Int, end: Int, isDoubleByte: Boolean): Int {
        var i = start
        if (isDoubleByte) {
            while (i + 1 < end) {
                if (bytes[i] == 0.toByte() && bytes[i + 1] == 0.toByte()) return i
                i += 2
            }
        } else {
            while (i < end) {
                if (bytes[i] == 0.toByte()) return i
                i++
            }
        }
        return end
    }

    private fun findNullTerminatorEnd(bytes: ByteArray, start: Int, end: Int, isDoubleByte: Boolean): Int {
        val nullStart = findNullTerminatorStart(bytes, start, end, isDoubleByte)
        return if (nullStart >= end) end else (nullStart + if (isDoubleByte) 2 else 1).coerceAtMost(end)
    }

    private fun decodeSynchsafeInt(b: ByteArray, offset: Int): Int {
        if (offset + 4 > b.size) return 0
        return ((b[offset].toInt() and 0x7F) shl 21) or
            ((b[offset + 1].toInt() and 0x7F) shl 14) or
            ((b[offset + 2].toInt() and 0x7F) shl 7) or
            (b[offset + 3].toInt() and 0x7F)
    }

    private fun readInt32BE(b: ByteArray, offset: Int): Int {
        if (offset + 4 > b.size) return 0
        return ((b[offset].toInt() and 0xFF) shl 24) or
            ((b[offset + 1].toInt() and 0xFF) shl 16) or
            ((b[offset + 2].toInt() and 0xFF) shl 8) or
            (b[offset + 3].toInt() and 0xFF)
    }

    private fun readUInt32BE(b: ByteArray, offset: Int): Long {
        if (offset + 4 > b.size) return 0L
        return ((b[offset].toLong() and 0xFF) shl 24) or
            ((b[offset + 1].toLong() and 0xFF) shl 16) or
            ((b[offset + 2].toLong() and 0xFF) shl 8) or
            (b[offset + 3].toLong() and 0xFF)
    }

    private fun readInt32LE(b: ByteArray, offset: Int): Int {
        if (offset + 4 > b.size) return 0
        return (b[offset].toInt() and 0xFF) or
            ((b[offset + 1].toInt() and 0xFF) shl 8) or
            ((b[offset + 2].toInt() and 0xFF) shl 16) or
            ((b[offset + 3].toInt() and 0xFF) shl 24)
    }

    private fun indexOfSequence(haystack: ByteArray, needle: ByteArray): Int {
        if (needle.isEmpty() || haystack.size < needle.size) return -1
        outer@ for (i in 0..(haystack.size - needle.size)) {
            for (j in needle.indices) {
                if (haystack[i + j] != needle[j]) continue@outer
            }
            return i
        }
        return -1
    }

    private fun readUpTo(input: InputStream, maxBytes: Int): ByteArray {
        if (maxBytes <= 0) return ByteArray(0)
        val out = ByteArrayOutputStream(minOf(maxBytes, 8192))
        val buf = ByteArray(8192)
        var remaining = maxBytes
        while (remaining > 0) {
            val read = input.read(buf, 0, minOf(buf.size, remaining))
            if (read <= 0) break
            out.write(buf, 0, read)
            remaining -= read
        }
        return out.toByteArray()
    }
}
