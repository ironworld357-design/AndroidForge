package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.audio.VybeMediaService
import com.example.model.Song

object VybeWidgetUpdater {

    fun updateAllWidgets(
        context: Context,
        song: Song?,
        isPlaying: Boolean,
        positionMs: Long,
        durationMs: Long
    ) {
        val appWidgetManager = AppWidgetManager.getInstance(context)

        val compactIds = appWidgetManager.getAppWidgetIds(
            ComponentName(context, VybeCompactWidgetProvider::class.java)
        )
        if (compactIds.isNotEmpty()) {
            val views = buildCompactViews(context, song, isPlaying)
            compactIds.forEach { appWidgetManager.updateAppWidget(it, views) }
        }

        val largeIds = appWidgetManager.getAppWidgetIds(
            ComponentName(context, VybeLargeWidgetProvider::class.java)
        )
        if (largeIds.isNotEmpty()) {
            val views = buildLargeViews(context, song, isPlaying, positionMs, durationMs)
            largeIds.forEach { appWidgetManager.updateAppWidget(it, views) }
        }
    }

    private fun buildCompactViews(
        context: Context,
        song: Song?,
        isPlaying: Boolean
    ): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_vybe_compact)
        views.setTextViewText(R.id.widget_compact_title, song?.title ?: "VYBE")
        views.setTextViewText(R.id.widget_compact_artist, song?.artist ?: "Feel Every Beat.")
        views.setImageViewResource(
            R.id.widget_compact_play_pause,
            if (isPlaying) R.drawable.ic_widget_pause else R.drawable.ic_widget_play
        )

        val artBitmap = loadSmallArtwork(context, song)
        if (artBitmap != null) {
            views.setImageViewBitmap(R.id.widget_compact_art, artBitmap)
        } else {
            views.setImageViewResource(R.id.widget_compact_art, R.drawable.img_default_album)
        }

        views.setOnClickPendingIntent(R.id.widget_compact_root, launchAppPendingIntent(context))
        views.setOnClickPendingIntent(
            R.id.widget_compact_prev,
            serviceActionPendingIntent(context, VybeMediaService.ACTION_WIDGET_PREV, 101)
        )
        views.setOnClickPendingIntent(
            R.id.widget_compact_play_pause,
            serviceActionPendingIntent(context, VybeMediaService.ACTION_WIDGET_PLAY_PAUSE, 102)
        )
        views.setOnClickPendingIntent(
            R.id.widget_compact_next,
            serviceActionPendingIntent(context, VybeMediaService.ACTION_WIDGET_NEXT, 103)
        )
        return views
    }

    private fun buildLargeViews(
        context: Context,
        song: Song?,
        isPlaying: Boolean,
        positionMs: Long,
        durationMs: Long
    ): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_vybe_large)
        views.setTextViewText(R.id.widget_large_title, song?.title ?: "Ready to Play")
        views.setTextViewText(R.id.widget_large_artist, song?.artist ?: "Tap to open VYBE")
        views.setTextViewText(R.id.widget_large_album, song?.album ?: "Offline Library")
        views.setTextViewText(R.id.widget_large_format, song?.formatBadge ?: "HI-FI")

        views.setImageViewResource(
            R.id.widget_large_play_pause,
            if (isPlaying) R.drawable.ic_widget_pause else R.drawable.ic_widget_play
        )
        views.setImageViewResource(
            R.id.widget_large_fav,
            if (song?.isFavorite == true) R.drawable.ic_widget_heart_filled else R.drawable.ic_widget_heart_outline
        )

        val progress = if (durationMs > 0L) {
            ((positionMs.toFloat() / durationMs.toFloat()) * 1000f).toInt().coerceIn(0, 1000)
        } else 0
        views.setProgressBar(R.id.widget_large_progress, 1000, progress, false)

        val artBitmap = loadSmallArtwork(context, song)
        if (artBitmap != null) {
            views.setImageViewBitmap(R.id.widget_large_art, artBitmap)
        } else {
            views.setImageViewResource(R.id.widget_large_art, R.drawable.img_default_album)
        }

        views.setOnClickPendingIntent(R.id.widget_large_root, launchAppPendingIntent(context))
        views.setOnClickPendingIntent(
            R.id.widget_large_prev,
            serviceActionPendingIntent(context, VybeMediaService.ACTION_WIDGET_PREV, 201)
        )
        views.setOnClickPendingIntent(
            R.id.widget_large_play_pause,
            serviceActionPendingIntent(context, VybeMediaService.ACTION_WIDGET_PLAY_PAUSE, 202)
        )
        views.setOnClickPendingIntent(
            R.id.widget_large_next,
            serviceActionPendingIntent(context, VybeMediaService.ACTION_WIDGET_NEXT, 203)
        )
        views.setOnClickPendingIntent(
            R.id.widget_large_fav,
            serviceActionPendingIntent(context, VybeMediaService.ACTION_WIDGET_FAVORITE, 204)
        )
        return views
    }

    private fun loadSmallArtwork(context: Context, song: Song?): Bitmap? {
        if (song == null) return null
        val uriStr = song.customArtworkUri ?: "content://media/external/audio/albumart/${song.albumId}"
        return runCatching {
            val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
            context.contentResolver.openInputStream(Uri.parse(uriStr))?.use { stream ->
                BitmapFactory.decodeStream(stream, null, opts)
            }
        }.getOrNull()
    }

    private fun launchAppPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        return PendingIntent.getActivity(
            context,
            100,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun serviceActionPendingIntent(context: Context, action: String, reqCode: Int): PendingIntent {
        val intent = Intent(context, VybeMediaService::class.java).apply {
            this.action = action
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PendingIntent.getForegroundService(
                context,
                reqCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else {
            PendingIntent.getService(
                context,
                reqCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}

class VybeCompactWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        VybeWidgetUpdater.updateAllWidgets(context, null, false, 0L, 0L)
    }
}

class VybeLargeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        VybeWidgetUpdater.updateAllWidgets(context, null, false, 0L, 0L)
    }
}
