package com.example.guitar

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.roundToInt
import kotlin.math.sin

enum class TimeSignature(val label: String, val beatsPerBar: Int) {
    TWO_FOUR("2/4", 2),
    THREE_FOUR("3/4", 3),
    FOUR_FOUR("4/4", 4),
    FIVE_FOUR("5/4", 5),
    SIX_EIGHT("6/8", 6),
    SEVEN_EIGHT("7/8", 7)
}

data class MetronomeState(
    val isRunning: Boolean = false,
    val bpm: Int = 100,
    val timeSignature: TimeSignature = TimeSignature.FOUR_FOUR,
    val accentFirstBeat: Boolean = true,
    val currentBeat: Int = 0, // 1..beatsPerBar
    val completedBars: Int = 0
)

class MetronomeEngine {

    private val _state = MutableStateFlow(MetronomeState())
    val state: StateFlow<MetronomeState> = _state.asStateFlow()

    private var playJob: Job? = null
    private val tapTimestamps = mutableListOf<Long>()

    private val sampleRate = 44100
    private val accentClickPcm = synthesizeClick(freqHz = 1280.0, durationMs = 28, amp = 0.85)
    private val regularClickPcm = synthesizeClick(freqHz = 840.0, durationMs = 22, amp = 0.6)

    fun setBpm(bpm: Int) {
        _state.update { it.copy(bpm = bpm.coerceIn(30, 260)) }
    }

    fun setTimeSignature(sig: TimeSignature) {
        _state.update { it.copy(timeSignature = sig, currentBeat = 0) }
    }

    fun setAccentFirstBeat(enabled: Boolean) {
        _state.update { it.copy(accentFirstBeat = enabled) }
    }

    fun registerTapTempo(): Int {
        val now = System.currentTimeMillis()
        if (tapTimestamps.isNotEmpty() && now - tapTimestamps.last() > 2200L) {
            tapTimestamps.clear()
        }
        tapTimestamps.add(now)
        if (tapTimestamps.size > 6) {
            tapTimestamps.removeAt(0)
        }
        if (tapTimestamps.size >= 2) {
            val intervals = tapTimestamps.zipWithNext { a, b -> b - a }
            val avgMs = intervals.average()
            if (avgMs > 150.0) {
                val computedBpm = (60_000.0 / avgMs).roundToInt().coerceIn(30, 260)
                setBpm(computedBpm)
                return computedBpm
            }
        }
        return _state.value.bpm
    }

    fun start(scope: CoroutineScope) {
        if (playJob?.isActive == true) return
        _state.update { it.copy(isRunning = true, currentBeat = 0, completedBars = 0) }

        playJob = scope.launch(Dispatchers.Default) {
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(sampleRate / 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            track.play()
            var beatCounter = 0

            try {
                while (isActive) {
                    val cur = _state.value
                    val beatsPerBar = cur.timeSignature.beatsPerBar
                    val beatInBar = (beatCounter % beatsPerBar) + 1
                    val isAccent = cur.accentFirstBeat && beatInBar == 1
                    val barsDone = beatCounter / beatsPerBar

                    _state.update {
                        it.copy(currentBeat = beatInBar, completedBars = barsDone)
                    }

                    val click = if (isAccent) accentClickPcm else regularClickPcm
                    val beatSamples = ((60.0 / cur.bpm.toDouble()) * sampleRate).roundToInt()
                    val silenceSamples = (beatSamples - click.size).coerceAtLeast(0)

                    track.write(click, 0, click.size)
                    // Write silence in chunks so BPM changes / stop are super responsive
                    var remainingSilence = silenceSamples
                    val chunk = ShortArray(1024)
                    while (remainingSilence > 0 && isActive) {
                        val toWrite = minOf(chunk.size, remainingSilence)
                        track.write(chunk, 0, toWrite)
                        remainingSilence -= toWrite
                    }
                    beatCounter++
                }
            } finally {
                runCatching {
                    track.stop()
                    track.release()
                }
            }
        }
    }

    fun stop() {
        playJob?.cancel()
        playJob = null
        _state.update { it.copy(isRunning = false, currentBeat = 0) }
    }

    private fun synthesizeClick(freqHz: Double, durationMs: Int, amp: Double): ShortArray {
        val count = (sampleRate * durationMs) / 1000
        return ShortArray(count) { i ->
            val t = i.toDouble() / sampleRate.toDouble()
            val env = exp(-t * 140.0)
            val wave = sin(2.0 * PI * freqHz * t) + 0.4 * sin(2.0 * PI * freqHz * 2.0 * t)
            ((wave * env * amp).coerceIn(-0.98, 0.98) * 32767.0).toInt().toShort()
        }
    }
}
