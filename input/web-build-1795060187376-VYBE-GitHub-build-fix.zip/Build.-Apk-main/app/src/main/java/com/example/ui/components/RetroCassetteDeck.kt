package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Song
import com.example.ui.theme.CourierPrimeFamily
import com.example.ui.theme.RetroAmber
import com.example.ui.theme.RetroBrushed
import com.example.ui.theme.RetroCharcoal
import com.example.ui.theme.RetroCopper
import com.example.ui.theme.RetroCream
import com.example.util.TimeFormatter
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RetroCassetteDeck(
    song: Song?,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    playbackSpeed: Float,
    animationsEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    var reelAngleDeg by remember { mutableFloatStateOf(0f) }
    var reelSpeedDegPerSec by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(isPlaying, playbackSpeed, animationsEnabled) {
        var lastNs = 0L
        while (true) {
            withFrameNanos { nowNs ->
                if (lastNs == 0L) lastNs = nowNs
                val dt = ((nowNs - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastNs = nowNs

                val targetSpeed = if (isPlaying && animationsEnabled) 135f * playbackSpeed else 0f
                val accel = if (isPlaying) 6f else 3.5f
                reelSpeedDegPerSec += (targetSpeed - reelSpeedDegPerSec) * (dt * accel).coerceIn(0f, 1f)
                reelAngleDeg = (reelAngleDeg + reelSpeedDegPerSec * dt) % 360f
            }
            if (!isPlaying && reelSpeedDegPerSec < 0.5f) {
                kotlinx.coroutines.delay(150L)
            }
        }
    }

    val progress = if (durationMs > 0L) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0.15f

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = RetroBrushed,
        border = BorderStroke(1.5.dp, RetroAmber.copy(alpha = 0.45f)),
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF332922), Color(0xFF1F1914))
                    )
                )
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top mechanical screw & model strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CassetteScrew()
                Text(
                    text = "VYBE TYPE-IV • METAL BIAS • ${song?.formatBadge ?: "TAPE"}",
                    fontFamily = CourierPrimeFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = RetroAmber,
                    letterSpacing = 1.sp
                )
                CassetteScrew()
            }

            // Classic Cream Paper Cassette Label
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = RetroCream,
                border = BorderStroke(1.dp, Color(0xFF9C8468))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SIDE A",
                            fontFamily = CourierPrimeFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = RetroCopper
                        )
                        Text(
                            text = "${TimeFormatter.formatDuration(positionMs)} / ${TimeFormatter.formatDuration(durationMs)}",
                            fontFamily = CourierPrimeFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color(0xFF3E2D20)
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = song?.title ?: "INSERT CASSETTE / SELECT TRACK",
                        fontFamily = CourierPrimeFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF1C140E),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${song?.artist ?: "VYBE Analog Deck"} — ${song?.album ?: "Offline Tape"}",
                        fontFamily = CourierPrimeFamily,
                        fontSize = 12.sp,
                        color = Color(0xFF5A4636),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Tape Window with Twin Rotating Reels & Dynamic Tape Spools
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(106.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(RetroCharcoal)
                    .border(1.5.dp, RetroAmber.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    val w = size.width
                    val h = size.height
                    val leftCenter = Offset(w * 0.27f, h * 0.5f)
                    val rightCenter = Offset(w * 0.73f, h * 0.5f)

                    // Tape spools grow/shrink dynamically with playback progress
                    val leftTapeR = h * (0.40f - 0.14f * progress)
                    val rightTapeR = h * (0.26f + 0.14f * progress)

                    drawCircle(color = Color(0xFF3E291A), radius = leftTapeR, center = leftCenter)
                    drawCircle(color = Color(0xFF3E291A), radius = rightTapeR, center = rightCenter)

                    // Center magnetic bridge window markings
                    drawRoundRect(
                        color = Color(0xFF282019),
                        topLeft = Offset(w * 0.38f, h * 0.25f),
                        size = Size(w * 0.24f, h * 0.5f),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                    )
                    for (t in 0..4) {
                        val tx = w * (0.41f + t * 0.045f)
                        drawLine(
                            color = RetroAmber.copy(alpha = 0.45f),
                            start = Offset(tx, h * 0.35f),
                            end = Offset(tx, h * 0.65f),
                            strokeWidth = 1.5.dp.toPx()
                        )
                    }

                    // Rotating Reel Hubs (6 teeth each)
                    listOf(leftCenter, rightCenter).forEach { center ->
                        val hubR = h * 0.20f
                        drawCircle(color = RetroCream, radius = hubR, center = center)
                        drawCircle(color = RetroCharcoal, radius = hubR * 0.66f, center = center)
                        rotate(degrees = reelAngleDeg, pivot = center) {
                            for (tooth in 0 until 6) {
                                val a = (tooth * 60.0) * PI / 180.0
                                val p1 = Offset(
                                    center.x + cos(a).toFloat() * hubR * 0.45f,
                                    center.y + sin(a).toFloat() * hubR * 0.45f
                                )
                                val p2 = Offset(
                                    center.x + cos(a).toFloat() * hubR * 0.9f,
                                    center.y + sin(a).toFloat() * hubR * 0.9f
                                )
                                drawLine(
                                    color = RetroAmber,
                                    start = p1,
                                    end = p2,
                                    strokeWidth = 2.5.dp.toPx()
                                )
                            }
                        }
                    }

                    // Tape guide rollers at bottom corners
                    drawCircle(color = Color(0xFF78685A), radius = 5.dp.toPx(), center = Offset(w * 0.10f, h * 0.82f))
                    drawCircle(color = Color(0xFF78685A), radius = 5.dp.toPx(), center = Offset(w * 0.90f, h * 0.82f))
                    drawLine(
                        color = Color(0xFF6B4C35),
                        start = Offset(w * 0.10f, h * 0.82f),
                        end = Offset(w * 0.90f, h * 0.82f),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }

            // Bottom trapezoid head gate + screws
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CassetteScrew()
                Box(
                    modifier = Modifier
                        .size(width = 140.dp, height = 14.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF14100D))
                        .border(1.dp, Color(0xFF4A3D32), RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isPlaying) "● REC / PLAY HEAD ENGAGED" else "❚❚ TAPE STANDBY",
                        fontFamily = CourierPrimeFamily,
                        fontSize = 8.sp,
                        color = if (isPlaying) Color(0xFF84CC16) else RetroAmber.copy(alpha = 0.7f)
                    )
                }
                CassetteScrew()
            }
        }
    }
}

@Composable
private fun CassetteScrew() {
    Box(
        modifier = Modifier
            .size(10.dp)
            .clip(CircleShape)
            .background(Color(0xFF4E433A))
            .border(0.8.dp, Color(0xFF1A1410), CircleShape)
    )
}
