package com.example

import android.app.Application
import com.example.audio.AudioEffectsEngine
import com.example.audio.VybeDspAudioProcessor
import com.example.audio.VybePlayerController
import com.example.data.local.SettingsDataStore
import com.example.data.local.VybeDatabase
import com.example.data.repo.MusicRepository
import com.example.data.scanner.MediaStoreScanner
import kotlinx.coroutines.flow.MutableStateFlow

class VybeApplication : Application() {

    val isCrossfadingFlow = MutableStateFlow(false)

    lateinit var database: VybeDatabase
        private set
    lateinit var settingsDataStore: SettingsDataStore
        private set
    lateinit var scanner: MediaStoreScanner
        private set
    lateinit var musicRepository: MusicRepository
        private set
    lateinit var dspProcessor: VybeDspAudioProcessor
        private set
    lateinit var audioEffectsEngine: AudioEffectsEngine
        private set
    lateinit var playerController: VybePlayerController
        private set

    override fun onCreate() {
        super.onCreate()
        database = VybeDatabase.getInstance(this)
        settingsDataStore = SettingsDataStore(this)
        scanner = MediaStoreScanner(this)
        musicRepository = MusicRepository(this, database, scanner)
        dspProcessor = VybeDspAudioProcessor()
        audioEffectsEngine = AudioEffectsEngine()
        playerController = VybePlayerController(
            context = this,
            musicRepository = musicRepository,
            settingsDataStore = settingsDataStore,
            dspProcessor = dspProcessor,
            audioEffectsEngine = audioEffectsEngine
        )
    }
}
