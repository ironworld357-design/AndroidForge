package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalVybeStyle

@Composable
fun VinylTurntableView(
    artworkModel: Any?,
    isPlaying: Boolean,
    playbackSpeed: Float,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current

    // Realistic turntable platter inertia: smooth spin-up & gradual coast-down when paused
    var platterAngle by remember { mutableFloatStateOf(0f) }
    var currentDegPerSec by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(isPlaying, playbackSpeed) {
        var lastNs = 0L
        while (true) {
            withFrameNanos { nowNs ->
                if (lastNs == 0L) lastNs = nowNs
                val dt = ((nowNs - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastNs = nowNs

                val targetDegPerSec = if (isPlaying) 140f * playbackSpeed else 0f
                val damping = if (isPlaying) 4.2f else 1.8f // Gradual stopping coast
                currentDegPerSec += (targetDegPerSec - currentDegPerSec) * (dt * damping).coerceIn(0f, 1f)
                platterAngle = (platterAngle + currentDegPerSec * dt) % 360f
            }
            if (!isPlaying && currentDegPerSec < 0.4f) {
                kotlinx.coroutines.delay(150L)
            }
        }
    }

    val tonearmAngle by animateFloatAsState(
        targetValue = if (isPlaying) 24f else 0f,
        animationSpec = tween(durationMillis = 550),
        label = "tonearmAngle"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f),
        contentAlignment = Alignment.Center
    ) {
        // Spinning Vinyl Platter + Grooves
        Canvas(
            modifier = Modifier
                .fillMaxSize(0.88f)
                .graphicsLayer { rotationZ = platterAngle }
        ) {
            val r = size.minDimension / 2f
            val center = Offset(size.width / 2f, size.height / 2f)

            // Outer metallic platter rim
            drawCircle(
                color = Color(0xFF1F1E28),
                radius = r,
                center = center
            )

            // Vinyl disc body
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF15151C), Color(0xFF0A0A0E), Color(0xFF181822)),
                    center = center,
                    radius = r * 0.96f
                ),
                radius = r * 0.96f,
                center = center
            )

            // Realistic vinyl sheen reflections
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = 0.09f),
                        Color.Transparent,
                        Color.White.copy(alpha = 0.07f),
                        Color.Transparent
                    )
                ),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = true,
                topLeft = Offset(center.x - r * 0.94f, center.y - r * 0.94f),
                size = Size(r * 1.88f, r * 1.88f)
            )

            // Concentric micro-grooves
            val grooveSteps = 22
            for (g in 1..grooveSteps) {
                val frac = 0.44f + (g / grooveSteps.toFloat()) * 0.49f
                drawCircle(
                    color = Color.White.copy(alpha = if (g % 4 == 0) 0.08f else 0.035f),
                    radius = r * frac,
                    center = center,
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            // Center label halo ring
            drawCircle(
                color = vybe.accentPrimary.copy(alpha = 0.7f),
                radius = r * 0.40f,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Center Album Artwork rotating synchronously with platter
        Box(
            modifier = Modifier
                .size(116.dp)
                .graphicsLayer { rotationZ = platterAngle }
                .clip(CircleShape),
            contentAlignment = Alignment.Center
        ) {
            VybeArtwork(
                model = artworkModel,
                contentDescription = "Vinyl Center Label Artwork",
                modifier = Modifier.fillMaxSize(),
                cornerRadius = 60.dp
            )
            // Spindle hole
            Canvas(modifier = Modifier.size(22.dp)) {
                drawCircle(color = Color(0xFF09090D), radius = size.minDimension / 2f)
                drawCircle(
                    color = Color(0xFFD4D4D8),
                    radius = size.minDimension / 2f,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }

        // Animated Tonearm Overlay (top-right pivot)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val pivot = Offset(size.width * 0.87f, size.height * 0.14f)
            // Base gimbal mount
            drawCircle(color = Color(0xFF2B2B36), radius = 22.dp.toPx(), center = pivot)
            drawCircle(
                color = vybe.accentSecondary.copy(alpha = 0.6f),
                radius = 22.dp.toPx(),
                center = pivot,
                style = Stroke(width = 1.5.dp.toPx())
            )
            drawCircle(color = Color(0xFF94A3B8), radius = 8.dp.toPx(), center = pivot)

            rotate(degrees = tonearmAngle, pivot = pivot) {
                val elbow = Offset(pivot.x - size.width * 0.06f, pivot.y + size.height * 0.36f)
                val headShell = Offset(elbow.x - size.width * 0.09f, elbow.y + size.height * 0.13f)

                // Counterweight
                drawLine(
                    color = Color(0xFFCBD5E1),
                    start = Offset(pivot.x + 8.dp.toPx(), pivot.y - 26.dp.toPx()),
                    end = pivot,
                    strokeWidth = 9.dp.toPx(),
                    cap = StrokeCap.Round
                )

                // Main tonearm tube
                drawLine(
                    color = Color(0xFFE2E8F0),
                    start = pivot,
                    end = elbow,
                    strokeWidth = 4.5.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = Color(0xFFE2E8F0),
                    start = elbow,
                    end = headShell,
                    strokeWidth = 4.5.dp.toPx(),
                    cap = StrokeCap.Round
                )

                // Cartridge / Headshell
                drawLine(
                    color = vybe.accentPrimary,
                    start = elbow,
                    end = headShell,
                    strokeWidth = 8.dp.toPx(),
                    cap = StrokeCap.Butt
                )
                drawCircle(
                    color = vybe.accentSecondary,
                    radius = 4.dp.toPx(),
                    center = headShell
                )
            }
        }
    }
}
