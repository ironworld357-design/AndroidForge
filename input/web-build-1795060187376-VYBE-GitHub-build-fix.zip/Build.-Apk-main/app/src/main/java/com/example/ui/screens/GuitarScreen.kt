package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.guitar.ChordCategory
import com.example.guitar.ChordLibraryData
import com.example.guitar.GuitarChord
import com.example.guitar.MetronomeState
import com.example.guitar.TimeSignature
import com.example.guitar.TunerState
import com.example.ui.PracticeToolsState
import com.example.ui.theme.LocalVybeStyle
import com.example.util.TimeFormatter
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GuitarScreen(
    tunerState: TunerState,
    metronomeState: MetronomeState,
    practiceTools: PracticeToolsState,
    onStartTuner: () -> Unit,
    onStopTuner: () -> Unit,
    onPlayReferenceTone: (Double) -> Unit,
    onToggleMetronome: () -> Unit,
    onSetMetronomeBpm: (Int) -> Unit,
    onTapTempo: () -> Unit,
    onSetTimeSignature: (TimeSignature) -> Unit,
    onSetMetronomeAccent: (Boolean) -> Unit,
    onPlayChordPreview: (GuitarChord) -> Unit,
    onTogglePracticeTimer: () -> Unit,
    onResetPracticeTimer: () -> Unit,
    onSetBpmTrainer: (Boolean, Int, Int) -> Unit,
    onSelectProgression: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Tuner", "Metronome", "Chords", "Practice")

    DisposableEffect(Unit) {
        onDispose { onStopTuner() }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text("Guitar Studio", style = MaterialTheme.typography.headlineMedium, color = vybe.textPrimary)
            Text("Chromatic Tuner • Metronome • Chords • Practice", style = MaterialTheme.typography.labelMedium, color = vybe.textMuted)
        }

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = vybe.surfaceCard,
            contentColor = vybe.accentSecondary
        ) {
            tabs.forEachIndexed { idx, label ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = {
                        selectedTab = idx
                        if (idx != 0 && tunerState.isListening) onStopTuner()
                    },
                    text = { Text(label, style = MaterialTheme.typography.labelLarge) },
                    modifier = Modifier.testTag("guitar_tab_${label.lowercase()}")
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (selectedTab) {
                0 -> TunerTabContent(
                    tunerState = tunerState,
                    onStartTuner = onStartTuner,
                    onStopTuner = onStopTuner,
                    onPlayReferenceTone = onPlayReferenceTone
                )
                1 -> MetronomeTabContent(
                    state = metronomeState,
                    onToggle = onToggleMetronome,
                    onSetBpm = onSetMetronomeBpm,
                    onTapTempo = onTapTempo,
                    onSetTimeSignature = onSetTimeSignature,
                    onSetAccent = onSetMetronomeAccent
                )
                2 -> ChordLibraryTabContent(onPlayChordPreview = onPlayChordPreview)
                3 -> PracticeToolsTabContent(
                    practiceTools = practiceTools,
                    metronomeState = metronomeState,
                    onToggleTimer = onTogglePracticeTimer,
                    onResetTimer = onResetPracticeTimer,
                    onSetBpmTrainer = onSetBpmTrainer,
                    onSelectProgression = onSelectProgression,
                    onPlayChordPreview = onPlayChordPreview
                )
            }
            Spacer(Modifier.height(110.dp))
        }
    }
}

@Composable
private fun TunerTabContent(
    tunerState: TunerState,
    onStartTuner: () -> Unit,
    onStopTuner: () -> Unit,
    onPlayReferenceTone: (Double) -> Unit
) {
    val vybe = LocalVybeStyle.current
    val context = LocalContext.current
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }
    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) onStartTuner()
    }

    var selectedPreset by remember { mutableStateOf(ChordLibraryData.tuningPresets.first()) }
    var selectedStringIdx by remember { mutableIntStateOf(0) }

    val needleOffset by animateFloatAsState(
        targetValue = (tunerState.centsOffset.toFloat() / 50f).coerceIn(-1f, 1f),
        animationSpec = tween(durationMillis = 90),
        label = "tunerNeedle"
    )

    // Tuning Presets
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(ChordLibraryData.tuningPresets, key = { it.id }) { preset ->
            FilterChip(
                selected = selectedPreset.id == preset.id,
                onClick = { selectedPreset = preset },
                label = { Text("${preset.name} (${preset.subtitle})") }
            )
        }
    }

    // Visual Tuning Gauge Card
    Surface(
        shape = RoundedCornerShape(vybe.cardRadius),
        color = vybe.surfaceCard,
        border = BorderStroke(
            width = 1.2.dp,
            color = if (tunerState.isInTune && tunerState.detectedHz > 0) Color(0xFF10B981) else vybe.cardBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val statusColor = when {
                tunerState.detectedHz <= 0.0 -> vybe.textMuted
                tunerState.isInTune -> Color(0xFF10B981)
                tunerState.centsOffset < 0 -> Color(0xFFF59E0B)
                else -> Color(0xFFEF4444)
            }

            val statusLabel = when {
                !tunerState.isListening -> "TAP START MIC TO TUNE"
                tunerState.detectedHz <= 0.0 -> "PLUCK ANY STRING..."
                tunerState.isInTune -> "IN TUNE"
                tunerState.centsOffset < 0 -> "FLAT (♭) • TUNE UP"
                else -> "SHARP (#) • TUNE DOWN"
            }

            Text(statusLabel, style = MaterialTheme.typography.labelLarge, color = statusColor)

            // Needle Gauge Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(155.dp)
            ) {
                val center = Offset(size.width / 2f, size.height * 0.88f)
                val r = minOf(size.width * 0.42f, size.height * 0.78f)

                drawArc(
                    color = vybe.textMuted.copy(alpha = 0.25f),
                    startAngle = 200f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(center.x - r, center.y - r),
                    size = Size(r * 2f, r * 2f),
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )

                // Center green sweet spot arc
                drawArc(
                    color = Color(0xFF10B981).copy(alpha = 0.8f),
                    startAngle = 264f,
                    sweepAngle = 12f,
                    useCenter = false,
                    topLeft = Offset(center.x - r, center.y - r),
                    size = Size(r * 2f, r * 2f),
                    style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
                )

                // Tick marks
                for (tick in -5..5) {
                    val deg = 270f + tick * 12f
                    val rad = deg * PI / 180.0
                    val inner = Offset(center.x + cos(rad).toFloat() * (r * 0.86f), center.y + sin(rad).toFloat() * (r * 0.86f))
                    val outer = Offset(center.x + cos(rad).toFloat() * r, center.y + sin(rad).toFloat() * r)
                    drawLine(
                        color = if (tick == 0) Color(0xFF10B981) else vybe.textMuted.copy(alpha = 0.45f),
                        start = inner,
                        end = outer,
                        strokeWidth = if (tick == 0) 3.dp.toPx() else 1.5.dp.toPx()
                    )
                }

                // Needle
                val needleDeg = 270f + needleOffset * 62f
                val needleRad = needleDeg * PI / 180.0
                val tip = Offset(
                    center.x + cos(needleRad).toFloat() * (r * 0.9f),
                    center.y + sin(needleRad).toFloat() * (r * 0.9f)
                )
                drawLine(
                    color = statusColor,
                    start = center,
                    end = tip,
                    strokeWidth = 3.5.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawCircle(color = vybe.accentSecondary, radius = 7.dp.toPx(), center = center)
            }

            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (tunerState.detectedHz > 0) "${tunerState.noteName}${tunerState.octave}" else "--",
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Bold,
                    color = statusColor
                )
                Column(modifier = Modifier.padding(bottom = 6.dp)) {
                    Text(
                        text = if (tunerState.detectedHz > 0) String.format("%.1f Hz", tunerState.detectedHz) else "0.0 Hz",
                        style = MaterialTheme.typography.titleMedium,
                        color = vybe.textPrimary
                    )
                    Text(
                        text = if (tunerState.detectedHz > 0) String.format("%+.1f cents", tunerState.centsOffset) else "A4 = 440 Hz",
                        style = MaterialTheme.typography.labelMedium,
                        color = vybe.textMuted
                    )
                }
            }

            if (tunerState.errorMessage != null) {
                Text(tunerState.errorMessage, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
            }

            Button(
                onClick = {
                    if (tunerState.isListening) {
                        onStopTuner()
                    } else if (hasMicPermission) {
                        onStartTuner()
                    } else {
                        micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (tunerState.isListening) MaterialTheme.colorScheme.error else vybe.accentPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tuner_mic_toggle_btn")
            ) {
                Icon(if (tunerState.isListening) Icons.Filled.MicOff else Icons.Filled.Mic, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (tunerState.isListening) "Stop Pitch Detection" else "Start Microphone Tuner")
            }
        }
    }

    // String Reference Tones
    Text("Tap String for Reference Pitch (${selectedPreset.name})", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        selectedPreset.strings.forEachIndexed { idx, ts ->
            val selected = selectedStringIdx == idx
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clickable {
                        selectedStringIdx = idx
                        onPlayReferenceTone(ts.targetHz)
                    },
                shape = RoundedCornerShape(12.dp),
                color = if (selected) vybe.accentPrimary.copy(alpha = 0.22f) else vybe.surfaceCard,
                border = BorderStroke(1.dp, if (selected) vybe.accentSecondary else vybe.cardBorder)
            ) {
                Column(
                    modifier = Modifier.padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(ts.noteLabel, style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                    Text("${ts.targetHz.toInt()}Hz", style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                    Icon(Icons.Filled.VolumeUp, contentDescription = "Play ${ts.noteLabel}", tint = vybe.accentSecondary, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
private fun MetronomeTabContent(
    state: MetronomeState,
    onToggle: () -> Unit,
    onSetBpm: (Int) -> Unit,
    onTapTempo: () -> Unit,
    onSetTimeSignature: (TimeSignature) -> Unit,
    onSetAccent: (Boolean) -> Unit
) {
    val vybe = LocalVybeStyle.current

    Surface(
        shape = RoundedCornerShape(vybe.cardRadius),
        color = vybe.surfaceCard,
        border = BorderStroke(1.dp, vybe.cardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Visual Beat Indicators
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (b in 1..state.timeSignature.beatsPerBar) {
                    val active = state.isRunning && state.currentBeat == b
                    val isAccent = state.accentFirstBeat && b == 1
                    Box(
                        modifier = Modifier
                            .size(if (active) 24.dp else 18.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    active && isAccent -> vybe.accentSecondary
                                    active -> vybe.accentPrimary
                                    else -> vybe.surfaceElevated
                                }
                            )
                    )
                }
            }

            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "${state.bpm}",
                    fontSize = 54.sp,
                    fontWeight = FontWeight.Bold,
                    color = vybe.accentSecondary
                )
                Text("BPM", style = MaterialTheme.typography.titleMedium, color = vybe.textMuted, modifier = Modifier.padding(bottom = 10.dp))
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = { onSetBpm(state.bpm - 5) }) { Text("-5") }
                IconButton(onClick = { onSetBpm(state.bpm - 1) }) { Icon(Icons.Filled.Remove, contentDescription = "-1 BPM") }
                IconButton(onClick = { onSetBpm(state.bpm + 1) }) { Icon(Icons.Filled.Add, contentDescription = "+1 BPM") }
                OutlinedButton(onClick = { onSetBpm(state.bpm + 5) }) { Text("+5") }
            }

            Slider(
                value = state.bpm.toFloat(),
                onValueChange = { onSetBpm(it.toInt()) },
                valueRange = 30f..260f
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onTapTempo,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("metronome_tap_tempo_btn")
                ) {
                    Icon(Icons.Filled.TouchApp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Tap Tempo")
                }

                Button(
                    onClick = onToggle,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("metronome_start_stop_btn")
                ) {
                    Icon(if (state.isRunning) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (state.isRunning) "Stop" else "Start")
                }
            }
        }
    }

    // Time Signatures & Beat Accent
    Surface(
        shape = RoundedCornerShape(vybe.cardRadius),
        color = vybe.surfaceCard,
        border = BorderStroke(0.8.dp, vybe.cardBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Time Signature", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(TimeSignature.entries) { sig ->
                    FilterChip(
                        selected = state.timeSignature == sig,
                        onClick = { onSetTimeSignature(sig) },
                        label = { Text(sig.label) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Accent Beat 1 (Downbeat)", style = MaterialTheme.typography.bodyLarge, color = vybe.textPrimary)
                Switch(checked = state.accentFirstBeat, onCheckedChange = onSetAccent)
            }
        }
    }
}

@Composable
private fun ChordLibraryTabContent(
    onPlayChordPreview: (GuitarChord) -> Unit
) {
    val vybe = LocalVybeStyle.current
    var selectedCategory by remember { mutableStateOf(ChordCategory.ALL) }
    val filtered = remember(selectedCategory) {
        when (selectedCategory) {
            ChordCategory.ALL -> ChordLibraryData.chords
            ChordCategory.OPEN -> ChordLibraryData.chords.filter { !it.isBarre }
            ChordCategory.BARRE -> ChordLibraryData.chords.filter { it.isBarre }
            else -> ChordLibraryData.chords.filter { it.category == selectedCategory }
        }
    }
    var selectedChord by remember(filtered) { mutableStateOf(filtered.first()) }

    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(ChordCategory.entries) { cat ->
            FilterChip(
                selected = selectedCategory == cat,
                onClick = { selectedCategory = cat },
                label = { Text(cat.displayName) }
            )
        }
    }

    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(filtered, key = { it.id }) { chord ->
            val active = selectedChord.id == chord.id
            Surface(
                modifier = Modifier.clickable { selectedChord = chord },
                shape = RoundedCornerShape(12.dp),
                color = if (active) vybe.accentPrimary.copy(alpha = 0.24f) else vybe.surfaceCard,
                border = BorderStroke(1.dp, if (active) vybe.accentSecondary else vybe.cardBorder)
            ) {
                Text(
                    text = chord.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (active) vybe.accentSecondary else vybe.textPrimary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                )
            }
        }
    }

    // Interactive Fretboard Diagram Card
    Surface(
        shape = RoundedCornerShape(vybe.cardRadius),
        color = vybe.surfaceCard,
        border = BorderStroke(1.dp, vybe.cardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(selectedChord.fullName, style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
                    Text(
                        text = if (selectedChord.startingFret > 1) "Base Fret ${selectedChord.startingFret}" else "Open Position",
                        style = MaterialTheme.typography.labelMedium,
                        color = vybe.accentSecondary
                    )
                }
                Button(
                    onClick = { onPlayChordPreview(selectedChord) },
                    modifier = Modifier.testTag("play_chord_btn")
                ) {
                    Icon(Icons.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Strum")
                }
            }

            ChordDiagramCanvas(
                chord = selectedChord,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
            )

            // String-by-String Breakdown
            val stringNames = listOf("6 (E)", "5 (A)", "4 (D)", "3 (G)", "2 (B)", "1 (e)")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                selectedChord.frets.forEachIndexed { idx, fret ->
                    val finger = selectedChord.fingers[idx]
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = vybe.surfaceElevated,
                        modifier = Modifier.weight(1f).padding(horizontal = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(stringNames[idx].substringBefore(" "), style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
                            Text(
                                text = when {
                                    fret < 0 -> "X"
                                    fret == 0 -> "O"
                                    else -> "F$fret"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = if (fret < 0) MaterialTheme.colorScheme.error else vybe.accentSecondary
                            )
                            Text(selectedChord.stringNotes[idx], style = MaterialTheme.typography.labelSmall, color = vybe.textPrimary)
                            Text(if (finger > 0) "Fg $finger" else "-", style = MaterialTheme.typography.labelSmall, color = vybe.textMuted, fontSize = 9.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChordDiagramCanvas(chord: GuitarChord, modifier: Modifier = Modifier) {
    val vybe = LocalVybeStyle.current
    Canvas(modifier = modifier) {
        val leftPad = size.width * 0.14f
        val rightPad = size.width * 0.14f
        val topPad = size.height * 0.14f
        val bottomPad = size.height * 0.08f

        val boardW = size.width - leftPad - rightPad
        val boardH = size.height - topPad - bottomPad
        val stringStep = boardW / 5f
        val fretCount = 5
        val fretStep = boardH / fretCount

        // Nut (thick if startingFret == 1)
        drawLine(
            color = vybe.textPrimary,
            start = Offset(leftPad, topPad),
            end = Offset(leftPad + boardW, topPad),
            strokeWidth = if (chord.startingFret == 1) 6.dp.toPx() else 2.dp.toPx()
        )

        // Frets
        for (f in 1..fretCount) {
            val y = topPad + f * fretStep
            drawLine(
                color = vybe.textMuted.copy(alpha = 0.4f),
                start = Offset(leftPad, y),
                end = Offset(leftPad + boardW, y),
                strokeWidth = 1.5.dp.toPx()
            )
        }

        // Strings (thickest on left -> thinnest on right)
        for (s in 0 until 6) {
            val x = leftPad + s * stringStep
            drawLine(
                color = vybe.textMuted.copy(alpha = 0.65f),
                start = Offset(x, topPad),
                end = Offset(x, topPad + boardH),
                strokeWidth = (2.8f - s * 0.25f).dp.toPx()
            )
        }

        // Barre bar if present
        chord.barreFret?.let { bf ->
            val relFret = bf - chord.startingFret + 1
            if (relFret in 1..fretCount) {
                val firstStr = chord.frets.indexOfFirst { it >= bf }.coerceAtLeast(0)
                val lastStr = chord.frets.indexOfLast { it >= bf }.coerceAtLeast(firstStr)
                val y = topPad + (relFret - 0.5f) * fretStep
                val x1 = leftPad + firstStr * stringStep
                val x2 = leftPad + lastStr * stringStep
                drawRoundRect(
                    color = vybe.accentPrimary.copy(alpha = 0.85f),
                    topLeft = Offset(x1 - 10.dp.toPx(), y - 10.dp.toPx()),
                    size = Size((x2 - x1) + 20.dp.toPx(), 20.dp.toPx()),
                    cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                )
            }
        }

        // Open / Muted indicators & Finger dots
        chord.frets.forEachIndexed { s, fret ->
            val x = leftPad + s * stringStep
            if (fret == 0) {
                drawCircle(
                    color = vybe.accentSecondary,
                    radius = 7.dp.toPx(),
                    center = Offset(x, topPad - 16.dp.toPx()),
                    style = Stroke(width = 2.dp.toPx())
                )
            } else if (fret < 0) {
                val cy = topPad - 16.dp.toPx()
                val d = 6.dp.toPx()
                drawLine(Color(0xFFEF4444), Offset(x - d, cy - d), Offset(x + d, cy + d), strokeWidth = 2.2.dp.toPx())
                drawLine(Color(0xFFEF4444), Offset(x - d, cy + d), Offset(x + d, cy - d), strokeWidth = 2.2.dp.toPx())
            } else {
                val relFret = fret - chord.startingFret + 1
                if (relFret in 1..fretCount) {
                    val y = topPad + (relFret - 0.5f) * fretStep
                    drawCircle(color = vybe.accentSecondary, radius = 11.dp.toPx(), center = Offset(x, y))
                    drawCircle(color = Color.White, radius = 4.dp.toPx(), center = Offset(x, y))
                }
            }
        }
    }
}

@Composable
private fun PracticeToolsTabContent(
    practiceTools: PracticeToolsState,
    metronomeState: MetronomeState,
    onToggleTimer: () -> Unit,
    onResetTimer: () -> Unit,
    onSetBpmTrainer: (Boolean, Int, Int) -> Unit,
    onSelectProgression: (String) -> Unit,
    onPlayChordPreview: (GuitarChord) -> Unit
) {
    val vybe = LocalVybeStyle.current

    // Practice Session Timer
    Surface(
        shape = RoundedCornerShape(vybe.cardRadius),
        color = vybe.surfaceCard,
        border = BorderStroke(0.8.dp, vybe.cardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Filled.Timer, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(28.dp))
                Column {
                    Text("Practice Timer", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                    Text(
                        TimeFormatter.formatDuration(practiceTools.timerElapsedSec * 1000L),
                        style = MaterialTheme.typography.headlineSmall,
                        color = vybe.accentSecondary
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onToggleTimer) {
                    Text(if (practiceTools.timerRunning) "Pause" else "Start")
                }
                IconButton(onClick = onResetTimer) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Reset timer")
                }
            }
        }
    }

    // BPM Ramp Trainer
    Surface(
        shape = RoundedCornerShape(vybe.cardRadius),
        color = vybe.surfaceCard,
        border = BorderStroke(0.8.dp, vybe.cardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("BPM Ramp Trainer", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                    Text(
                        "Gradually steps +5 BPM every ${practiceTools.bpmTrainerStepBars} bars (${practiceTools.bpmTrainerStart} → ${practiceTools.bpmTrainerTarget} BPM)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = vybe.textMuted
                    )
                }
                Switch(
                    checked = practiceTools.bpmTrainerActive,
                    onCheckedChange = { onSetBpmTrainer(it, practiceTools.bpmTrainerStart, practiceTools.bpmTrainerTarget) }
                )
            }
            Text("Current Metronome: ${metronomeState.bpm} BPM • Bar ${metronomeState.completedBars + 1}", style = MaterialTheme.typography.labelMedium, color = vybe.accentSecondary)
        }
    }

    // Chord Progression Practice
    val activeProg = ChordLibraryData.progressions.firstOrNull { it.id == practiceTools.selectedProgressionId }
        ?: ChordLibraryData.progressions.first()

    Surface(
        shape = RoundedCornerShape(vybe.cardRadius),
        color = vybe.surfaceCard,
        border = BorderStroke(0.8.dp, vybe.cardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Chord Progression Trainer", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ChordLibraryData.progressions, key = { it.id }) { prog ->
                    FilterChip(
                        selected = prog.id == activeProg.id,
                        onClick = { onSelectProgression(prog.id) },
                        label = { Text(prog.title) }
                    )
                }
            }
            Text("${activeProg.style} • ${activeProg.recommendedBpm} BPM", style = MaterialTheme.typography.labelMedium, color = vybe.textMuted)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                activeProg.chordIds.forEachIndexed { idx, chordId ->
                    val isActive = idx == practiceTools.activeProgressionIndex
                    val chordObj = ChordLibraryData.chords.firstOrNull { it.id == chordId }
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { chordObj?.let(onPlayChordPreview) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isActive) vybe.accentPrimary.copy(alpha = 0.25f) else vybe.surfaceElevated,
                        border = BorderStroke(1.2.dp, if (isActive) vybe.accentSecondary else vybe.cardBorder)
                    ) {
                        Box(modifier = Modifier.padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                            Text(chordId, style = MaterialTheme.typography.titleLarge, color = if (isActive) vybe.accentSecondary else vybe.textPrimary)
                        }
                    }
                }
            }
        }
    }

    // Beginner Guitar Exercises
    Text("Guided Practice Exercises", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
    ChordLibraryData.exercises.forEach { ex ->
        Surface(
            shape = RoundedCornerShape(vybe.cardRadius),
            color = vybe.surfaceCard,
            border = BorderStroke(0.8.dp, vybe.cardBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(ex.title, style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                    Text("${ex.level} • ${ex.targetBpm} BPM", style = MaterialTheme.typography.labelSmall, color = vybe.accentSecondary)
                }
                Text(ex.description, style = MaterialTheme.typography.bodyMedium, color = vybe.textMuted)
                ex.patternSteps.forEachIndexed { i, step ->
                    Text("${i + 1}. $step", style = MaterialTheme.typography.bodyMedium, color = vybe.textPrimary)
                }
            }
        }
    }
}
