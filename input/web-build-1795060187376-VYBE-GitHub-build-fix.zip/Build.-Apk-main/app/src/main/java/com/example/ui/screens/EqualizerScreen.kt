package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioEffectsCapabilities
import com.example.audio.VybeDspAudioProcessor
import com.example.data.local.VybeSettings
import com.example.model.DisplayRefreshInfo
import com.example.model.EqPreset
import com.example.model.HeadphoneProfile
import com.example.model.VisualizerSize
import com.example.model.VisualizerStyle
import com.example.ui.components.VybeVisualizerCanvas
import com.example.ui.theme.LocalVybeStyle
import com.example.util.rememberVybeHaptics
import kotlin.math.roundToInt

@Composable
fun EqualizerScreen(
    settings: VybeSettings,
    capabilities: AudioEffectsCapabilities,
    dspProcessor: VybeDspAudioProcessor,
    isPlaying: Boolean,
    displayRefreshInfo: DisplayRefreshInfo,
    builtInPresets: List<EqPreset>,
    customPresets: List<EqPreset>,
    bandLabels: List<String>,
    isClipping: Boolean,
    onBack: () -> Unit,
    onToggleEq: (Boolean) -> Unit,
    onUpdateBand: (Int, Float) -> Unit,
    onApplyPreset: (EqPreset) -> Unit,
    onResetFlat: () -> Unit,
    onSaveCustomPreset: (String) -> Unit,
    onDeleteCustomPreset: (String) -> Unit,
    onSelectVisualizerStyle: (VisualizerStyle) -> Unit,
    onSetBassBoost: (Int) -> Unit,
    onSetVirtualizer: (Int) -> Unit,
    onSetLoudness: (Int) -> Unit,
    onSetPreamp: (Float) -> Unit,
    onSetBalance: (Float) -> Unit,
    onSetNormalization: (Boolean) -> Unit,
    onApplyHeadphoneProfile: (HeadphoneProfile) -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val haptics = rememberVybeHaptics(settings.hapticFeedbackEnabled)
    var showSaveDialog by remember { mutableStateOf(false) }
    var useVerticalFaders by remember { mutableStateOf(true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("eq_back_btn")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = vybe.textPrimary)
                }
                Column {
                    Text("10-Band EQ & Visualizer", style = MaterialTheme.typography.titleLarge, color = vybe.textPrimary)
                    val srLabel = String.format("%.1f kHz", dspProcessor.activeSampleRateHz / 1000f)
                    Text(
                        text = if (settings.eqEnabled) {
                            "Media3 10-Band Biquad DSP • $srLabel"
                        } else {
                            "Equalizer Bypassed • Visualizer Active"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (settings.eqEnabled) vybe.accentSecondary else vybe.textMuted
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isClipping) {
                    Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.error) {
                        Text("CLIP", style = MaterialTheme.typography.labelSmall, color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                Switch(
                    checked = settings.eqEnabled,
                    onCheckedChange = {
                        haptics.toggle()
                        onToggleEq(it)
                    },
                    modifier = Modifier.testTag("eq_master_switch")
                )
            }
        }

        // Live Post-EQ Audio Visualizer + Parametric Curve Card
        Surface(
            shape = RoundedCornerShape(vybe.cardRadius),
            color = vybe.surfaceCard,
            border = BorderStroke(1.dp, vybe.cardBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(18.dp))
                        Text(
                            text = if (isPlaying) "LIVE POST-EQ SPECTRUM" else "EQ RESPONSE & VISUALIZER",
                            style = MaterialTheme.typography.labelMedium,
                            color = vybe.textPrimary
                        )
                    }
                    Text(
                        text = settings.visualizerStyle.displayName,
                        style = MaterialTheme.typography.labelSmall,
                        color = vybe.accentSecondary
                    )
                }

                // Live Audio Visualizer layered cleanly with the smooth 10-band EQ spline curve
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(vybe.bgDeep.copy(alpha = 0.65f))
                        .padding(8.dp)
                ) {
                    VybeVisualizerCanvas(
                        dspProcessor = dspProcessor,
                        isPlaying = isPlaying,
                        style = settings.visualizerStyle,
                        intensity = settings.visualizerIntensity,
                        sizePreset = VisualizerSize.MEDIUM,
                        customColorHex = settings.visualizerCustomColorHex,
                        performanceMode = settings.performanceMode,
                        displayRefreshInfo = displayRefreshInfo,
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("eq_live_visualizer")
                    )

                    // Parametric EQ frequency curve overlay
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val midY = h / 2f
                        drawLine(
                            color = vybe.textMuted.copy(alpha = 0.22f),
                            start = Offset(0f, midY),
                            end = Offset(w, midY),
                            strokeWidth = 1.dp.toPx()
                        )
                        val path = Path()
                        val bands = settings.eqBandsDb
                        val stepX = w / (bands.size - 1).coerceAtLeast(1)
                        bands.forEachIndexed { idx, db ->
                            val x = idx * stepX
                            val norm = (db / 12f).coerceIn(-1f, 1f)
                            val y = midY - norm * (h * 0.42f)
                            if (idx == 0) path.moveTo(x, y) else {
                                val prevX = (idx - 1) * stepX
                                val prevDb = bands[idx - 1]
                                val prevY = midY - (prevDb / 12f).coerceIn(-1f, 1f) * (h * 0.42f)
                                val cx = (prevX + x) / 2f
                                path.cubicTo(cx, prevY, cx, y, x, y)
                            }
                        }
                        drawPath(
                            path = path,
                            brush = Brush.horizontalGradient(
                                listOf(
                                    vybe.accentPrimary.copy(alpha = if (settings.eqEnabled) 0.95f else 0.4f),
                                    vybe.accentSecondary.copy(alpha = if (settings.eqEnabled) 0.95f else 0.4f)
                                )
                            ),
                            style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round)
                        )
                        bands.forEachIndexed { idx, db ->
                            val x = idx * stepX
                            val y = midY - (db / 12f).coerceIn(-1f, 1f) * (h * 0.42f)
                            drawCircle(
                                color = if (settings.eqEnabled) vybe.accentSecondary else vybe.textMuted,
                                radius = 3.5.dp.toPx(),
                                center = Offset(x, y)
                            )
                        }
                    }
                }

                // Quick Visualizer Style Chips directly inside EQ screen
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(VisualizerStyle.entries) { style ->
                        val selected = settings.visualizerStyle == style
                        Surface(
                            modifier = Modifier
                                .clickable { onSelectVisualizerStyle(style) }
                                .testTag("eq_vis_style_${style.name.lowercase()}"),
                            shape = RoundedCornerShape(50),
                            color = if (selected) vybe.accentPrimary.copy(alpha = 0.24f) else vybe.surfaceElevated,
                            border = BorderStroke(0.8.dp, if (selected) vybe.accentSecondary else vybe.cardBorder)
                        ) {
                            Text(
                                text = style.displayName,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) vybe.accentSecondary else vybe.textMuted,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Presets Row (10 Built-in + Custom)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Presets", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        haptics.toggle()
                        onResetFlat()
                    },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("eq_reset_flat_btn")
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("0 dB Flat", style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(
                    onClick = { showSaveDialog = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Save", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(builtInPresets, key = { it.id }) { preset ->
                FilterChip(
                    selected = settings.eqPresetId == preset.id,
                    onClick = {
                        haptics.toggle()
                        onApplyPreset(preset)
                    },
                    label = { Text(preset.name) },
                    modifier = Modifier.testTag("eq_preset_${preset.id}")
                )
            }
            items(customPresets, key = { it.id }) { preset ->
                FilterChip(
                    selected = settings.eqPresetId == preset.id,
                    onClick = {
                        haptics.toggle()
                        onApplyPreset(preset)
                    },
                    label = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(preset.name)
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                Icons.Filled.Delete,
                                contentDescription = "Delete preset",
                                modifier = Modifier
                                    .size(14.dp)
                                    .clickable { onDeleteCustomPreset(preset.id) }
                            )
                        }
                    }
                )
            }
        }

        // 10-Band Equalizer Controls (Vertical Studio Rack + Fine Precision Sliders)
        Surface(
            shape = RoundedCornerShape(vybe.cardRadius),
            color = vybe.surfaceCard,
            border = BorderStroke(0.8.dp, vybe.cardBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "10-Band Frequency Rack",
                        style = MaterialTheme.typography.titleMedium,
                        color = vybe.textPrimary
                    )
                    Surface(
                        modifier = Modifier
                            .clickable { useVerticalFaders = !useVerticalFaders }
                            .testTag("eq_toggle_layout_btn"),
                        shape = RoundedCornerShape(50),
                        color = vybe.surfaceElevated,
                        border = BorderStroke(0.8.dp, vybe.cardBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Filled.Tune, contentDescription = null, tint = vybe.accentSecondary, modifier = Modifier.size(14.dp))
                            Text(
                                text = if (useVerticalFaders) "Fine Sliders" else "Studio Faders",
                                style = MaterialTheme.typography.labelSmall,
                                color = vybe.accentSecondary
                            )
                        }
                    }
                }

                if (useVerticalFaders) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        settings.eqBandsDb.forEachIndexed { idx, db ->
                            VerticalEqBandFader(
                                label = bandLabels[idx],
                                gainDb = db,
                                enabled = settings.eqEnabled,
                                onChange = { newDb ->
                                    if (newDb != db) {
                                        haptics.tick()
                                        onUpdateBand(idx, newDb)
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("eq_band_slider_$idx")
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        settings.eqBandsDb.forEachIndexed { idx, db ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "${bandLabels[idx]}Hz",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = vybe.textMuted,
                                    modifier = Modifier.width(52.dp)
                                )
                                Slider(
                                    value = db,
                                    onValueChange = {
                                        haptics.tick()
                                        onUpdateBand(idx, it)
                                    },
                                    valueRange = -12f..12f,
                                    enabled = settings.eqEnabled,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("eq_band_slider_$idx")
                                )
                                Text(
                                    text = String.format("%+.1f", db),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = vybe.accentSecondary,
                                    modifier = Modifier.width(46.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Spatial, Bass, Loudness, Preamp, Stereo Balance & Normalization
        Surface(
            shape = RoundedCornerShape(vybe.cardRadius),
            color = vybe.surfaceCard,
            border = BorderStroke(0.8.dp, vybe.cardBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Audiophile DSP & Hardware Effects", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)

                EqSliderRow(
                    label = "Bass Boost (${settings.bassBoostStrength / 10}%)",
                    value = settings.bassBoostStrength.toFloat(),
                    range = 0f..1000f,
                    enabled = settings.eqEnabled,
                    subtitle = if (!capabilities.bassBoostSupported && capabilities.isAttached) "Hardware BassBoost unavailable on device" else null,
                    onValueChange = { onSetBassBoost(it.toInt()) }
                )

                EqSliderRow(
                    label = "3D Virtualizer (${settings.virtualizerStrength / 10}%)",
                    value = settings.virtualizerStrength.toFloat(),
                    range = 0f..1000f,
                    enabled = settings.eqEnabled,
                    subtitle = if (!capabilities.virtualizerSupported && capabilities.isAttached) "Hardware Virtualizer unavailable on device" else null,
                    onValueChange = { onSetVirtualizer(it.toInt()) }
                )

                EqSliderRow(
                    label = "Loudness Enhancer (+${settings.loudnessGainMb / 100} dB)",
                    value = settings.loudnessGainMb.toFloat(),
                    range = 0f..1500f,
                    enabled = settings.eqEnabled,
                    onValueChange = { onSetLoudness(it.toInt()) }
                )

                EqSliderRow(
                    label = "Preamp Gain (${String.format("%+.1f dB", settings.preampDb)})",
                    value = settings.preampDb,
                    range = -12f..12f,
                    enabled = true,
                    onValueChange = onSetPreamp
                )

                EqSliderRow(
                    label = when {
                        settings.channelBalance < -0.05f -> "L/R Balance (${((-settings.channelBalance) * 100).toInt()}% Left)"
                        settings.channelBalance > 0.05f -> "L/R Balance (${(settings.channelBalance * 100).toInt()}% Right)"
                        else -> "L/R Balance (Center)"
                    },
                    value = settings.channelBalance,
                    range = -1f..1f,
                    enabled = true,
                    onValueChange = onSetBalance
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Volume Normalization", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                        Text("Smooth RMS leveling with soft clipping limiter", style = MaterialTheme.typography.bodyMedium, color = vybe.textMuted)
                    }
                    Switch(checked = settings.volumeNormalization, onCheckedChange = {
                        haptics.toggle()
                        onSetNormalization(it)
                    })
                }
            }
        }

        // Headphone-Specific Audio Profiles
        Surface(
            shape = RoundedCornerShape(vybe.cardRadius),
            color = vybe.surfaceCard,
            border = BorderStroke(0.8.dp, vybe.cardBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Headphones, contentDescription = null, tint = vybe.accentSecondary)
                    Text("Headphone Audio Profiles", style = MaterialTheme.typography.titleMedium, color = vybe.textPrimary)
                }
                HeadphoneProfile.entries.forEach { profile ->
                    val active = settings.headphoneProfile == profile
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                haptics.toggle()
                                onApplyHeadphoneProfile(profile)
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = if (active) vybe.accentPrimary.copy(alpha = 0.2f) else vybe.surfaceElevated,
                        border = BorderStroke(1.dp, if (active) vybe.accentSecondary else vybe.cardBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(profile.displayName, style = MaterialTheme.typography.titleMedium, color = if (active) vybe.accentSecondary else vybe.textPrimary)
                            Text(profile.description, style = MaterialTheme.typography.bodyMedium, color = vybe.textMuted)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(32.dp))
    }

    if (showSaveDialog) {
        var presetName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Custom EQ Preset") },
            text = {
                OutlinedTextField(
                    value = presetName,
                    onValueChange = { presetName = it },
                    label = { Text("Preset Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (presetName.isNotBlank()) {
                        onSaveCustomPreset(presetName)
                        showSaveDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun VerticalEqBandFader(
    label: String,
    gainDb: Float,
    enabled: Boolean,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val vybe = LocalVybeStyle.current
    val snappedDb = (gainDb * 2f).roundToInt() / 2f

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = if (snappedDb == 0f) "0" else String.format("%+.0f", snappedDb),
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (enabled) vybe.accentSecondary else vybe.textMuted,
            textAlign = TextAlign.Center,
            maxLines = 1
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(172.dp)
                .pointerInput(enabled) {
                    if (!enabled) return@pointerInput
                    detectTapGestures { offset ->
                        val frac = (1f - (offset.y / size.height.toFloat())).coerceIn(0f, 1f)
                        val db = -12f + frac * 24f
                        onChange((db * 2f).roundToInt() / 2f)
                    }
                }
                .pointerInput(enabled) {
                    if (!enabled) return@pointerInput
                    detectVerticalDragGestures { change, _ ->
                        change.consume()
                        val frac = (1f - (change.position.y / size.height.toFloat())).coerceIn(0f, 1f)
                        val db = -12f + frac * 24f
                        onChange((db * 2f).roundToInt() / 2f)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val trackW = 5.dp.toPx()
                val padY = 10.dp.toPx()
                val usableH = (size.height - padY * 2).coerceAtLeast(1f)
                val midY = padY + usableH / 2f

                // Track background
                drawRoundRect(
                    color = vybe.surfaceElevated,
                    topLeft = Offset(cx - trackW / 2f, padY),
                    size = Size(trackW, usableH),
                    cornerRadius = CornerRadius(trackW / 2f, trackW / 2f)
                )

                // Center 0 dB tick
                drawLine(
                    color = vybe.textMuted.copy(alpha = 0.35f),
                    start = Offset(cx - 8.dp.toPx(), midY),
                    end = Offset(cx + 8.dp.toPx(), midY),
                    strokeWidth = 1.dp.toPx()
                )

                val norm = ((gainDb + 12f) / 24f).coerceIn(0f, 1f)
                val thumbY = padY + usableH * (1f - norm)

                // Active fill from 0dB datum line to thumb
                val topY = minOf(midY, thumbY)
                val fillH = kotlin.math.abs(thumbY - midY)
                if (fillH > 1f) {
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(
                                if (enabled) vybe.accentSecondary else vybe.textMuted,
                                if (enabled) vybe.accentPrimary else vybe.textMuted
                            )
                        ),
                        topLeft = Offset(cx - trackW / 2f, topY),
                        size = Size(trackW, fillH),
                        cornerRadius = CornerRadius(trackW / 2f, trackW / 2f)
                    )
                }

                // Glowing thumb cap
                if (enabled) {
                    drawCircle(
                        color = vybe.accentSecondary.copy(alpha = 0.30f),
                        radius = 10.dp.toPx(),
                        center = Offset(cx, thumbY)
                    )
                }
                drawCircle(
                    color = if (enabled) Color.White else vybe.textMuted,
                    radius = 5.5.dp.toPx(),
                    center = Offset(cx, thumbY)
                )
                drawCircle(
                    color = if (enabled) vybe.accentPrimary else vybe.surfaceCard,
                    radius = 2.5.dp.toPx(),
                    center = Offset(cx, thumbY)
                )
            }
        }

        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.sp,
            color = vybe.textMuted,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

@Composable
private fun EqSliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    enabled: Boolean,
    subtitle: String? = null,
    onValueChange: (Float) -> Unit
) {
    val vybe = LocalVybeStyle.current
    Column {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = vybe.textPrimary)
        if (subtitle != null) {
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = vybe.textMuted)
        }
        Slider(value = value, onValueChange = onValueChange, valueRange = range, enabled = enabled)
    }
}
