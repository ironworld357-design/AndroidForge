// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
  alias(libs.plugins.android.application) apply false
  alias(libs.plugins.kotlin.compose) apply false
  alias(libs.plugins.kotlin.serialization) apply false
  alias(libs.plugins.google.devtools.ksp) apply false
  alias(libs.plugins.secrets) apply false
  alias(libs.plugins.google.services) apply false
}

// Automatically reconstruct debug.keystore from debug.keystore.base64 on fresh GitHub clones/downloads
// so debug builds work immediately without manual keystore setup.
run {
  val debugKeystore = java.io.File(rootDir, "debug.keystore")
  val debugKeystoreBase64 = java.io.File(rootDir, "debug.keystore.base64")
  if (!debugKeystore.exists() && debugKeystoreBase64.exists()) {
    val encoded = debugKeystoreBase64.readText().trim()
    if (encoded.isNotEmpty()) {
      debugKeystore.writeBytes(java.util.Base64.getMimeDecoder().decode(encoded))
    }
  }
}
