# VYBE — Dual-Theme Offline Music Player

**Feel Every Beat.** Native Android music player built with **Kotlin**, **Jetpack Compose**, **Material Design 3**, **Room**, and **Media3 / ExoPlayer**.

## Features

- **Dual & Addon Visual Themes**: Switch seamlessly between **Modern Pro**, **Retro Cassette**, **Aurora Glass**, **Liquid Smoke**, and **Halo Orchid** without interrupting playback.
- **Offline Audio Engine (Media3 + Foreground Service)**: Gapless playback, crossfade, A-B looping, variable playback speed, lock-screen & notification media controls, and offline MediaStore scanning (`.mp3`, `.wav`, `.flac`, `.aac`, `.m4a`, `.ogg`, `.opus`).
- **Real-Time 10-Band Equalizer & Visualizers**: Custom 64-bit cascaded biquad DSP (`31 Hz – 16 kHz`), preamp, stereo balance, loudness normalization, headphone profiles, and live post-EQ audio visualizers.
- **Synchronized Lyrics**: Reads `.lrc` sidecar files and embedded audio metadata tags (`ID3 SYLT/USLT`, `FLAC/OGG Vorbis`, `M4A ©lyr`), centering and highlighting lines in real time with tap-to-seek and offset fine-tuning.
- **Vinyl Turntable & Animations**: Physics-driven spinning vinyl record animations across Now Playing, Mini Player, and Floating Dock.
- **Guitar Practice Studio**: Chromatic pitch tuner, metronome, chord library, and practice timer.

## Getting Started (From GitHub)

### Prerequisites
- **Android Studio** (Meerkat / Narwhal or newer) or CLI with **JDK 21**
- **Android SDK 36** (`compileSdk = 36`, `minSdk = 24`, `targetSdk = 36`)

### Clone & Build

```bash
git clone <your-repo-url>
cd VYBE
./gradlew assembleDebug
```

On Windows:
```powershell
gradlew.bat assembleDebug
```

Run unit & Robolectric tests:
```bash
./gradlew testDebugUnitTest
```

### Configuration Notes
- **Debug Signing**: `debug.keystore` is automatically reconstructed from `debug.keystore.base64` during Gradle configuration if not already present, so fresh clones build without manual keystore setup.
- **Environment File**: Optional `.env` defaults to `.env.example` via the Secrets Gradle Plugin; no API keys are required for offline playback.
- **Release Builds**: Configure `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` environment variables (or place `my-upload-key.jks` in the project root) before running `assembleRelease`.
