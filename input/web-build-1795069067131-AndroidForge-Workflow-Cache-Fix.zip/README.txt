ANDROIDFORGE WORKFLOW CACHE FIX

Important:
- The failure shown in the GitHub run belongs to the AndroidForge repository workflow,
  not to the VYBE media-player source project.
- Therefore replacing the VYBE ZIP alone cannot fix this particular error.
- This package contains the corrected Gradle cache step and a patch template.

Apply:
1. Open your AndroidForge repository:
   https://github.com/ironworld357-design/AndroidForge
2. Open .github/workflows/build-android.yml and tap Edit.
3. Find the 'Restore Gradle cache' step.
4. Replace its 'key:' line with:

   key: gradle-${{ runner.os }}-${{ steps.toolchain.outputs.gradle_version }}-${{ github.repository }}

5. Commit the change, then run AndroidForge again.

The current public main-branch workflow already shows this stable key form.
The failing run was commit fd76792, so make sure the fix is committed to the
same repository/branch used by the workflow before rerunning.
