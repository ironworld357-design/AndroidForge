# VYBE Surround – APK build notes

## Build on GitHub Actions
This source includes `.github/workflows/build-apk.yml`. Push the project to a GitHub
repository, open **Actions → Build Android APK → Run workflow**, and download the
`vybe-surround-debug-apk` artifact after the workflow completes.

## Local build requirements
- JDK 21
- Android SDK Platform 36 and Build Tools 36.0.0
- Gradle 9.3.1

Run from the project root:

```bash
gradle --no-daemon :app:assembleDebug
```

The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
- The debug APK uses Gradle/Android’s automatically generated standard debug key.
  A release APK built without signing secrets also falls back to that debug key, so it
  is for testing/installing only. For Play Store publishing, add `KEYSTORE_PATH`,
  `STORE_PASSWORD`, `KEY_PASSWORD`, and optionally `KEY_ALIAS` as CI secrets.
- The app uses Android/Media3 decoder and output-route capabilities. Dolby Atmos,
  TrueHD, DTS, HDMI/eARC bitstream passthrough, and multichannel output depend on
  the phone, Android build, decoder licensing, cable/adapter, and receiver. The UI
  reports detected capabilities; it cannot add unsupported hardware codecs.
- `compileSdk` is set to stable Android API 36 rather than the API 36.1 extension
  level to improve build-runner compatibility.
