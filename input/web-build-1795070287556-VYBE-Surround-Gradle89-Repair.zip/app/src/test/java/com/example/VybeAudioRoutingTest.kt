package com.example

import android.content.Context
import android.media.AudioFormat
import androidx.test.core.app.ApplicationProvider
import com.example.audio.engine.AudioRoutingEngine
import com.example.audio.engine.MultichannelTestSynthesizer
import com.example.audio.engine.PlaybackPathValidator
import com.example.audio.model.AudioCodecFormat
import com.example.audio.model.AudioDecoderInfo
import com.example.audio.model.AudioStatusIndicator
import com.example.audio.model.ChannelLayout
import com.example.audio.model.OutputDeviceReport
import com.example.audio.model.OutputRouteType
import com.example.audio.model.PlaybackTestStatus
import com.example.audio.model.RoutingModePreference
import com.example.audio.model.SourceAudioTelemetry
import com.example.audio.model.SpatializerReport
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class VybeAudioRoutingTest {

    private val phoneSpeaker = OutputDeviceReport(
        id = 1,
        productName = "Phone Speakers",
        routeType = OutputRouteType.BUILTIN_SPEAKER,
        isActiveDefault = true,
        maxChannels = 2,
        supportedSampleRates = listOf(48000),
        supportedEncodings = setOf(AudioFormat.ENCODING_PCM_16BIT),
        supportedFormats = setOf(AudioCodecFormat.PCM),
        supportsPassthrough = false,
        directPlaybackCodecs = emptySet()
    )

    private val hdmi71AtmosAvr = OutputDeviceReport(
        id = 2,
        productName = "Denon AVR-X3800H",
        routeType = OutputRouteType.HDMI_EARC,
        isActiveDefault = true,
        maxChannels = 8,
        supportedSampleRates = listOf(44100, 48000, 96000, 192000),
        supportedEncodings = setOf(
            AudioFormat.ENCODING_PCM_16BIT,
            AudioFormat.ENCODING_AC3,
            AudioFormat.ENCODING_E_AC3,
            AudioFormat.ENCODING_E_AC3_JOC,
            AudioFormat.ENCODING_DOLBY_TRUEHD,
            AudioFormat.ENCODING_DTS,
            AudioFormat.ENCODING_DTS_HD
        ),
        supportedFormats = setOf(
            AudioCodecFormat.PCM,
            AudioCodecFormat.AC3,
            AudioCodecFormat.E_AC3,
            AudioCodecFormat.E_AC3_JOC,
            AudioCodecFormat.DOLBY_TRUEHD,
            AudioCodecFormat.DTS,
            AudioCodecFormat.DTS_HD
        ),
        supportsPassthrough = true,
        directPlaybackCodecs = setOf(
            AudioCodecFormat.PCM,
            AudioCodecFormat.AC3,
            AudioCodecFormat.E_AC3,
            AudioCodecFormat.E_AC3_JOC,
            AudioCodecFormat.DOLBY_TRUEHD,
            AudioCodecFormat.DTS,
            AudioCodecFormat.DTS_HD
        )
    )

    private val bluetoothA2dp = OutputDeviceReport(
        id = 3,
        productName = "BT Headphones",
        routeType = OutputRouteType.BLUETOOTH_A2DP,
        isActiveDefault = true,
        maxChannels = 2,
        supportedSampleRates = listOf(44100, 48000),
        supportedEncodings = setOf(AudioFormat.ENCODING_PCM_16BIT),
        supportedFormats = setOf(AudioCodecFormat.PCM),
        supportsPassthrough = false,
        directPlaybackCodecs = emptySet()
    )

    private val dolbyDecoders = listOf(
        AudioDecoderInfo("c2.dolby.ac3.decoder", "audio/ac3", true, false, 6, 32000..48000),
        AudioDecoderInfo("c2.dolby.eac3.decoder", "audio/eac3", true, false, 8, 32000..48000),
        AudioDecoderInfo("c2.dolby.eac3_joc.decoder", "audio/eac3-joc", true, false, 8, 32000..48000)
    )

    private val noSpatializer = SpatializerReport(false, false, "Unavailable", false, false, false)
    private val atmosSpatializer = SpatializerReport(true, true, "Bed + Objects", true, true, true)

    @Test
    fun `path 1 stereo source on phone speakers never invents surround channels`() {
        val source = SourceAudioTelemetry(
            title = "Stereo Movie",
            codec = AudioCodecFormat.PCM,
            rawMimeType = "audio/raw",
            channelCount = 2,
            channelLayout = ChannelLayout.STEREO,
            sampleRateHz = 48000,
            hasMediaLoaded = true
        )
        val res = AudioRoutingEngine.resolveAudioPath(
            source, phoneSpeaker, dolbyDecoders, noSpatializer, RoutingModePreference.AUTO_OPTIMAL
        )
        assertEquals(ChannelLayout.STEREO, res.outputChannelLayout)
        assertFalse(res.downmixApplied)
        assertFalse(res.atmosActive)
    }

    @Test
    fun `path 2 5_1 PCM preserves discrete 5_1 on HDMI receiver`() {
        val source = SourceAudioTelemetry(
            title = "5.1 PCM",
            codec = AudioCodecFormat.PCM,
            rawMimeType = "audio/raw",
            channelCount = 6,
            channelLayout = ChannelLayout.SURROUND_5_1,
            sampleRateHz = 48000,
            hasMediaLoaded = true
        )
        val res = AudioRoutingEngine.resolveAudioPath(
            source, hdmi71AtmosAvr, dolbyDecoders, noSpatializer, RoutingModePreference.AUTO_OPTIMAL
        )
        assertEquals(AudioStatusIndicator.MULTICHANNEL_PCM, res.status)
        assertEquals(ChannelLayout.SURROUND_5_1, res.outputChannelLayout)
        assertFalse(res.downmixApplied)
    }

    @Test
    fun `path 3 6_1 source falls back cleanly to stereo on 2ch speakers`() {
        val source = SourceAudioTelemetry(
            title = "6.1 Surround",
            codec = AudioCodecFormat.PCM,
            rawMimeType = "audio/raw",
            channelCount = 7,
            channelLayout = ChannelLayout.SURROUND_6_1,
            sampleRateHz = 48000,
            hasMediaLoaded = true
        )
        val res = AudioRoutingEngine.resolveAudioPath(
            source, phoneSpeaker, dolbyDecoders, noSpatializer, RoutingModePreference.AUTO_OPTIMAL
        )
        assertEquals(AudioStatusIndicator.STEREO_DOWNMIX, res.status)
        assertEquals(ChannelLayout.STEREO, res.outputChannelLayout)
        assertTrue(res.downmixApplied)
    }

    @Test
    fun `path 4 7_1 source preserves 7_1 on AVR and downmixes on stereo speaker`() {
        val source = SourceAudioTelemetry(
            title = "7.1 Theater",
            codec = AudioCodecFormat.PCM,
            rawMimeType = "audio/raw",
            channelCount = 8,
            channelLayout = ChannelLayout.SURROUND_7_1,
            sampleRateHz = 48000,
            hasMediaLoaded = true
        )
        val avrRes = AudioRoutingEngine.resolveAudioPath(
            source, hdmi71AtmosAvr, dolbyDecoders, noSpatializer, RoutingModePreference.AUTO_OPTIMAL
        )
        assertEquals(ChannelLayout.SURROUND_7_1, avrRes.outputChannelLayout)

        val speakerRes = AudioRoutingEngine.resolveAudioPath(
            source, phoneSpeaker, dolbyDecoders, noSpatializer, RoutingModePreference.AUTO_OPTIMAL
        )
        assertEquals(AudioStatusIndicator.STEREO_DOWNMIX, speakerRes.status)
        assertEquals(ChannelLayout.STEREO, speakerRes.outputChannelLayout)
    }

    @Test
    fun `path 5 and 6 Dolby Digital and Plus decode or passthrough accurately`() {
        val ac3 = SourceAudioTelemetry(
            title = "AC-3",
            codec = AudioCodecFormat.AC3,
            rawMimeType = "audio/ac3",
            channelCount = 6,
            channelLayout = ChannelLayout.SURROUND_5_1,
            hasMediaLoaded = true
        )
        val eac3 = ac3.copy(title = "E-AC-3", codec = AudioCodecFormat.E_AC3, rawMimeType = "audio/eac3")

        val ac3Hdmi = AudioRoutingEngine.resolveAudioPath(
            ac3, hdmi71AtmosAvr, dolbyDecoders, noSpatializer, RoutingModePreference.AUTO_OPTIMAL
        )
        assertEquals(AudioStatusIndicator.ORIGINAL_BITSTREAM, ac3Hdmi.status)
        assertTrue(ac3Hdmi.passthroughActive)

        val eac3ForcePcm = AudioRoutingEngine.resolveAudioPath(
            eac3, hdmi71AtmosAvr, dolbyDecoders, noSpatializer, RoutingModePreference.FORCE_PCM
        )
        assertEquals(AudioStatusIndicator.DOLBY_DECODED, eac3ForcePcm.status)
        assertFalse(eac3ForcePcm.passthroughActive)
    }

    @Test
    fun `path 7 and 8 Dolby Atmos never faked without Spatializer or passthrough`() {
        val atmos = SourceAudioTelemetry(
            title = "Atmos JOC",
            codec = AudioCodecFormat.E_AC3_JOC,
            rawMimeType = "audio/eac3-joc",
            channelCount = 6,
            channelLayout = ChannelLayout.SURROUND_5_1,
            hasMediaLoaded = true
        )

        // Stereo speaker without Spatializer must NOT claim Atmos active
        val speakerRes = AudioRoutingEngine.resolveAudioPath(
            atmos, phoneSpeaker, dolbyDecoders, noSpatializer, RoutingModePreference.AUTO_OPTIMAL
        )
        assertFalse(speakerRes.atmosActive)

        // Headphone / Spatializer with JOC capability confirms device-side Atmos
        val spatialRes = AudioRoutingEngine.resolveAudioPath(
            atmos, bluetoothA2dp, dolbyDecoders, atmosSpatializer, RoutingModePreference.AUTO_OPTIMAL
        )
        assertTrue(spatialRes.atmosActive)
        assertFalse(spatialRes.passthroughActive) // Bluetooth does not carry native Atmos bitstream!

        // HDMI eARC AVR confirms Atmos Bitstream Passthrough
        val hdmiRes = AudioRoutingEngine.resolveAudioPath(
            atmos, hdmi71AtmosAvr, dolbyDecoders, noSpatializer, RoutingModePreference.PREFER_PASSTHROUGH
        )
        assertEquals(AudioStatusIndicator.ORIGINAL_BITSTREAM, hdmiRes.status)
        assertTrue(hdmiRes.passthroughActive)
        assertTrue(hdmiRes.atmosActive)
    }

    @Test
    fun `path 9 unsupported format returns UNSUPPORTED_FORMAT without faking`() {
        val dsd = SourceAudioTelemetry(
            title = "Unsupported DSD",
            codec = AudioCodecFormat.UNSUPPORTED,
            rawMimeType = "audio/x-dsd",
            channelCount = 6,
            channelLayout = ChannelLayout.SURROUND_5_1,
            hasMediaLoaded = true
        )
        val res = AudioRoutingEngine.resolveAudioPath(
            dsd, hdmi71AtmosAvr, dolbyDecoders, atmosSpatializer, RoutingModePreference.AUTO_OPTIMAL
        )
        assertEquals(AudioStatusIndicator.UNSUPPORTED_FORMAT, res.status)
        assertFalse(res.passthroughActive)
        assertFalse(res.atmosActive)
    }

    @Test
    fun `path 10 validator produces all 10 verified scenario checks`() {
        val results = PlaybackPathValidator.runAll10Checks(
            devices = listOf(phoneSpeaker, hdmi71AtmosAvr),
            activeDevice = hdmi71AtmosAvr,
            decoders = dolbyDecoders,
            spatializer = atmosSpatializer
        )
        assertEquals(10, results.size)
        assertTrue(results.take(9).all {
            it.status == PlaybackTestStatus.VERIFIED_PASS || it.status == PlaybackTestStatus.VERIFIED_FALLBACK
        })
        assertEquals(PlaybackTestStatus.VERIFIED_PASS, results.last().status)
    }

    @Test
    fun `multichannel wav synthesizer writes valid WAVEFORMATEXTENSIBLE headers`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val suite = MultichannelTestSynthesizer.generateReferenceSuite(context)
        assertEquals(5, suite.size)
        val track71 = suite.first { it.layout == ChannelLayout.SURROUND_7_1 }
        val file = File(track71.uri.path!!)
        assertTrue(file.exists())
        val bytes = file.inputStream().use { stream ->
            ByteArray(44).also { stream.read(it) }
        }
        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        assertEquals('R'.code.toByte(), buf.get(0))
        assertEquals('W'.code.toByte(), buf.get(8))
        val channels = buf.getShort(22).toInt()
        val sampleRate = buf.getInt(24)
        val channelMask = buf.getInt(40)
        assertEquals(8, channels)
        assertEquals(48000, sampleRate)
        assertEquals(0x63F, channelMask)
    }
}
