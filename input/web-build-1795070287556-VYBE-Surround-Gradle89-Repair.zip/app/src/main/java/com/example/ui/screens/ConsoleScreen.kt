package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.SurroundSound
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.audio.engine.MultichannelTestSynthesizer
import com.example.audio.model.AudioTrackOption
import com.example.audio.model.RoutingModePreference
import com.example.audio.model.SpeakerChannel
import com.example.ui.components.AudioStatusHeroCard
import com.example.ui.components.SignalChainTelemetryGrid
import com.example.ui.components.SpeakerTopologyCard
import com.example.ui.state.VybeUiState
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.StudioAmber

@Composable
fun ConsoleScreen(
    state: VybeUiState,
    onPickVideo: () -> Unit,
    onPickAudioOrContainer: () -> Unit,
    onPlayStreamUrl: (String) -> Unit,
    onPlayReferenceTrack: (MultichannelTestSynthesizer.GeneratedReferenceTrack) -> Unit,
    onTogglePlayPause: () -> Unit,
    onSpeakerTap: (SpeakerChannel) -> Unit,
    onSelectRoutingMode: (RoutingModePreference) -> Unit,
    onSelectAudioTrack: (AudioTrackOption) -> Unit,
    onDismissRouteBanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showStreamDialog by remember { mutableStateOf(false) }
    var streamUrlInput by remember { mutableStateOf("") }

    if (showStreamDialog) {
        AlertDialog(
            onDismissRequest = { showStreamDialog = false },
            title = { Text("Load Network Media Stream") },
            text = {
                Column {
                    Text(
                        text = "Enter an HLS (.m3u8), DASH (.mpd), MP4, or multichannel audio stream URL.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = streamUrlInput,
                        onValueChange = { streamUrlInput = it },
                        label = { Text("Stream URL") },
                        placeholder = { Text("https://...") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("stream_url_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onPlayStreamUrl(streamUrlInput)
                        showStreamDialog = false
                    },
                    enabled = streamUrlInput.isNotBlank(),
                    modifier = Modifier.testTag("confirm_stream_url_button")
                ) {
                    Text("Load Stream")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStreamDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    val resolution = state.resolution ?: return

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("console_screen_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 840.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "VYBE SURROUND AUDIO",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Master Control Console",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SurroundSound,
                            contentDescription = "Active spatializer status",
                            tint = if (resolution.spatializerActive) ElectricCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (resolution.spatializerActive) "SPATIAL ON" else "${resolution.activeRouteType.label.uppercase()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Route disconnect or change banner
        item {
            AnimatedVisibility(visible = !state.routeBanner.isNullOrBlank()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 840.dp),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    border = BorderStroke(1.dp, StudioAmber.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = "Audio route update",
                            tint = StudioAmber,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = state.routeBanner.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = onDismissRouteBanner,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Dismiss route notification",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Error card if stream/codec failed
        if (!state.playerError.isNullOrBlank()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 840.dp),
                    shape = MaterialTheme.shapes.medium,
                    color = CrimsonContainer,
                    border = BorderStroke(1.dp, CrimsonAlert.copy(alpha = 0.7f))
                ) {
                    Text(
                        text = state.playerError,
                        style = MaterialTheme.typography.bodySmall,
                        color = CrimsonAlert,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        // 1. Live Audio Status Hero Indicator
        item {
            AudioStatusHeroCard(
                source = state.sourceAudio,
                resolution = resolution,
                isPlaying = state.isPlaying,
                positionMs = state.positionMs,
                durationMs = state.durationMs,
                activeAudioTrackConfig = state.activeAudioTrackConfig,
                onTogglePlayPause = onTogglePlayPause,
                modifier = Modifier.widthIn(max = 840.dp)
            )
        }

        // 2. Interactive Speaker Stage Topology
        item {
            SpeakerTopologyCard(
                nodes = state.speakerNodes,
                sourceLayout = state.sourceAudio.channelLayout,
                outputLayout = resolution.outputChannelLayout,
                isPlaying = state.isPlaying,
                downmixApplied = resolution.downmixApplied,
                atmosActive = resolution.atmosActive,
                lastPingedSpeaker = state.lastPingedSpeaker,
                onSpeakerTap = onSpeakerTap,
                modifier = Modifier.widthIn(max = 840.dp)
            )
        }

        // 3. Media Source Picker & Genuine Multichannel Reference PCM Suite
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 840.dp),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "MEDIA SOURCE & REFERENCE SIGNALS",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onPickVideo,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("pick_video_button"),
                            contentPadding = PaddingValues(horizontal = 10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Movie,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Video", maxLines = 1)
                        }

                        OutlinedButton(
                            onClick = onPickAudioOrContainer,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("pick_audio_file_button"),
                            contentPadding = PaddingValues(horizontal = 10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AudioFile,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("MKV / Audio", maxLines = 1)
                        }

                        OutlinedButton(
                            onClick = { showStreamDialog = true },
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("open_stream_url_button"),
                            colors = ButtonDefaults.outlinedButtonColors(),
                            contentPadding = PaddingValues(horizontal = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Link,
                                contentDescription = "Load network stream URL",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = "GENUINE MULTICHANNEL PCM TEST SUITE (48 kHz WAV)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(state.referenceTracks, key = { it.id }) { track ->
                            val isCurrent = state.sourceAudio.title == track.title
                            Surface(
                                onClick = { onPlayReferenceTrack(track) },
                                modifier = Modifier.testTag("ref_track_${track.id}"),
                                shape = RoundedCornerShape(12.dp),
                                color = if (isCurrent) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceContainerLow
                                },
                                border = BorderStroke(
                                    1.dp,
                                    if (isCurrent) ElectricCyan else MaterialTheme.colorScheme.outlineVariant
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .widthIn(min = 128.dp)
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                ) {
                                    Text(
                                        text = track.layout.shortCode,
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                        color = if (isCurrent) ElectricCyan else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = track.layout.label,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${track.layout.channelCount}ch PCM",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Audio Track Switcher (when multi-track media is loaded)
        if (state.audioTracks.size > 1) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 840.dp),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "SOURCE AUDIO TRACKS (${state.audioTracks.size})",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            state.audioTracks.forEachIndexed { idx, track ->
                                FilterChip(
                                    selected = track.isSelected,
                                    onClick = { onSelectAudioTrack(track) },
                                    label = { Text(track.label) },
                                    modifier = Modifier.testTag("audio_track_chip_$idx")
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Routing Preference & Downmix Control
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 840.dp),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Tune,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "SURROUND ROUTING & FALLBACK POLICY",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RoutingModePreference.entries.forEach { mode ->
                            val enabled = mode != RoutingModePreference.PREFER_PASSTHROUGH ||
                                (state.activeDevice?.supportsPassthrough == true)
                            FilterChip(
                                selected = state.preferences.routingMode == mode,
                                onClick = { onSelectRoutingMode(mode) },
                                enabled = enabled,
                                label = { Text(mode.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = ElectricCyan
                                ),
                                modifier = Modifier.testTag("routing_mode_${mode.name.lowercase()}")
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = state.preferences.routingMode.summary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (!resolution.downmixMatrixDescription.isNullOrBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Text(
                                text = "Downmix Matrix: ${resolution.downmixMatrixDescription}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
            }
        }

        // 6. Full Signal Chain Telemetry Matrix
        item {
            SignalChainTelemetryGrid(
                source = state.sourceAudio,
                resolution = resolution,
                modifier = Modifier.widthIn(max = 840.dp)
            )
        }

        item { Spacer(Modifier.height(8.dp)) }
    }
}
