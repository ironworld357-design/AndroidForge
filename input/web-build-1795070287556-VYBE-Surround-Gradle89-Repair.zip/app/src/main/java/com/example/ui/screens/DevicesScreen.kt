package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DisplaySettings
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SpatialAudio
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.audio.model.AudioDecoderInfo
import com.example.audio.model.OutputDeviceReport
import com.example.ui.components.routeIconFor
import com.example.ui.state.VybeUiState
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.DeepCyanContainer
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.StudioAmber

private enum class DecoderFilter(val label: String) {
    ALL("All Audio"),
    DOLBY("Dolby / Atmos"),
    DTS("DTS"),
    HARDWARE("Hardware Only")
}

@Composable
fun DevicesScreen(
    state: VybeUiState,
    onRefreshHardware: () -> Unit,
    modifier: Modifier = Modifier
) {
    var decoderFilter by remember { mutableStateOf(DecoderFilter.ALL) }

    val filteredDecoders = remember(state.decoders, decoderFilter) {
        when (decoderFilter) {
            DecoderFilter.ALL -> state.decoders
            DecoderFilter.DOLBY -> state.decoders.filter {
                it.mimeType.contains("ac3") || it.mimeType.contains("ac4") || it.mimeType.contains("true-hd")
            }
            DecoderFilter.DTS -> state.decoders.filter { it.mimeType.contains("dts") }
            DecoderFilter.HARDWARE -> state.decoders.filter { it.isHardwareAccelerated }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("devices_screen_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 840.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "HARDWARE & OUTPUT MATRIX",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Connected Audio Routes",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                IconButton(
                    onClick = onRefreshHardware,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("refresh_hardware_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Refresh connected audio devices",
                        tint = ElectricCyan
                    )
                }
            }
        }

        // Connected Output Devices
        items(state.outputDevices, key = { "${it.id}_${it.routeType}" }) { device ->
            OutputDeviceCard(
                device = device,
                modifier = Modifier.widthIn(max = 840.dp)
            )
        }

        // Android Spatializer Inspector
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 840.dp),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.SpatialAudio,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "ANDROID SPATIALIZER ENGINE",
                            style = MaterialTheme.typography.labelMedium,
                            color = ElectricCyan
                        )
                    }
                    Spacer(Modifier.height(10.dp))

                    val sp = state.spatializer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MiniSpecChip(
                            label = "Status",
                            value = when {
                                sp.isAvailable && sp.isEnabled -> "Enabled"
                                sp.isAvailable -> "Available (Off)"
                                else -> "Unavailable"
                            },
                            highlight = sp.isAvailable && sp.isEnabled,
                            modifier = Modifier.weight(1f)
                        )
                        MiniSpecChip(
                            label = "Level",
                            value = sp.immersiveLevel,
                            highlight = sp.canSpatializeAtmosJoc,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MiniSpecChip(
                            label = "5.1 PCM Spatial",
                            value = if (sp.canSpatialize51Pcm) "Confirmed" else "No",
                            highlight = sp.canSpatialize51Pcm,
                            modifier = Modifier.weight(1f)
                        )
                        MiniSpecChip(
                            label = "Atmos JOC Spatial",
                            value = if (sp.canSpatializeAtmosJoc) "Confirmed" else "No",
                            highlight = sp.canSpatializeAtmosJoc,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Display HDR Capabilities
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 840.dp),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.DisplaySettings,
                            contentDescription = null,
                            tint = StudioAmber,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "DISPLAY HDR & REFRESH TELEMETRY",
                            style = MaterialTheme.typography.labelMedium,
                            color = StudioAmber
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Supported Formats: ${state.displayCaps.supportedHdrTypes.joinToString { it.label }}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Panel Refresh: ${"%.1f".format(state.displayCaps.refreshRateHz)} Hz • Seamless Frame Rate Switch: ${if (state.displayCaps.seamlessFrameRateSwitchSupported) "Supported" else "Panel Fixed"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // MediaCodecList Decoder Inventory
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 840.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Memory,
                        contentDescription = null,
                        tint = SignalEmerald,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "INSTALLED OS AUDIO DECODERS (${filteredDecoders.size})",
                        style = MaterialTheme.typography.labelMedium,
                        color = SignalEmerald
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DecoderFilter.entries.forEach { filter ->
                        FilterChip(
                            selected = decoderFilter == filter,
                            onClick = { decoderFilter = filter },
                            label = { Text(filter.label) },
                            modifier = Modifier.testTag("decoder_filter_${filter.name.lowercase()}")
                        )
                    }
                }
            }
        }

        if (filteredDecoders.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 840.dp),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Text(
                        text = "No platform decoders found for this codec category. External HDMI receiver passthrough is required unless licensed OEM decoders are present.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        } else {
            items(filteredDecoders, key = { "${it.codecName}_${it.mimeType}" }) { decoder ->
                DecoderInventoryRow(
                    decoder = decoder,
                    modifier = Modifier.widthIn(max = 840.dp)
                )
            }
        }

        item { Spacer(Modifier.height(8.dp)) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OutputDeviceCard(
    device: OutputDeviceReport,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("output_device_card_${device.id}"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(
            1.dp,
            if (device.isActiveDefault) ElectricCyan.copy(alpha = 0.65f) else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (device.isActiveDefault) DeepCyanContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
                    modifier = Modifier.size(42.dp)
                ) {
                    Icon(
                        imageVector = routeIconFor(device.routeType),
                        contentDescription = device.routeType.label,
                        tint = if (device.isActiveDefault) ElectricCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(9.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = device.productName,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (device.isActiveDefault) {
                            Spacer(Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Active output device",
                                tint = ElectricCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(
                        text = "${device.routeType.label} • Max ${device.maxChannels}ch",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (device.supportsPassthrough) AmberContainer else MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Text(
                        text = if (device.supportsPassthrough) "PASSTHROUGH" else "PCM SINK",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (device.supportsPassthrough) StudioAmber else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(
                text = "Sample Rates: ${device.supportedSampleRates.joinToString { "${it / 1000.0}k" }}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                device.supportedFormats.forEach { fmt ->
                    val isDirect = fmt in device.directPlaybackCodecs
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isDirect) EmeraldContainer else MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(
                            1.dp,
                            if (isDirect) SignalEmerald.copy(alpha = 0.55f) else MaterialTheme.colorScheme.outlineVariant
                        )
                    ) {
                        Text(
                            text = fmt.displayName,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isDirect) SignalEmerald else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            if (!device.bluetoothWarning.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AmberContainer.copy(alpha = 0.65f),
                    border = BorderStroke(1.dp, StudioAmber.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = "Bluetooth capability notice",
                            tint = StudioAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = device.bluetoothWarning,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DecoderInventoryRow(
    decoder: AudioDecoderInfo,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = decoder.codecName,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${decoder.mimeType} • Max ${decoder.maxChannelCount}ch • ${decoder.supportedSampleRates.first / 1000}–${decoder.supportedSampleRates.last / 1000} kHz",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (decoder.isHardwareAccelerated) EmeraldContainer else MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                Text(
                    text = if (decoder.isHardwareAccelerated) "HW" else "SW",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (decoder.isHardwareAccelerated) SignalEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun MiniSpecChip(
    label: String,
    value: String,
    highlight: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, if (highlight) ElectricCyan.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = if (highlight) ElectricCyan else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
