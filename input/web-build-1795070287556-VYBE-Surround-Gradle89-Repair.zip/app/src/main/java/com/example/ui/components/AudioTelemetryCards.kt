package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BluetoothAudio
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SettingsInputHdmi
import androidx.compose.material.icons.rounded.Speaker
import androidx.compose.material.icons.rounded.SurroundSound
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.audio.model.AudioPathResolution
import com.example.audio.model.AudioStatusIndicator
import com.example.audio.model.OutputRouteType
import com.example.audio.model.SourceAudioTelemetry
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.DeepCyanContainer
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SlateDownmix
import com.example.ui.theme.SlateDownmixContainer
import com.example.ui.theme.StudioAmber

@Composable
fun statusColorsFor(status: AudioStatusIndicator): Pair<Color, Color> {
    return when (status) {
        AudioStatusIndicator.ORIGINAL_BITSTREAM -> StudioAmber to AmberContainer
        AudioStatusIndicator.DOLBY_DECODED -> ElectricCyan to DeepCyanContainer
        AudioStatusIndicator.MULTICHANNEL_PCM -> SignalEmerald to EmeraldContainer
        AudioStatusIndicator.STEREO_DOWNMIX -> SlateDownmix to SlateDownmixContainer
        AudioStatusIndicator.UNSUPPORTED_FORMAT -> CrimsonAlert to CrimsonContainer
    }
}

fun routeIconFor(routeType: OutputRouteType): ImageVector = when (routeType) {
    OutputRouteType.HDMI, OutputRouteType.HDMI_ARC, OutputRouteType.HDMI_EARC -> Icons.Rounded.SettingsInputHdmi
    OutputRouteType.USB_DAC -> Icons.Rounded.Usb
    OutputRouteType.WIRED_HEADSET -> Icons.Rounded.Headphones
    OutputRouteType.BLUETOOTH_A2DP, OutputRouteType.BLUETOOTH_LE_AUDIO -> Icons.Rounded.BluetoothAudio
    OutputRouteType.BUILTIN_SPEAKER, OutputRouteType.OTHER -> Icons.Rounded.Speaker
}

@Composable
fun AudioStatusHeroCard(
    source: SourceAudioTelemetry,
    resolution: AudioPathResolution,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    activeAudioTrackConfig: String?,
    onTogglePlayPause: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (accentColor, containerColor) = statusColorsFor(resolution.status)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("audio_status_hero_card"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Required Status Indicator Pill
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = containerColor,
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.65f)),
                    modifier = Modifier.testTag("audio_status_indicator_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (resolution.status == AudioStatusIndicator.UNSUPPORTED_FORMAT) {
                                Icons.Rounded.ErrorOutline
                            } else {
                                Icons.Rounded.SurroundSound
                            },
                            contentDescription = "Audio path status",
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = resolution.status.label.uppercase(),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = accentColor
                        )
                    }
                }

                // Confirmed Atmos badge (strictly hidden unless confirmed!)
                if (resolution.atmosActive) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AmberContainer,
                        border = BorderStroke(1.dp, StudioAmber.copy(alpha = 0.7f)),
                        modifier = Modifier.testTag("atmos_confirmed_badge")
                    ) {
                        Text(
                            text = "DOLBY ATMOS ACTIVE",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = StudioAmber,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = routeIconFor(resolution.activeRouteType),
                                contentDescription = resolution.activeOutputDeviceName,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = resolution.outputChannelLayout.shortCode,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = source.title,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = resolution.playbackModeSummary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (!activeAudioTrackConfig.isNullOrBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = activeAudioTrackConfig,
                            style = MaterialTheme.typography.labelSmall,
                            color = accentColor
                        )
                    }
                }

                Spacer(Modifier.width(12.dp))

                FilledIconButton(
                    onClick = onTogglePlayPause,
                    enabled = source.hasMediaLoaded,
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("hero_play_pause_button"),
                    shape = CircleShape,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = accentColor,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (isPlaying) "Pause playback" else "Resume playback"
                    )
                }
            }

            if (source.hasMediaLoaded && durationMs > 0L) {
                Spacer(Modifier.height(12.dp))
                val progress = (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp),
                    color = accentColor,
                    trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatTimeMs(positionMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatTimeMs(durationMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (!resolution.fallbackReason.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.GraphicEq,
                            contentDescription = "Routing note",
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = resolution.fallbackReason,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SignalChainTelemetryGrid(
    source: SourceAudioTelemetry,
    resolution: AudioPathResolution,
    modifier: Modifier = Modifier
) {
    val sampleRateText = if (source.sampleRateHz > 0) {
        val khz = source.sampleRateHz / 1000.0
        if (khz % 1.0 == 0.0) "${khz.toInt()}.0 kHz" else "${"%.1f".format(khz)} kHz"
    } else {
        "Unavailable"
    }

    val bitrateText = if (source.bitrateBps > 0) {
        if (source.bitrateBps >= 1_000_000) {
            "${"%.2f".format(source.bitrateBps / 1_000_000.0)} Mbps"
        } else {
            "${source.bitrateBps / 1000} kbps"
        }
    } else {
        "Variable / Unreported"
    }

    val passthroughText = when {
        resolution.passthroughActive -> "Active (Bitstream Locked)"
        resolution.passthroughAvailable -> "Available on ${resolution.activeRouteType.label}"
        else -> "Not Supported on Route"
    }

    val items = listOf(
        "Source Format" to "${source.codec.displayName} (${source.rawMimeType})",
        "Source Channels" to "${source.channelCount}ch • ${source.channelLayout.label}",
        "Output Device" to "${resolution.activeOutputDeviceName} (${resolution.activeRouteType.label})",
        "Output Config" to resolution.outputChannelLayout.label,
        "Decoder Path" to resolution.decoderSummary,
        "Passthrough" to passthroughText,
        "Sample Rate" to sampleRateText,
        "Bitrate" to bitrateText,
        "Playback Mode" to resolution.playbackModeSummary,
        "A/V Sync" to resolution.avSyncStatus
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("signal_chain_telemetry_grid"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "SIGNAL CHAIN TELEMETRY",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(10.dp))

            items.chunked(2).forEachIndexed { rowIdx, pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    pair.forEach { (label, value) ->
                        TelemetryCell(
                            label = label,
                            value = value,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (pair.size == 1) {
                        Spacer(Modifier.weight(1f))
                    }
                }
                if (rowIdx < items.chunked(2).lastIndex) {
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun TelemetryCell(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp)) {
            Text(
                text = label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

fun formatTimeMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    return "%02d:%02d".format(mins, secs)
}
