package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cable
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.audio.model.PlaybackPathTestResult
import com.example.audio.model.PlaybackTestStatus
import com.example.audio.model.SpeakerChannel
import com.example.ui.state.VybeUiState
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.DeepCyanContainer
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.StudioAmber

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VerifyScreen(
    state: VybeUiState,
    onRunValidation: () -> Unit,
    onSpeakerPing: (SpeakerChannel) -> Unit,
    modifier: Modifier = Modifier
) {
    val passCount = state.validationResults.count { it.status == PlaybackTestStatus.VERIFIED_PASS }
    val fallbackCount = state.validationResults.count { it.status == PlaybackTestStatus.VERIFIED_FALLBACK }
    val receiverNeededCount = state.validationResults.count { it.status == PlaybackTestStatus.REQUIRES_EXTERNAL_RECEIVER }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("verify_screen_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 840.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "AUTOMATED HARDWARE AUDIT",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "10-Path Verification Suite",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                Button(
                    onClick = onRunValidation,
                    enabled = !state.isRunningValidation,
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("run_hardware_audit_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Verified,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Run Audit")
                }
            }
        }

        // Summary KPI strip
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 840.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AuditMetricTile(
                    label = "Verified Pass",
                    count = passCount,
                    accent = SignalEmerald,
                    modifier = Modifier.weight(1f)
                )
                AuditMetricTile(
                    label = "Safe Fallback",
                    count = fallbackCount,
                    accent = ElectricCyan,
                    modifier = Modifier.weight(1f)
                )
                AuditMetricTile(
                    label = "Needs AVR",
                    count = receiverNeededCount,
                    accent = StudioAmber,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Individual Channel Isolation Calibration Panel
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 840.dp),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.GraphicEq,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "CHANNEL ISOLATION CALIBRATION TONES",
                            style = MaterialTheme.typography.labelMedium,
                            color = ElectricCyan
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Plays a real isolated PCM tone in the corresponding WAVEFORMATEXTENSIBLE channel slot.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            SpeakerChannel.FL,
                            SpeakerChannel.FC,
                            SpeakerChannel.FR,
                            SpeakerChannel.LFE,
                            SpeakerChannel.SL,
                            SpeakerChannel.SR,
                            SpeakerChannel.BC,
                            SpeakerChannel.BL,
                            SpeakerChannel.BR
                        ).forEach { ch ->
                            OutlinedButton(
                                onClick = { onSpeakerPing(ch) },
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("calibrate_${ch.code.lowercase()}"),
                                contentPadding = PaddingValues(horizontal = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PlayCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(5.dp))
                                Text(ch.code)
                            }
                        }
                    }
                }
            }
        }

        // 10 Path Results
        items(state.validationResults, key = { it.id }) { item ->
            ValidationResultCard(
                result = item,
                modifier = Modifier.widthIn(max = 840.dp)
            )
        }

        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun AuditMetricTile(
    label: String,
    count: Int,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = accent
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ValidationResultCard(
    result: PlaybackPathTestResult,
    modifier: Modifier = Modifier
) {
    val (accent, container, icon) = when (result.status) {
        PlaybackTestStatus.VERIFIED_PASS -> Triple(SignalEmerald, EmeraldContainer, Icons.Rounded.CheckCircle)
        PlaybackTestStatus.VERIFIED_FALLBACK -> Triple(ElectricCyan, DeepCyanContainer, Icons.Rounded.Verified)
        PlaybackTestStatus.REQUIRES_EXTERNAL_RECEIVER -> Triple(StudioAmber, AmberContainer, Icons.Rounded.Cable)
        PlaybackTestStatus.NOT_SUPPORTED_ON_HARDWARE,
        PlaybackTestStatus.PENDING -> Triple(CrimsonAlert, CrimsonContainer, Icons.Rounded.ErrorOutline)
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("validation_path_${result.id}"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = icon,
                        contentDescription = result.statusBadge,
                        tint = accent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(
                            text = result.scenarioCode,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${result.id}. ${result.title}",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = container,
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = result.statusBadge,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = accent,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = result.hardwareProof,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = result.resolutionSummary,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
