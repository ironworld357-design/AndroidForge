package com.example.audio.engine

import android.content.Context
import android.hardware.display.DisplayManager
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.Spatializer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import com.example.audio.model.AudioCodecFormat
import com.example.audio.model.AudioDecoderInfo
import com.example.audio.model.DisplayCapabilitiesReport
import com.example.audio.model.HdrFormat
import com.example.audio.model.OutputDeviceReport
import com.example.audio.model.OutputRouteType
import com.example.audio.model.SpatializerReport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors

/**
 * Inspects genuine Android OS, AudioManager, Spatializer, Display, and MediaCodecList hardware capabilities.
 * Reacts live when external HDMI, USB DAC, wired, or Bluetooth audio routes connect or disconnect.
 */
class AudioCapabilityInspector(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val spatializerExecutor = Executors.newSingleThreadExecutor()

    private val _outputDevices = MutableStateFlow<List<OutputDeviceReport>>(emptyList())
    val outputDevices: StateFlow<List<OutputDeviceReport>> = _outputDevices.asStateFlow()

    private val _activeDevice = MutableStateFlow(fallbackSpeakerReport())
    val activeDevice: StateFlow<OutputDeviceReport> = _activeDevice.asStateFlow()

    private val _spatializerReport = MutableStateFlow(SpatializerReport(false, false, "Unavailable", false, false, false))
    val spatializerReport: StateFlow<SpatializerReport> = _spatializerReport.asStateFlow()

    private val _decoders = MutableStateFlow<List<AudioDecoderInfo>>(emptyList())
    val decoders: StateFlow<List<AudioDecoderInfo>> = _decoders.asStateFlow()

    private val _displayCapabilities = MutableStateFlow(
        DisplayCapabilitiesReport(false, listOf(HdrFormat.SDR), 60f, false)
    )
    val displayCapabilities: StateFlow<DisplayCapabilitiesReport> = _displayCapabilities.asStateFlow()

    private var onRouteChangedListener: ((OutputDeviceReport, Boolean) -> Unit)? = null
    private var previousExternalDeviceIds: Set<Int> = emptySet()

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            refreshHardwareState(routeChangeEvent = true, disconnected = false)
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            val hadExternalRemoved = removedDevices?.any {
                it.isSink && it.type != AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
            } == true
            refreshHardwareState(routeChangeEvent = true, disconnected = hadExternalRemoved)
        }
    }

    private var spatializerListener: Any? = null

    fun startMonitoring(onRouteChanged: ((OutputDeviceReport, Boolean) -> Unit)? = null) {
        this.onRouteChangedListener = onRouteChanged
        _decoders.value = inspectMediaCodecs()
        refreshHardwareState(routeChangeEvent = false, disconnected = false)
        audioManager.registerAudioDeviceCallback(deviceCallback, mainHandler)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S_V2) {
            runCatching {
                val spatializer = audioManager.spatializer
                val listener = object : Spatializer.OnSpatializerStateChangedListener {
                    override fun onSpatializerEnabledChanged(spat: Spatializer, enabled: Boolean) {
                        _spatializerReport.value = inspectSpatializer()
                    }

                    override fun onSpatializerAvailableChanged(spat: Spatializer, available: Boolean) {
                        _spatializerReport.value = inspectSpatializer()
                    }
                }
                spatializerListener = listener
                spatializer.addOnSpatializerStateChangedListener(spatializerExecutor, listener)
            }
        }
    }

    fun stopMonitoring() {
        runCatching { audioManager.unregisterAudioDeviceCallback(deviceCallback) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S_V2) {
            val listener = spatializerListener as? Spatializer.OnSpatializerStateChangedListener
            if (listener != null) {
                runCatching { audioManager.spatializer.removeOnSpatializerStateChangedListener(listener) }
            }
        }
        onRouteChangedListener = null
    }

    fun refreshHardwareState(routeChangeEvent: Boolean = false, disconnected: Boolean = false) {
        val devices = inspectOutputDevices()
        _outputDevices.value = devices
        val chosenActive = selectPrimaryActiveDevice(devices)
        _activeDevice.value = chosenActive
        _spatializerReport.value = inspectSpatializer()
        _displayCapabilities.value = inspectDisplayCapabilities()

        val currentExternalIds = devices
            .filter { it.routeType != OutputRouteType.BUILTIN_SPEAKER }
            .map { it.id }
            .toSet()
        val deviceDisconnected = disconnected || (previousExternalDeviceIds - currentExternalIds).isNotEmpty()
        previousExternalDeviceIds = currentExternalIds

        if (routeChangeEvent) {
            onRouteChangedListener?.invoke(chosenActive, deviceDisconnected)
        }
    }

    private fun inspectOutputDevices(): List<OutputDeviceReport> {
        val rawDevices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .filter { it.isSink }

        if (rawDevices.isEmpty()) {
            return listOf(fallbackSpeakerReport())
        }

        val reports = rawDevices.map { device ->
            val routeType = mapRouteType(device.type)
            val encodings = device.encodings.toSet()
            val channelCounts = device.channelCounts
            val maxChannels = (channelCounts.maxOrNull() ?: defaultChannelsForRoute(routeType))
                .coerceAtLeast(if (routeType == OutputRouteType.BUILTIN_SPEAKER) 2 else 2)
            val sampleRates = device.sampleRates.toList().sorted()
                .ifEmpty { listOf(48000) }

            val directCodecs = probeDirectPlaybackCodecs(device, routeType, encodings, maxChannels)
            val supportedFormats = mapEncodingsToFormats(encodings, directCodecs)

            val isBluetooth = routeType == OutputRouteType.BLUETOOTH_A2DP ||
                routeType == OutputRouteType.BLUETOOTH_LE_AUDIO
            val btWarning = if (isBluetooth && directCodecs.none { it.isDolby || it.isDts }) {
                "Bluetooth A2DP/LE carries stereo PCM/codec audio only; native 5.1/7.1 or Atmos bitstreams are not supported over this link."
            } else null

            val supportsPassthrough = routeType.supportsNativeBitstream &&
                directCodecs.any { it != AudioCodecFormat.PCM }

            OutputDeviceReport(
                id = device.id,
                productName = device.productName?.toString()?.takeIf { it.isNotBlank() } ?: routeType.label,
                routeType = routeType,
                isActiveDefault = false,
                maxChannels = maxChannels,
                supportedSampleRates = sampleRates,
                supportedEncodings = encodings,
                supportedFormats = supportedFormats,
                supportsPassthrough = supportsPassthrough,
                directPlaybackCodecs = directCodecs,
                bluetoothWarning = btWarning
            )
        }

        val primaryId = selectPrimaryActiveDevice(reports).id
        return reports.map { it.copy(isActiveDefault = it.id == primaryId) }
    }

    private fun selectPrimaryActiveDevice(devices: List<OutputDeviceReport>): OutputDeviceReport {
        if (devices.isEmpty()) return fallbackSpeakerReport()
        val priority = listOf(
            OutputRouteType.HDMI_EARC,
            OutputRouteType.HDMI_ARC,
            OutputRouteType.HDMI,
            OutputRouteType.USB_DAC,
            OutputRouteType.WIRED_HEADSET,
            OutputRouteType.BLUETOOTH_LE_AUDIO,
            OutputRouteType.BLUETOOTH_A2DP,
            OutputRouteType.OTHER,
            OutputRouteType.BUILTIN_SPEAKER
        )
        for (route in priority) {
            devices.firstOrNull { it.routeType == route }?.let { return it }
        }
        return devices.first()
    }

    private fun probeDirectPlaybackCodecs(
        device: AudioDeviceInfo,
        routeType: OutputRouteType,
        reportedEncodings: Set<Int>,
        maxChannels: Int
    ): Set<AudioCodecFormat> {
        val supported = mutableSetOf<AudioCodecFormat>()
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
            .build()

        // Never assume Bluetooth carries native lossless 5.1/7.1 or Atmos bitstreams unless OS direct playback confirms it
        val candidateEncodings = listOf(
            AudioFormat.ENCODING_AC3 to AudioCodecFormat.AC3,
            AudioFormat.ENCODING_E_AC3 to AudioCodecFormat.E_AC3,
            AudioFormat.ENCODING_DTS to AudioCodecFormat.DTS,
            AudioFormat.ENCODING_DTS_HD to AudioCodecFormat.DTS_HD
        ) + buildApiSpecificEncodings()

        for ((encoding, codec) in candidateEncodings) {
            val channelMask = when {
                maxChannels >= 8 -> AudioFormat.CHANNEL_OUT_7POINT1_SURROUND
                maxChannels >= 6 -> AudioFormat.CHANNEL_OUT_5POINT1
                else -> AudioFormat.CHANNEL_OUT_STEREO
            }
            val format = AudioFormat.Builder()
                .setEncoding(encoding)
                .setSampleRate(48000)
                .setChannelMask(channelMask)
                .build()

            val directSupported = checkDirectPlayback(format, attrs, device, reportedEncodings, encoding)
            if (directSupported) {
                if (routeType == OutputRouteType.BLUETOOTH_A2DP || routeType == OutputRouteType.BLUETOOTH_LE_AUDIO) {
                    // Require BOTH direct playback API AND explicit encoding announcement on Bluetooth devices
                    if (encoding in reportedEncodings) {
                        supported.add(codec)
                    }
                } else if (routeType.supportsNativeBitstream) {
                    supported.add(codec)
                }
            }
        }

        // Check multichannel PCM direct playback on HDMI / USB DAC
        if (routeType.supportsNativeBitstream && maxChannels >= 6) {
            val pcmMask = if (maxChannels >= 8) AudioFormat.CHANNEL_OUT_7POINT1_SURROUND else AudioFormat.CHANNEL_OUT_5POINT1
            val pcmFormat = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(48000)
                .setChannelMask(pcmMask)
                .build()
            if (checkDirectPlayback(pcmFormat, attrs, device, reportedEncodings, AudioFormat.ENCODING_PCM_16BIT)) {
                supported.add(AudioCodecFormat.PCM)
            }
        }

        return supported
    }

    private fun buildApiSpecificEncodings(): List<Pair<Int, AudioCodecFormat>> {
        val list = mutableListOf<Pair<Int, AudioCodecFormat>>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            list += AudioFormat.ENCODING_E_AC3_JOC to AudioCodecFormat.E_AC3_JOC
            list += AudioFormat.ENCODING_AC4 to AudioCodecFormat.AC4
            list += AudioFormat.ENCODING_DOLBY_TRUEHD to AudioCodecFormat.DOLBY_TRUEHD
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            list += AudioFormat.ENCODING_DOLBY_MAT to AudioCodecFormat.DOLBY_TRUEHD
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            list += AudioFormat.ENCODING_DTS_UHD_P1 to AudioCodecFormat.DTS_X
        }
        return list
    }

    private fun checkDirectPlayback(
        format: AudioFormat,
        attrs: AudioAttributes,
        device: AudioDeviceInfo,
        reportedEncodings: Set<Int>,
        encoding: Int
    ): Boolean {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                runCatching {
                    val support = AudioManager.getDirectPlaybackSupport(format, attrs)
                    support != AudioManager.DIRECT_PLAYBACK_NOT_SUPPORTED &&
                        (encoding in reportedEncodings || device.type == AudioDeviceInfo.TYPE_HDMI ||
                            device.type == AudioDeviceInfo.TYPE_HDMI_ARC ||
                            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && device.type == AudioDeviceInfo.TYPE_HDMI_EARC))
                }.getOrDefault(false)
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> {
                @Suppress("DEPRECATION")
                runCatching {
                    AudioTrack.isDirectPlaybackSupported(format, attrs) && encoding in reportedEncodings
                }.getOrDefault(false)
            }
            else -> encoding in reportedEncodings
        }
    }

    private fun mapEncodingsToFormats(
        encodings: Set<Int>,
        directCodecs: Set<AudioCodecFormat>
    ): Set<AudioCodecFormat> {
        val formats = mutableSetOf(AudioCodecFormat.PCM)
        formats.addAll(directCodecs)
        AudioCodecFormat.entries.forEach { codec ->
            if (codec.androidEncodings.any { it in encodings }) {
                formats.add(codec)
            }
        }
        return formats
    }

    private fun inspectSpatializer(): SpatializerReport {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S_V2) {
            return SpatializerReport(
                isAvailable = false,
                isEnabled = false,
                immersiveLevel = "Requires Android 12L+ (API 32)",
                isHeadTrackerAvailable = false,
                canSpatialize51Pcm = false,
                canSpatializeAtmosJoc = false
            )
        }
        return runCatching {
            val spatializer = audioManager.spatializer
            val levelName = when (spatializer.immersiveAudioLevel) {
                Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_MULTICHANNEL -> "Multichannel Spatializer"
                Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_NONE -> "None"
                Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_OTHER -> "Spatializer (Custom)"
                else -> if (spatializer.immersiveAudioLevel > Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_MULTICHANNEL) {
                    "Bed + Objects (Atmos-Ready)"
                } else {
                    "None"
                }
            }
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                .build()
            val pcm51 = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_5POINT1)
                .setSampleRate(48000)
                .build()
            val jocFormat = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_E_AC3_JOC)
                .setChannelMask(AudioFormat.CHANNEL_OUT_5POINT1)
                .setSampleRate(48000)
                .build()

            SpatializerReport(
                isAvailable = spatializer.isAvailable,
                isEnabled = spatializer.isEnabled,
                immersiveLevel = levelName,
                isHeadTrackerAvailable = spatializer.isHeadTrackerAvailable,
                canSpatialize51Pcm = spatializer.isAvailable && spatializer.isEnabled &&
                    spatializer.canBeSpatialized(attrs, pcm51),
                canSpatializeAtmosJoc = spatializer.isAvailable && spatializer.isEnabled &&
                    spatializer.canBeSpatialized(attrs, jocFormat)
            )
        }.getOrElse {
            SpatializerReport(false, false, "Unavailable", false, false, false)
        }
    }

    private fun inspectMediaCodecs(): List<AudioDecoderInfo> {
        val results = mutableListOf<AudioDecoderInfo>()
        val codecList = runCatching { MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos }
            .getOrDefault(emptyArray())

        for (info in codecList) {
            if (info.isEncoder) continue
            for (mime in info.supportedTypes) {
                if (!mime.startsWith("audio/", ignoreCase = true)) continue
                val caps = runCatching { info.getCapabilitiesForType(mime) }.getOrNull() ?: continue
                val audioCaps = caps.audioCapabilities ?: continue
                val isHardware = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    info.isHardwareAccelerated
                } else {
                    !info.name.startsWith("OMX.google.", ignoreCase = true) &&
                        !info.name.startsWith("c2.android.", ignoreCase = true)
                }
                val isSoftwareOnly = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    info.isSoftwareOnly
                } else {
                    !isHardware
                }
                val sampleRates = audioCaps.supportedSampleRateRanges
                val minRate = sampleRates.minOfOrNull { it.lower } ?: 8000
                val maxRate = sampleRates.maxOfOrNull { it.upper } ?: 48000

                results += AudioDecoderInfo(
                    codecName = info.name,
                    mimeType = mime.lowercase(),
                    isHardwareAccelerated = isHardware,
                    isSoftwareOnly = isSoftwareOnly,
                    maxChannelCount = audioCaps.maxInputChannelCount,
                    supportedSampleRates = minRate..maxRate
                )
            }
        }
        return results.sortedWith(
            compareByDescending<AudioDecoderInfo> { it.isHardwareAccelerated }
                .thenBy { it.mimeType }
                .thenByDescending { it.maxChannelCount }
        )
    }

    private fun inspectDisplayCapabilities(): DisplayCapabilitiesReport {
        val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
            ?: return DisplayCapabilitiesReport(false, listOf(HdrFormat.SDR), 60f, false)
        val hdrTypes = mutableListOf<HdrFormat>()
        val supportedHdrInts = display.hdrCapabilities?.supportedHdrTypes ?: intArrayOf()
        for (type in supportedHdrInts) {
            when (type) {
                Display.HdrCapabilities.HDR_TYPE_DOLBY_VISION -> hdrTypes += HdrFormat.DOLBY_VISION
                Display.HdrCapabilities.HDR_TYPE_HDR10_PLUS -> hdrTypes += HdrFormat.HDR10_PLUS
                Display.HdrCapabilities.HDR_TYPE_HDR10 -> hdrTypes += HdrFormat.HDR10
                Display.HdrCapabilities.HDR_TYPE_HLG -> hdrTypes += HdrFormat.HLG
            }
        }
        val refreshRate = display.mode?.refreshRate ?: 60f
        val seamless = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && display.supportedModes.size > 1
        return DisplayCapabilitiesReport(
            hdrSupported = hdrTypes.isNotEmpty(),
            supportedHdrTypes = hdrTypes.ifEmpty { listOf(HdrFormat.SDR) },
            refreshRateHz = refreshRate,
            seamlessFrameRateSwitchSupported = seamless
        )
    }

    private fun mapRouteType(type: Int): OutputRouteType {
        return when {
            type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> OutputRouteType.BUILTIN_SPEAKER
            type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                type == AudioDeviceInfo.TYPE_LINE_ANALOG ||
                type == AudioDeviceInfo.TYPE_LINE_DIGITAL -> OutputRouteType.WIRED_HEADSET
            type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                type == AudioDeviceInfo.TYPE_USB_ACCESSORY ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && type == AudioDeviceInfo.TYPE_USB_HEADSET) ->
                OutputRouteType.USB_DAC
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && type == AudioDeviceInfo.TYPE_HDMI_EARC ->
                OutputRouteType.HDMI_EARC
            type == AudioDeviceInfo.TYPE_HDMI_ARC -> OutputRouteType.HDMI_ARC
            type == AudioDeviceInfo.TYPE_HDMI -> OutputRouteType.HDMI
            type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> OutputRouteType.BLUETOOTH_A2DP
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                (type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                    type == AudioDeviceInfo.TYPE_BLE_SPEAKER ||
                    type == AudioDeviceInfo.TYPE_BLE_BROADCAST) -> OutputRouteType.BLUETOOTH_LE_AUDIO
            else -> OutputRouteType.OTHER
        }
    }

    private fun defaultChannelsForRoute(routeType: OutputRouteType): Int = when (routeType) {
        OutputRouteType.HDMI_EARC, OutputRouteType.HDMI -> 8
        OutputRouteType.HDMI_ARC -> 6
        OutputRouteType.USB_DAC -> 2
        else -> 2
    }

    private fun fallbackSpeakerReport() = OutputDeviceReport(
        id = 0,
        productName = "Device Speakers",
        routeType = OutputRouteType.BUILTIN_SPEAKER,
        isActiveDefault = true,
        maxChannels = 2,
        supportedSampleRates = listOf(48000),
        supportedEncodings = setOf(AudioFormat.ENCODING_PCM_16BIT),
        supportedFormats = setOf(AudioCodecFormat.PCM),
        supportsPassthrough = false,
        directPlaybackCodecs = emptySet()
    )
}
