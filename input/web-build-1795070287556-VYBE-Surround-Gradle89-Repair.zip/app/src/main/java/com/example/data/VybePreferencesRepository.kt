package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.audio.model.CinemaAspectMode
import com.example.audio.model.RoutingModePreference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.vybeDataStore: DataStore<Preferences> by preferencesDataStore(name = "vybe_surround_prefs")

data class VybeUserPreferences(
    val routingMode: RoutingModePreference = RoutingModePreference.AUTO_OPTIMAL,
    val cinemaAspectMode: CinemaAspectMode = CinemaAspectMode.ORIGINAL,
    val matchFrameRate: Boolean = true,
    val hdrModeEnabled: Boolean = true
)

class VybePreferencesRepository(private val context: Context) {

    private object Keys {
        val ROUTING_MODE = stringPreferencesKey("routing_mode")
        val CINEMA_ASPECT = stringPreferencesKey("cinema_aspect")
        val MATCH_FRAME_RATE = booleanPreferencesKey("match_frame_rate")
        val HDR_ENABLED = booleanPreferencesKey("hdr_enabled")
    }

    val preferencesFlow: Flow<VybeUserPreferences> = context.vybeDataStore.data.map { prefs ->
        val routing = prefs[Keys.ROUTING_MODE]
            ?.let { runCatching { RoutingModePreference.valueOf(it) }.getOrNull() }
            ?: RoutingModePreference.AUTO_OPTIMAL
        val aspect = prefs[Keys.CINEMA_ASPECT]
            ?.let { runCatching { CinemaAspectMode.valueOf(it) }.getOrNull() }
            ?: CinemaAspectMode.ORIGINAL
        VybeUserPreferences(
            routingMode = routing,
            cinemaAspectMode = aspect,
            matchFrameRate = prefs[Keys.MATCH_FRAME_RATE] ?: true,
            hdrModeEnabled = prefs[Keys.HDR_ENABLED] ?: true
        )
    }

    suspend fun setRoutingMode(mode: RoutingModePreference) {
        context.vybeDataStore.edit { it[Keys.ROUTING_MODE] = mode.name }
    }

    suspend fun setCinemaAspectMode(mode: CinemaAspectMode) {
        context.vybeDataStore.edit { it[Keys.CINEMA_ASPECT] = mode.name }
    }

    suspend fun setMatchFrameRate(enabled: Boolean) {
        context.vybeDataStore.edit { it[Keys.MATCH_FRAME_RATE] = enabled }
    }

    suspend fun setHdrEnabled(enabled: Boolean) {
        context.vybeDataStore.edit { it[Keys.HDR_ENABLED] = enabled }
    }
}
