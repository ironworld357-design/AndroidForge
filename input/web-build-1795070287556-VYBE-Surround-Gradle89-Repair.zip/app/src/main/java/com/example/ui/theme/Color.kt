package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianVoid = Color(0xFF07090D)
val AcousticSlate = Color(0xFF0E131C)
val TitaniumSurface = Color(0xFF151C28)
val TitaniumElevated = Color(0xFF1D2636)
val HairlineSlate = Color(0xFF283347)

val ElectricCyan = Color(0xFF22D3EE)
val DeepCyanContainer = Color(0xFF0E3A47)
val StudioAmber = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF3E2908)
val SignalEmerald = Color(0xFF34D399)
val EmeraldContainer = Color(0xFF0B3B2B)
val CrimsonAlert = Color(0xFFF87171)
val CrimsonContainer = Color(0xFF45161B)
val SlateDownmix = Color(0xFF94A3B8)
val SlateDownmixContainer = Color(0xFF1E293B)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF9AA8BE)
val TextMuted = Color(0xFF64748B)
