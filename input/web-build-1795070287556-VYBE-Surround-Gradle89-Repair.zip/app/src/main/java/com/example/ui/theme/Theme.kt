package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val VybeDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = ObsidianVoid,
    primaryContainer = DeepCyanContainer,
    onPrimaryContainer = TextPrimary,
    secondary = StudioAmber,
    onSecondary = ObsidianVoid,
    secondaryContainer = AmberContainer,
    onSecondaryContainer = StudioAmber,
    tertiary = SignalEmerald,
    onTertiary = ObsidianVoid,
    tertiaryContainer = EmeraldContainer,
    onTertiaryContainer = SignalEmerald,
    error = CrimsonAlert,
    onError = ObsidianVoid,
    errorContainer = CrimsonContainer,
    onErrorContainer = CrimsonAlert,
    background = ObsidianVoid,
    onBackground = TextPrimary,
    surface = AcousticSlate,
    onSurface = TextPrimary,
    surfaceVariant = TitaniumSurface,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = ObsidianVoid,
    surfaceContainerLow = AcousticSlate,
    surfaceContainer = TitaniumSurface,
    surfaceContainerHigh = TitaniumElevated,
    surfaceContainerHighest = HairlineSlate,
    outline = HairlineSlate,
    outlineVariant = ColorTokens.SubtleBorder
)

private object ColorTokens {
    val SubtleBorder = HairlineSlate.copy(alpha = 0.55f)
}

val VybeShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun VybeSurroundTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = false
                isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = VybeDarkColorScheme,
        typography = VybeTypography,
        shapes = VybeShapes,
        content = content
    )
}
