package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.SettingsInputHdmi
import androidx.compose.material.icons.outlined.Theaters
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.SettingsInputHdmi
import androidx.compose.material.icons.rounded.Theaters
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.CinemaScreen
import com.example.ui.screens.ConsoleScreen
import com.example.ui.screens.DevicesScreen
import com.example.ui.screens.VerifyScreen
import com.example.ui.state.VybeViewModel
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.VybeSurroundTheme

const val ROUTE_CONSOLE = "console"
const val ROUTE_CINEMA = "cinema"
const val ROUTE_DEVICES = "devices"
const val ROUTE_VERIFY = "verify"

private data class VybeNavItem(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val vybeNavItems = listOf(
    VybeNavItem(ROUTE_CONSOLE, R.string.nav_console, Icons.Rounded.GraphicEq, Icons.Outlined.GraphicEq),
    VybeNavItem(ROUTE_CINEMA, R.string.nav_cinema, Icons.Rounded.Theaters, Icons.Outlined.Theaters),
    VybeNavItem(ROUTE_DEVICES, R.string.nav_routing, Icons.Rounded.SettingsInputHdmi, Icons.Outlined.SettingsInputHdmi),
    VybeNavItem(ROUTE_VERIFY, R.string.nav_diagnostics, Icons.Rounded.Verified, Icons.Outlined.Verified)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VybeSurroundTheme {
                VybeSurroundApp()
            }
        }
    }
}

@Composable
fun VybeSurroundApp(
    viewModel: VybeViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_CONSOLE

    var isCinemaFullscreen by remember { mutableStateOf(false) }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                viewModel.playPickedMediaUri(uri, "Selected Video")
                navController.navigate(ROUTE_CINEMA) {
                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        }
    )

    val audioDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            if (uri != null) {
                viewModel.playPickedMediaUri(uri, "Local Surround Media")
            }
        }
    )

    val launchVideoPicker = {
        videoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
    }

    val launchDocumentPicker = {
        audioDocumentLauncher.launch(
            arrayOf("audio/*", "video/*", "application/octet-stream")
        )
    }

    val navigateTo: (String) -> Unit = { route ->
        if (route != ROUTE_CINEMA) {
            isCinemaFullscreen = false
        }
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = if (isCinemaFullscreen && currentRoute == ROUTE_CINEMA) {
                WindowInsets(0, 0, 0, 0)
            } else {
                WindowInsets.safeDrawing
            },
            bottomBar = {
                if (!useRail && !(isCinemaFullscreen && currentRoute == ROUTE_CINEMA)) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 4.dp
                    ) {
                        vybeNavItems.forEach { item ->
                            val selected = currentRoute == item.route
                            val label = stringResource(item.labelRes)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ElectricCyan,
                                    selectedTextColor = ElectricCyan,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                modifier = Modifier.testTag("nav_tab_${item.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail && !(isCinemaFullscreen && currentRoute == ROUTE_CINEMA)) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        vybeNavItems.forEach { item ->
                            val selected = currentRoute == item.route
                            val label = stringResource(item.labelRes)
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = ElectricCyan,
                                    selectedTextColor = ElectricCyan,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                modifier = Modifier.testTag("nav_rail_${item.route}")
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_CONSOLE,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(ROUTE_CONSOLE) {
                        ConsoleScreen(
                            state = state,
                            onPickVideo = launchVideoPicker,
                            onPickAudioOrContainer = launchDocumentPicker,
                            onPlayStreamUrl = viewModel::playStreamUrl,
                            onPlayReferenceTrack = viewModel::playReferenceTrack,
                            onTogglePlayPause = viewModel::togglePlayPause,
                            onSpeakerTap = viewModel::pingSpeaker,
                            onSelectRoutingMode = viewModel::setRoutingMode,
                            onSelectAudioTrack = viewModel::selectAudioTrack,
                            onDismissRouteBanner = viewModel::dismissRouteBanner
                        )
                    }

                    composable(ROUTE_CINEMA) {
                        CinemaScreen(
                            state = state,
                            exoPlayer = viewModel.playerManager.getOrCreatePlayer(),
                            isImmersiveFullscreen = isCinemaFullscreen,
                            onSetImmersiveFullscreen = { isCinemaFullscreen = it },
                            onPickVideo = launchVideoPicker,
                            onTogglePlayPause = viewModel::togglePlayPause,
                            onSeekTo = viewModel::seekTo,
                            onSetAspectMode = viewModel::setCinemaAspectMode,
                            onSetMatchFrameRate = viewModel::setMatchFrameRate,
                            onSetHdrEnabled = viewModel::setHdrEnabled,
                            onSelectAudioTrack = viewModel::selectAudioTrack
                        )
                    }

                    composable(ROUTE_DEVICES) {
                        DevicesScreen(
                            state = state,
                            onRefreshHardware = viewModel::refreshHardwareAndValidate
                        )
                    }

                    composable(ROUTE_VERIFY) {
                        VerifyScreen(
                            state = state,
                            onRunValidation = viewModel::runHardwareValidation,
                            onSpeakerPing = viewModel::pingSpeaker
                        )
                    }
                }
            }
        }
    }
}
