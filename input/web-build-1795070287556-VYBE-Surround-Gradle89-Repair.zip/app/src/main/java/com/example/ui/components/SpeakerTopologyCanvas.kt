package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Hearing
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.audio.model.ChannelLayout
import com.example.audio.model.SpeakerActivity
import com.example.audio.model.SpeakerChannel
import com.example.audio.model.SpeakerNodeState
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.HairlineSlate
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SlateDownmix
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.TitaniumSurface
import kotlin.math.roundToInt

/**
 * Interactive acoustic soundstage diagram displaying active discrete channels,
 * downmixed channels, spatialized virtual nodes, and height channels.
 * Tapping any node fires an isolated channel test tone.
 */
@Composable
fun SpeakerTopologyCard(
    nodes: List<SpeakerNodeState>,
    sourceLayout: ChannelLayout,
    outputLayout: ChannelLayout,
    isPlaying: Boolean,
    downmixApplied: Boolean,
    atmosActive: Boolean,
    lastPingedSpeaker: SpeakerChannel?,
    onSpeakerTap: (SpeakerChannel) -> Unit,
    modifier: Modifier = Modifier
) {
    val nodeMap = nodes.associateBy { it.channel }
    val pulseTransition = rememberInfiniteTransition(label = "acoustic_pulse")
    val pulseProgress by pulseTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_ring"
    )

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.large)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "ACOUSTIC STAGE TOPOLOGY",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = "${sourceLayout.label} → ${outputLayout.label}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Text(
                        text = if (atmosActive) "OBJECTS + BED" else "TAP SPEAKER TO PING",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (atmosActive) StudioAmber else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(276.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                TitaniumSurface,
                                ObsidianVoid
                            )
                        )
                    )
                    .border(1.dp, HairlineSlate.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            ) {
                val widthPx = with(LocalDensity.current) { maxWidth.toPx() }
                val heightPx = with(LocalDensity.current) { maxHeight.toPx() }
                val center = Offset(widthPx * 0.5f, heightPx * 0.54f)

                val positions = mapOf(
                    SpeakerChannel.FL to Offset(widthPx * 0.17f, heightPx * 0.18f),
                    SpeakerChannel.FC to Offset(widthPx * 0.50f, heightPx * 0.14f),
                    SpeakerChannel.FR to Offset(widthPx * 0.83f, heightPx * 0.18f),
                    SpeakerChannel.LFE to Offset(widthPx * 0.68f, heightPx * 0.28f),
                    SpeakerChannel.TFL to Offset(widthPx * 0.34f, heightPx * 0.32f),
                    SpeakerChannel.TFR to Offset(widthPx * 0.66f, heightPx * 0.32f),
                    SpeakerChannel.SL to Offset(widthPx * 0.13f, heightPx * 0.54f),
                    SpeakerChannel.SR to Offset(widthPx * 0.87f, heightPx * 0.54f),
                    SpeakerChannel.BL to Offset(widthPx * 0.25f, heightPx * 0.84f),
                    SpeakerChannel.BC to Offset(widthPx * 0.50f, heightPx * 0.88f),
                    SpeakerChannel.BR to Offset(widthPx * 0.75f, heightPx * 0.84f)
                )

                val cyanColor = ElectricCyan
                val amberColor = StudioAmber
                val emeraldColor = SignalEmerald
                val downmixColor = SlateDownmix
                val hairlineColor = HairlineSlate

                Canvas(modifier = Modifier.fillMaxSize()) {
                    // Acoustic stage concentric reference rings
                    val maxRadius = minOf(size.width, size.height) * 0.42f
                    listOf(0.45f, 0.75f, 1.0f).forEach { factor ->
                        drawCircle(
                            color = hairlineColor.copy(alpha = 0.45f),
                            radius = maxRadius * factor,
                            center = center,
                            style = Stroke(width = 1.2f)
                        )
                    }

                    // Active acoustic pulse ring during playback
                    if (isPlaying) {
                        drawCircle(
                            color = cyanColor.copy(alpha = (1f - pulseProgress) * 0.35f),
                            radius = maxRadius * pulseProgress,
                            center = center,
                            style = Stroke(width = 2.5f)
                        )
                    }

                    // Draw screen line at front of room
                    drawLine(
                        color = amberColor.copy(alpha = 0.35f),
                        start = Offset(size.width * 0.22f, size.height * 0.05f),
                        end = Offset(size.width * 0.78f, size.height * 0.05f),
                        strokeWidth = 3f
                    )

                    val flPos = positions[SpeakerChannel.FL] ?: center
                    val frPos = positions[SpeakerChannel.FR] ?: center

                    // Draw signal vectors from active/downmixed nodes
                    positions.forEach { (channel, pos) ->
                        val activity = nodeMap[channel]?.activity ?: SpeakerActivity.INACTIVE
                        when (activity) {
                            SpeakerActivity.ACTIVE_DISCRETE -> {
                                val lineColor = if (channel == SpeakerChannel.TFL || channel == SpeakerChannel.TFR) amberColor else cyanColor
                                drawLine(
                                    color = lineColor.copy(alpha = 0.48f),
                                    start = pos,
                                    end = center,
                                    strokeWidth = 2.2f
                                )
                            }
                            SpeakerActivity.SPATIALIZED_VIRTUAL -> {
                                drawLine(
                                    color = emeraldColor.copy(alpha = 0.45f),
                                    start = pos,
                                    end = center,
                                    strokeWidth = 2f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f))
                                )
                            }
                            SpeakerActivity.DOWNMIXED_TO_STEREO -> {
                                val target = when (channel) {
                                    SpeakerChannel.SL, SpeakerChannel.BL -> flPos
                                    SpeakerChannel.SR, SpeakerChannel.BR -> frPos
                                    else -> if (pos.x <= center.x) flPos else frPos
                                }
                                drawLine(
                                    color = downmixColor.copy(alpha = 0.45f),
                                    start = pos,
                                    end = target,
                                    strokeWidth = 1.6f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                                )
                            }
                            SpeakerActivity.INACTIVE -> Unit
                        }
                    }
                }

                // Listener sweet-spot badge
                Surface(
                    modifier = Modifier
                        .offset {
                            IntOffset(
                                (center.x - 20.dp.toPx()).roundToInt(),
                                (center.y - 20.dp.toPx()).roundToInt()
                            )
                        }
                        .size(40.dp),
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.5f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Rounded.Hearing,
                            contentDescription = "Sweet spot listener position",
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Interactive Speaker Nodes (48dp touch target)
                positions.forEach { (channel, pos) ->
                    val activity = nodeMap[channel]?.activity ?: SpeakerActivity.INACTIVE
                    // Hide height nodes unless Atmos is active or source is Atmos
                    val showNode = if (channel == SpeakerChannel.TFL || channel == SpeakerChannel.TFR) {
                        activity != SpeakerActivity.INACTIVE
                    } else true

                    if (showNode) {
                        val isPinged = lastPingedSpeaker == channel
                        val nodeSize = 48.dp
                        val halfPx = with(LocalDensity.current) { (nodeSize / 2).toPx() }

                        SpeakerNodePill(
                            channel = channel,
                            activity = activity,
                            isPinged = isPinged,
                            onClick = { onSpeakerTap(channel) },
                            modifier = Modifier
                                .offset {
                                    IntOffset(
                                        (pos.x - halfPx).roundToInt(),
                                        (pos.y - halfPx).roundToInt()
                                    )
                                }
                                .size(nodeSize)
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Legend row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TopologyLegendChip(color = ElectricCyan, label = "Discrete")
                Spacer(Modifier.width(12.dp))
                TopologyLegendChip(color = SignalEmerald, label = "Spatialized")
                Spacer(Modifier.width(12.dp))
                TopologyLegendChip(
                    color = SlateDownmix,
                    label = if (downmixApplied) "Downmixed → 2.0" else "Downmix Target"
                )
                Spacer(Modifier.width(12.dp))
                TopologyLegendChip(color = HairlineSlate, label = "Silent")
            }
        }
    }
}

@Composable
private fun SpeakerNodePill(
    channel: SpeakerChannel,
    activity: SpeakerActivity,
    isPinged: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = when {
        isPinged -> StudioAmber
        activity == SpeakerActivity.ACTIVE_DISCRETE ->
            if (channel == SpeakerChannel.TFL || channel == SpeakerChannel.TFR) StudioAmber else ElectricCyan
        activity == SpeakerActivity.SPATIALIZED_VIRTUAL -> SignalEmerald
        activity == SpeakerActivity.DOWNMIXED_TO_STEREO -> SlateDownmix
        else -> HairlineSlate
    }

    val containerAlpha = when (activity) {
        SpeakerActivity.ACTIVE_DISCRETE -> 0.24f
        SpeakerActivity.SPATIALIZED_VIRTUAL -> 0.20f
        SpeakerActivity.DOWNMIXED_TO_STEREO -> 0.16f
        SpeakerActivity.INACTIVE -> 0.45f
    }

    val bgColor = if (activity == SpeakerActivity.INACTIVE && !isPinged) {
        ObsidianVoid.copy(alpha = 0.85f)
    } else {
        accent.copy(alpha = containerAlpha)
    }

    Box(
        modifier = modifier
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .testTag("speaker_node_${channel.code.lowercase()}")
            .semantics { contentDescription = "Test ${channel.fullName} speaker channel" },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(if (channel == SpeakerChannel.LFE) 38.dp else 36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(bgColor)
                .border(
                    width = if (isPinged || activity == SpeakerActivity.ACTIVE_DISCRETE) 1.5.dp else 1.dp,
                    color = if (activity == SpeakerActivity.INACTIVE && !isPinged) HairlineSlate else accent,
                    shape = RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = channel.code,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = if (activity == SpeakerActivity.INACTIVE && !isPinged) {
                    MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)
                } else {
                    MaterialTheme.colorScheme.onSurface
                }
            )
        }
    }
}

@Composable
private fun TopologyLegendChip(color: androidx.compose.ui.graphics.Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(5.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
