package com.example.ui.screens

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Build
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.HdrOn
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.R
import com.example.audio.model.AudioTrackOption
import com.example.audio.model.CinemaAspectMode
import com.example.audio.model.HdrFormat
import com.example.ui.components.formatTimeMs
import com.example.ui.components.statusColorsFor
import com.example.ui.state.VybeUiState
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.StudioAmber

/**
 * Dedicated IMAX-inspired Expanded Cinema Viewing Mode.
 * Preserves original aspect ratio without stretching, supports Original/Fit/Fill/Crop,
 * HDR color mode when supported, native frame rate matching, and minimal immersive HUD.
 * Never claims official IMAX Enhanced certification.
 */
@OptIn(UnstableApi::class)
@Composable
fun CinemaScreen(
    state: VybeUiState,
    exoPlayer: ExoPlayer,
    isImmersiveFullscreen: Boolean,
    onSetImmersiveFullscreen: (Boolean) -> Unit,
    onPickVideo: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSetAspectMode: (CinemaAspectMode) -> Unit,
    onSetMatchFrameRate: (Boolean) -> Unit,
    onSetHdrEnabled: (Boolean) -> Unit,
    onSelectAudioTrack: (AudioTrackOption) -> Unit,
    modifier: Modifier = Modifier
) {
    val view = LocalView.current
    val context = LocalContext.current
    var hudVisible by remember { mutableStateOf(true) }

    BackHandler(enabled = isImmersiveFullscreen) {
        onSetImmersiveFullscreen(false)
    }

    // Manage HDR window color mode & immersive system bars cleanly
    LaunchedEffect(state.preferences.hdrModeEnabled, state.sourceVideo.hdrFormat, state.displayCaps.hdrSupported) {
        val window = (context as? Activity)?.window ?: return@LaunchedEffect
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val useHdr = state.preferences.hdrModeEnabled &&
                state.displayCaps.hdrSupported &&
                state.sourceVideo.hdrFormat != HdrFormat.SDR
            window.colorMode = if (useHdr) {
                ActivityInfo.COLOR_MODE_HDR
            } else {
                ActivityInfo.COLOR_MODE_DEFAULT
            }
        }
    }

    DisposableEffect(isImmersiveFullscreen) {
        val window = (context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        if (isImmersiveFullscreen) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && window != null) {
                window.colorMode = ActivityInfo.COLOR_MODE_DEFAULT
            }
        }
    }

    val resizeMode = when (state.preferences.cinemaAspectMode) {
        CinemaAspectMode.ORIGINAL, CinemaAspectMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        CinemaAspectMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        CinemaAspectMode.CROP -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    }

    val resolution = state.resolution
    val statusAccent = resolution?.let { statusColorsFor(it.status).first } ?: ElectricCyan

    if (isImmersiveFullscreen) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(ObsidianVoid)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { hudVisible = !hudVisible }
        ) {
            CinemaViewport(
                exoPlayer = exoPlayer,
                hasVideo = state.sourceVideo.hasVideo,
                aspectMode = state.preferences.cinemaAspectMode,
                nativeAspectRatio = state.sourceVideo.aspectRatio,
                resizeMode = resizeMode,
                onPickVideo = onPickVideo,
                modifier = Modifier.fillMaxSize()
            )

            AnimatedVisibility(
                visible = hudVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    ObsidianVoid.copy(alpha = 0.72f),
                                    Color.Transparent,
                                    ObsidianVoid.copy(alpha = 0.85f)
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    // Minimal Top Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = state.sourceAudio.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = resolution?.playbackModeSummary ?: "Cinema Scope Mode",
                                style = MaterialTheme.typography.labelSmall,
                                color = statusAccent
                            )
                        }
                        IconButton(
                            onClick = { onSetImmersiveFullscreen(false) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("cinema_exit_fullscreen_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FullscreenExit,
                                contentDescription = "Exit fullscreen cinema mode",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Minimal Bottom Transport
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                    ) {
                        if (state.durationMs > 0L) {
                            Slider(
                                value = state.positionMs.toFloat(),
                                onValueChange = { onSeekTo(it.toLong()) },
                                valueRange = 0f..state.durationMs.toFloat().coerceAtLeast(1f)
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onTogglePlayPause,
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = if (state.isPlaying) "Pause" else "Play",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                CinemaAspectMode.entries.forEach { mode ->
                                    FilterChip(
                                        selected = state.preferences.cinemaAspectMode == mode,
                                        onClick = { onSetAspectMode(mode) },
                                        label = { Text(mode.shortLabel) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 880.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "EXPANDED THEATER VIEW",
                    style = MaterialTheme.typography.labelMedium,
                    color = StudioAmber
                )
                Text(
                    text = "Cinema Scope Mode",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            IconButton(
                onClick = { onSetImmersiveFullscreen(true) },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("cinema_fullscreen_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Fullscreen,
                    contentDescription = "Enter fullscreen cinema mode",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Video Theater Stage
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 880.dp),
            shape = MaterialTheme.shapes.large,
            color = ObsidianVoid,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(
                        if (state.preferences.cinemaAspectMode == CinemaAspectMode.CROP) 2.39f else 16f / 9f
                    )
                    .clipToBounds()
            ) {
                CinemaViewport(
                    exoPlayer = exoPlayer,
                    hasVideo = state.sourceVideo.hasVideo,
                    aspectMode = state.preferences.cinemaAspectMode,
                    nativeAspectRatio = state.sourceVideo.aspectRatio,
                    resizeMode = resizeMode,
                    onPickVideo = onPickVideo,
                    modifier = Modifier.fillMaxSize()
                )

                // Subtle Cinema Badges
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (state.sourceVideo.hasVideo) {
                        CinemaBadge("${state.sourceVideo.width}×${state.sourceVideo.height}")
                        if (state.sourceVideo.frameRate > 0f) {
                            CinemaBadge("${"%.2f".format(state.sourceVideo.frameRate)} fps")
                        }
                        CinemaBadge(
                            text = state.sourceVideo.hdrFormat.label,
                            accent = if (state.sourceVideo.hdrFormat != HdrFormat.SDR) StudioAmber else null
                        )
                    }
                    if (resolution != null) {
                        CinemaBadge(text = resolution.status.label, accent = statusAccent)
                    }
                }
            }
        }

        // Transport + Seekbar when media loaded
        if (state.sourceAudio.hasMediaLoaded) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 880.dp),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            onClick = onTogglePlayPause,
                            shape = CircleShape,
                            color = statusAccent,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("cinema_play_pause_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = if (state.isPlaying) "Pause" else "Play",
                                    tint = ObsidianVoid
                                )
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = state.sourceAudio.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${formatTimeMs(state.positionMs)} / ${formatTimeMs(state.durationMs)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (state.durationMs > 0L) {
                        Slider(
                            value = state.positionMs.toFloat(),
                            onValueChange = { onSeekTo(it.toLong()) },
                            valueRange = 0f..state.durationMs.toFloat().coerceAtLeast(1f),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Aspect Ratio Framing Controls (Never stretches pixel aspect ratio!)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 880.dp),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surfaceContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.AspectRatio,
                        contentDescription = null,
                        tint = StudioAmber,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "PROPORTIONAL ASPECT RATIO FRAMING",
                        style = MaterialTheme.typography.labelMedium,
                        color = StudioAmber
                    )
                }
                Spacer(Modifier.height(10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CinemaAspectMode.entries.forEach { mode ->
                        FilterChip(
                            selected = state.preferences.cinemaAspectMode == mode,
                            onClick = { onSetAspectMode(mode) },
                            label = { Text(mode.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                selectedLabelColor = StudioAmber
                            ),
                            modifier = Modifier.testTag("aspect_mode_${mode.name.lowercase()}")
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Pixel aspect ratio remains locked 1:1 — video is never stretched horizontally or vertically.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // HDR & Frame Rate Preservation
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 880.dp),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surfaceContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "CINEMA DISPLAY & MOTION PROFILE",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Preserve Original Frame Rate",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (state.displayCaps.seamlessFrameRateSwitchSupported) {
                                    "Display supports seamless refresh switching (${state.displayCaps.refreshRateHz.toInt()} Hz)"
                                } else {
                                    "Uses Media3 seamless frame-rate strategy when panel allows"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = state.preferences.matchFrameRate,
                        onCheckedChange = onSetMatchFrameRate,
                        modifier = Modifier.testTag("cinema_match_fps_switch")
                    )
                }

                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = Icons.Rounded.HdrOn,
                            contentDescription = null,
                            tint = StudioAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "High-Dynamic-Range (HDR) Pipeline",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Panel: ${state.displayCaps.supportedHdrTypes.joinToString { it.label }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = state.preferences.hdrModeEnabled,
                        onCheckedChange = onSetHdrEnabled,
                        modifier = Modifier.testTag("cinema_hdr_switch")
                    )
                }

                if (state.audioTracks.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = "AUDIO TRACKS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        state.audioTracks.forEachIndexed { idx, track ->
                            FilterChip(
                                selected = track.isSelected,
                                onClick = { onSelectAudioTrack(track) },
                                label = { Text(track.label) },
                                modifier = Modifier.testTag("cinema_audio_track_$idx")
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun CinemaViewport(
    exoPlayer: ExoPlayer,
    hasVideo: Boolean,
    aspectMode: CinemaAspectMode,
    nativeAspectRatio: Float,
    resizeMode: Int,
    onPickVideo: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(ObsidianVoid)
            .clipToBounds(),
        contentAlignment = Alignment.Center
    ) {
        if (hasVideo) {
            val frameModifier = if (aspectMode == CinemaAspectMode.ORIGINAL && nativeAspectRatio > 0.1f) {
                Modifier
                    .fillMaxSize()
                    .aspectRatio(nativeAspectRatio, matchHeightConstraintsFirst = false)
            } else {
                Modifier.fillMaxSize()
            }

            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        useController = false
                        keepScreenOn = true
                        player = exoPlayer
                        this.resizeMode = resizeMode
                    }
                },
                update = { pv ->
                    if (pv.player !== exoPlayer) {
                        pv.player = exoPlayer
                    }
                    if (pv.resizeMode != resizeMode) {
                        pv.resizeMode = resizeMode
                    }
                },
                modifier = frameModifier.testTag("cinema_player_view")
            )
        } else {
            Image(
                painter = painterResource(id = R.drawable.img_cinema_stage_1795063901743),
                contentDescription = "Private cinema theater stage",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ObsidianVoid.copy(alpha = 0.58f))
            )
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(20.dp)
            ) {
                Text(
                    text = "Theater Stage Ready",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Load a local HDR/multichannel video to project in Cinema Scope Mode.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onPickVideo,
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
                    modifier = Modifier.testTag("cinema_load_video_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Movie,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Select Video")
                }
            }
        }
    }
}

@Composable
private fun CinemaBadge(
    text: String,
    accent: Color? = null
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = ObsidianVoid.copy(alpha = 0.78f),
        border = BorderStroke(1.dp, (accent ?: MaterialTheme.colorScheme.outlineVariant).copy(alpha = 0.7f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = accent ?: MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
        )
    }
}
