package com.example.audio.engine

import android.content.Context
import android.net.Uri
import com.example.audio.model.ChannelLayout
import com.example.audio.model.SpeakerChannel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

/**
 * Generates genuine multi-channel WAVEFORMATEXTENSIBLE PCM audio files with exact channel masks
 * (2.0, 2.1, 5.1, 6.1, 7.1) and distinct acoustic identification sweeps per speaker slot so
 * ExoPlayer & Android AudioTrack exercise real multichannel decoding, spatialization, or downmixing.
 */
object MultichannelTestSynthesizer {

    private const val SAMPLE_RATE = 48000
    private const val BITS_PER_SAMPLE = 16

    data class GeneratedReferenceTrack(
        val id: String,
        val title: String,
        val subtitle: String,
        val layout: ChannelLayout,
        val uri: Uri,
        val sampleRateHz: Int = SAMPLE_RATE,
        val bitrateBps: Int
    )

    suspend fun generateReferenceSuite(context: Context): List<GeneratedReferenceTrack> = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "vybe_reference_pcm").apply { mkdirs() }
        val specs = listOf(
            Triple("ref_2_0", "Reference 2.0 Stereo Sweep", ChannelLayout.STEREO),
            Triple("ref_2_1", "Reference 2.1 Stereo + LFE", ChannelLayout.SURROUND_2_1),
            Triple("ref_5_1", "Reference 5.1 Surround Matrix", ChannelLayout.SURROUND_5_1),
            Triple("ref_6_1", "Reference 6.1 Surround Matrix", ChannelLayout.SURROUND_6_1),
            Triple("ref_7_1", "Reference 7.1 Theater Matrix", ChannelLayout.SURROUND_7_1)
        )

        specs.map { (id, title, layout) ->
            val file = File(dir, "$id.wav")
            if (!file.exists() || file.length() < 1024) {
                writeMultichannelSweepWav(file, layout)
            }
            val bitrate = SAMPLE_RATE * layout.channelCount * BITS_PER_SAMPLE
            GeneratedReferenceTrack(
                id = id,
                title = title,
                subtitle = "${layout.channelCount}ch PCM • 48 kHz • Mask 0x${layout.waveChannelMask.toString(16).uppercase()}",
                layout = layout,
                uri = Uri.fromFile(file),
                sampleRateHz = SAMPLE_RATE,
                bitrateBps = bitrate
            )
        }
    }

    suspend fun generateIsolatedSpeakerFile(
        context: Context,
        targetChannel: SpeakerChannel,
        layout: ChannelLayout
    ): Uri = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "vybe_speaker_pings").apply { mkdirs() }
        val file = File(dir, "ping_${layout.name}_${targetChannel.code}.wav")
        val slots = channelOrderForLayout(layout)
        val targetSlotIndex = slots.indexOf(targetChannel).let { if (it >= 0) it else 0 }
        val durationSec = 1.4
        val totalFrames = (SAMPLE_RATE * durationSec).toInt()
        val numChannels = layout.channelCount
        val dataBytes = totalFrames * numChannels * 2

        FileOutputStream(file).use { out ->
            out.write(buildWaveFormatExtensibleHeader(numChannels, layout.waveChannelMask, dataBytes))
            val buffer = ByteBuffer.allocate(4096 * numChannels * 2).order(ByteOrder.LITTLE_ENDIAN)
            val freq = frequencyForChannel(targetChannel)

            var frame = 0
            while (frame < totalFrames) {
                buffer.clear()
                val chunk = minOf(4096, totalFrames - frame)
                for (i in 0 until chunk) {
                    val t = (frame + i).toDouble() / SAMPLE_RATE
                    val env = envelope(t, durationSec)
                    val sampleVal = (sin(2.0 * PI * freq * t) * env * 0.48 * Short.MAX_VALUE).toInt()
                        .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                    for (ch in 0 until numChannels) {
                        buffer.putShort(if (ch == targetSlotIndex) sampleVal else 0)
                    }
                }
                out.write(buffer.array(), 0, chunk * numChannels * 2)
                frame += chunk
            }
        }
        Uri.fromFile(file)
    }

    private fun writeMultichannelSweepWav(file: File, layout: ChannelLayout) {
        val slots = channelOrderForLayout(layout)
        val numChannels = layout.channelCount
        val slotDuration = 1.0
        val totalDuration = (slots.size * slotDuration).coerceAtLeast(3.0)
        val totalFrames = (SAMPLE_RATE * totalDuration).toInt()
        val dataBytes = totalFrames * numChannels * 2

        FileOutputStream(file).use { out ->
            out.write(buildWaveFormatExtensibleHeader(numChannels, layout.waveChannelMask, dataBytes))
            val chunkFrames = 2048
            val buffer = ByteBuffer.allocate(chunkFrames * numChannels * 2).order(ByteOrder.LITTLE_ENDIAN)

            var frame = 0
            while (frame < totalFrames) {
                buffer.clear()
                val count = minOf(chunkFrames, totalFrames - frame)
                for (i in 0 until count) {
                    val globalTime = (frame + i).toDouble() / SAMPLE_RATE
                    val activeSlot = ((globalTime / slotDuration).toInt()) % slots.size
                    val localTime = globalTime % slotDuration
                    val channel = slots[activeSlot]
                    val freq = frequencyForChannel(channel)
                    val env = envelope(localTime, slotDuration)
                    // Gentle warm chord harmonic for non-LFE channels
                    val wave = if (channel == SpeakerChannel.LFE) {
                        sin(2.0 * PI * 65.0 * globalTime)
                    } else {
                        0.75 * sin(2.0 * PI * freq * globalTime) +
                            0.25 * sin(2.0 * PI * (freq * 1.5) * globalTime)
                    }
                    val sample = (wave * env * 0.42 * Short.MAX_VALUE).toInt()
                        .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()

                    for (ch in 0 until numChannels) {
                        buffer.putShort(if (ch == activeSlot) sample else 0)
                    }
                }
                out.write(buffer.array(), 0, count * numChannels * 2)
                frame += count
            }
        }
    }

    private fun channelOrderForLayout(layout: ChannelLayout): List<SpeakerChannel> = when (layout) {
        ChannelLayout.MONO -> listOf(SpeakerChannel.FC)
        ChannelLayout.STEREO -> listOf(SpeakerChannel.FL, SpeakerChannel.FR)
        ChannelLayout.SURROUND_2_1 -> listOf(SpeakerChannel.FL, SpeakerChannel.FR, SpeakerChannel.LFE)
        ChannelLayout.QUAD -> listOf(SpeakerChannel.FL, SpeakerChannel.FR, SpeakerChannel.SL, SpeakerChannel.SR)
        ChannelLayout.SURROUND_5_0 -> listOf(
            SpeakerChannel.FL, SpeakerChannel.FR, SpeakerChannel.FC, SpeakerChannel.SL, SpeakerChannel.SR
        )
        ChannelLayout.SURROUND_5_1 -> listOf(
            SpeakerChannel.FL, SpeakerChannel.FR, SpeakerChannel.FC,
            SpeakerChannel.LFE, SpeakerChannel.SL, SpeakerChannel.SR
        )
        ChannelLayout.SURROUND_6_1 -> listOf(
            SpeakerChannel.FL, SpeakerChannel.FR, SpeakerChannel.FC,
            SpeakerChannel.LFE, SpeakerChannel.BC, SpeakerChannel.SL, SpeakerChannel.SR
        )
        ChannelLayout.SURROUND_7_1, ChannelLayout.ATMOS_7_1_4 -> listOf(
            SpeakerChannel.FL, SpeakerChannel.FR, SpeakerChannel.FC,
            SpeakerChannel.LFE, SpeakerChannel.BL, SpeakerChannel.BR, SpeakerChannel.SL, SpeakerChannel.SR
        )
    }

    private fun frequencyForChannel(channel: SpeakerChannel): Double = when (channel) {
        SpeakerChannel.FL -> 329.63 // E4
        SpeakerChannel.FC -> 440.00 // A4
        SpeakerChannel.FR -> 523.25 // C5
        SpeakerChannel.LFE -> 65.41 // C2 sub-bass
        SpeakerChannel.SL -> 392.00 // G4
        SpeakerChannel.SR -> 587.33 // D5
        SpeakerChannel.BC -> 493.88 // B4
        SpeakerChannel.BL -> 349.23 // F4
        SpeakerChannel.BR -> 659.25 // E5
        SpeakerChannel.TFL -> 783.99 // G5
        SpeakerChannel.TFR -> 880.00 // A5
    }

    private fun envelope(t: Double, duration: Double): Double {
        val attack = 0.04
        val release = 0.12
        return when {
            t < attack -> t / attack
            t > duration - release -> ((duration - t) / release).coerceAtLeast(0.0)
            else -> 1.0
        }
    }

    /**
     * Builds a 68-byte RIFF WAVEFORMATEXTENSIBLE header with exact speaker channel mask.
     */
    private fun buildWaveFormatExtensibleHeader(
        channels: Int,
        channelMask: Int,
        dataSizeBytes: Int
    ): ByteArray {
        val byteRate = SAMPLE_RATE * channels * (BITS_PER_SAMPLE / 8)
        val blockAlign = channels * (BITS_PER_SAMPLE / 8)
        val fmtChunkSize = 40 // WAVEFORMATEXTENSIBLE
        val totalSize = 4 + (8 + fmtChunkSize) + (8 + dataSizeBytes)

        val buf = ByteBuffer.allocate(68).order(ByteOrder.LITTLE_ENDIAN)
        // RIFF header
        buf.put("RIFF".toByteArray(Charsets.US_ASCII))
        buf.putInt(totalSize)
        buf.put("WAVE".toByteArray(Charsets.US_ASCII))
        // fmt chunk
        buf.put("fmt ".toByteArray(Charsets.US_ASCII))
        buf.putInt(fmtChunkSize)
        buf.putShort(0xFFFE.toShort()) // WAVE_FORMAT_EXTENSIBLE
        buf.putShort(channels.toShort())
        buf.putInt(SAMPLE_RATE)
        buf.putInt(byteRate)
        buf.putShort(blockAlign.toShort())
        buf.putShort(BITS_PER_SAMPLE.toShort())
        buf.putShort(22.toShort()) // cbSize
        buf.putShort(BITS_PER_SAMPLE.toShort()) // validBitsPerSample
        buf.putInt(channelMask)
        // KSDATAFORMAT_SUBTYPE_PCM GUID: 00000001-0000-0010-8000-00AA00389B71
        buf.putInt(0x00000001)
        buf.putShort(0x0000)
        buf.putShort(0x0010)
        buf.put(byteArrayOf(0x80.toByte(), 0x00, 0x00, 0xAA.toByte(), 0x00, 0x38, 0x9B.toByte(), 0x71))
        // data chunk
        buf.put("data".toByteArray(Charsets.US_ASCII))
        buf.putInt(dataSizeBytes)
        return buf.array()
    }
}
