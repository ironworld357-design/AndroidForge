package com.example.ui.state

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import com.example.audio.engine.AudioCapabilityInspector
import com.example.audio.engine.AudioRoutingEngine
import com.example.audio.engine.MultichannelTestSynthesizer
import com.example.audio.engine.PlaybackPathValidator
import com.example.audio.engine.VybePlayerManager
import com.example.audio.model.AudioDecoderInfo
import com.example.audio.model.AudioPathResolution
import com.example.audio.model.AudioTrackOption
import com.example.audio.model.ChannelLayout
import com.example.audio.model.CinemaAspectMode
import com.example.audio.model.DisplayCapabilitiesReport
import com.example.audio.model.HdrFormat
import com.example.audio.model.OutputDeviceReport
import com.example.audio.model.PlaybackPathTestResult
import com.example.audio.model.RoutingModePreference
import com.example.audio.model.SourceAudioTelemetry
import com.example.audio.model.SourceVideoTelemetry
import com.example.audio.model.SpatializerReport
import com.example.audio.model.SpeakerChannel
import com.example.audio.model.SpeakerNodeState
import com.example.data.VybePreferencesRepository
import com.example.data.VybeUserPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class VybeUiState(
    val sourceAudio: SourceAudioTelemetry = SourceAudioTelemetry(),
    val sourceVideo: SourceVideoTelemetry = SourceVideoTelemetry(),
    val audioTracks: List<AudioTrackOption> = emptyList(),
    val resolution: AudioPathResolution? = null,
    val speakerNodes: List<SpeakerNodeState> = emptyList(),
    val outputDevices: List<OutputDeviceReport> = emptyList(),
    val activeDevice: OutputDeviceReport? = null,
    val spatializer: SpatializerReport = SpatializerReport(false, false, "Checking...", false, false, false),
    val decoders: List<AudioDecoderInfo> = emptyList(),
    val displayCaps: DisplayCapabilitiesReport = DisplayCapabilitiesReport(false, listOf(HdrFormat.SDR), 60f, false),
    val preferences: VybeUserPreferences = VybeUserPreferences(),
    val referenceTracks: List<MultichannelTestSynthesizer.GeneratedReferenceTrack> = emptyList(),
    val validationResults: List<PlaybackPathTestResult> = emptyList(),
    val isPlaying: Boolean = false,
    val playbackState: Int = Player.STATE_IDLE,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val activeAudioTrackConfig: String? = null,
    val playerError: String? = null,
    val routeBanner: String? = null,
    val lastPingedSpeaker: SpeakerChannel? = null,
    val isRunningValidation: Boolean = false
)

class VybeViewModel(application: Application) : AndroidViewModel(application) {

    private val inspector = AudioCapabilityInspector(application)
    val playerManager = VybePlayerManager(application)
    private val prefsRepo = VybePreferencesRepository(application)

    private val referenceTracksFlow = MutableStateFlow<List<MultichannelTestSynthesizer.GeneratedReferenceTrack>>(emptyList())
    private val validationResultsFlow = MutableStateFlow<List<PlaybackPathTestResult>>(emptyList())
    private val lastPingedSpeakerFlow = MutableStateFlow<SpeakerChannel?>(null)
    private val isRunningValidationFlow = MutableStateFlow(false)

    private val hardwareFlow = combine(
        inspector.outputDevices,
        inspector.activeDevice,
        inspector.spatializerReport,
        inspector.decoders,
        inspector.displayCapabilities
    ) { devices, active, spatializer, decoders, display ->
        HardwareBundle(devices, active, spatializer, decoders, display)
    }

    private val playbackFlow = combine(
        playerManager.isPlaying,
        playerManager.playbackState,
        playerManager.positionMs,
        playerManager.durationMs,
        playerManager.activeDecoderName
    ) { playing, state, pos, dur, decoderName ->
        PlaybackBundle(playing, state, pos, dur, decoderName)
    }

    private val trackInfoFlow = combine(
        playerManager.sourceAudio,
        playerManager.sourceVideo,
        playerManager.audioTracks,
        playerManager.activeAudioTrackConfig,
        playerManager.underrunCount
    ) { audio, video, tracks, trackCfg, underruns ->
        TrackBundle(audio, video, tracks, trackCfg, underruns)
    }

    private val alertsAndSuiteFlow = combine(
        playerManager.playerErrorMessage,
        playerManager.routeChangeBanner,
        referenceTracksFlow,
        validationResultsFlow,
        lastPingedSpeakerFlow
    ) { err, banner, refs, validations, pinged ->
        AlertsBundle(err, banner, refs, validations, pinged)
    }

    val uiState: StateFlow<VybeUiState> = combine(
        hardwareFlow,
        playbackFlow,
        trackInfoFlow,
        prefsRepo.preferencesFlow,
        alertsAndSuiteFlow,
        isRunningValidationFlow
    ) { arr ->
        val hw = arr[0] as HardwareBundle
        val pb = arr[1] as PlaybackBundle
        val tr = arr[2] as TrackBundle
        val prefs = arr[3] as VybeUserPreferences
        val al = arr[4] as AlertsBundle
        val runningVal = arr[5] as Boolean

        val resolution = AudioRoutingEngine.resolveAudioPath(
            source = tr.audio,
            activeDevice = hw.active,
            decoders = hw.decoders,
            spatializer = hw.spatializer,
            preference = prefs.routingMode,
            activePlayerDecoderName = pb.decoderName,
            underrunCount = tr.underruns
        )
        val nodes = AudioRoutingEngine.buildSpeakerTopology(tr.audio, resolution)

        VybeUiState(
            sourceAudio = tr.audio,
            sourceVideo = tr.video,
            audioTracks = tr.tracks,
            resolution = resolution,
            speakerNodes = nodes,
            outputDevices = hw.devices,
            activeDevice = hw.active,
            spatializer = hw.spatializer,
            decoders = hw.decoders,
            displayCaps = hw.display,
            preferences = prefs,
            referenceTracks = al.refs,
            validationResults = al.validations,
            isPlaying = pb.playing,
            playbackState = pb.state,
            positionMs = pb.pos,
            durationMs = pb.dur,
            activeAudioTrackConfig = tr.trackCfg,
            playerError = al.err,
            routeBanner = al.banner,
            lastPingedSpeaker = al.pinged,
            isRunningValidation = runningVal
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = VybeUiState()
    )

    init {
        inspector.startMonitoring { newDevice, wasExternalDisconnected ->
            val currentPrefs = uiState.value.preferences
            playerManager.handleAudioRouteChanged(
                newDevice = newDevice,
                wasExternalDisconnected = wasExternalDisconnected,
                preference = currentPrefs.routingMode,
                matchFrameRate = currentPrefs.matchFrameRate
            )
            runHardwareValidation()
        }

        viewModelScope.launch {
            val refs = MultichannelTestSynthesizer.generateReferenceSuite(getApplication())
            referenceTracksFlow.value = refs
            runHardwareValidation()
        }
    }

    fun playReferenceTrack(track: MultichannelTestSynthesizer.GeneratedReferenceTrack) {
        val state = uiState.value
        playerManager.getOrCreatePlayer()
        state.activeDevice?.let {
            playerManager.applyRoutingPreference(
                state.preferences.routingMode,
                it,
                state.preferences.matchFrameRate
            )
        }
        playerManager.playMediaUri(
            uri = track.uri,
            title = track.title,
            fallbackChannelHint = track.layout,
            fallbackSampleRateHint = track.sampleRateHz,
            fallbackBitrateHint = track.bitrateBps
        )
    }

    fun playPickedMediaUri(uri: Uri, fallbackName: String = "Local Media") {
        val name = resolveDisplayName(uri) ?: fallbackName
        val state = uiState.value
        playerManager.getOrCreatePlayer()
        state.activeDevice?.let {
            playerManager.applyRoutingPreference(
                state.preferences.routingMode,
                it,
                state.preferences.matchFrameRate
            )
        }
        playerManager.playMediaUri(uri = uri, title = name)
    }

    fun playStreamUrl(url: String) {
        val trimmed = url.trim()
        if (trimmed.isBlank()) return
        val uri = Uri.parse(trimmed)
        val label = uri.lastPathSegment?.takeIf { it.isNotBlank() } ?: "Network Stream"
        val state = uiState.value
        playerManager.getOrCreatePlayer()
        state.activeDevice?.let {
            playerManager.applyRoutingPreference(
                state.preferences.routingMode,
                it,
                state.preferences.matchFrameRate
            )
        }
        playerManager.playMediaUri(uri = uri, title = label)
    }

    fun pingSpeaker(channel: SpeakerChannel) {
        viewModelScope.launch {
            lastPingedSpeakerFlow.value = channel
            val currentLayout = uiState.value.sourceAudio.channelLayout.let {
                if (it.channelCount < 6 && (channel != SpeakerChannel.FL && channel != SpeakerChannel.FR)) {
                    ChannelLayout.SURROUND_7_1
                } else {
                    it
                }
            }
            val uri = MultichannelTestSynthesizer.generateIsolatedSpeakerFile(
                context = getApplication(),
                targetChannel = channel,
                layout = currentLayout
            )
            playerManager.playMediaUri(
                uri = uri,
                title = "Speaker Ping • ${channel.fullName} (${channel.code})",
                fallbackChannelHint = currentLayout,
                fallbackSampleRateHint = 48000,
                fallbackBitrateHint = 48000 * currentLayout.channelCount * 16
            )
        }
    }

    fun togglePlayPause() = playerManager.togglePlayPause()

    fun seekTo(ms: Long) = playerManager.seekTo(ms)

    fun selectAudioTrack(option: AudioTrackOption) = playerManager.selectAudioTrack(option)

    fun setRoutingMode(mode: RoutingModePreference) {
        viewModelScope.launch {
            prefsRepo.setRoutingMode(mode)
            uiState.value.activeDevice?.let { device ->
                playerManager.applyRoutingPreference(mode, device, uiState.value.preferences.matchFrameRate)
            }
        }
    }

    fun setCinemaAspectMode(mode: CinemaAspectMode) {
        viewModelScope.launch {
            prefsRepo.setCinemaAspectMode(mode)
        }
    }

    fun setMatchFrameRate(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setMatchFrameRate(enabled)
            uiState.value.activeDevice?.let { device ->
                playerManager.applyRoutingPreference(uiState.value.preferences.routingMode, device, enabled)
            }
        }
    }

    fun setHdrEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setHdrEnabled(enabled)
        }
    }

    fun refreshHardwareAndValidate() {
        inspector.refreshHardwareState(routeChangeEvent = false, disconnected = false)
        runHardwareValidation()
    }

    fun runHardwareValidation() {
        viewModelScope.launch {
            isRunningValidationFlow.value = true
            val results = PlaybackPathValidator.runAll10Checks(
                devices = inspector.outputDevices.value,
                activeDevice = inspector.activeDevice.value,
                decoders = inspector.decoders.value,
                spatializer = inspector.spatializerReport.value
            )
            validationResultsFlow.value = results
            isRunningValidationFlow.value = false
        }
    }

    fun dismissRouteBanner() = playerManager.dismissRouteBanner()

    private fun resolveDisplayName(uri: Uri): String? {
        return runCatching {
            getApplication<Application>().contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIdx >= 0 && cursor.moveToFirst()) {
                    cursor.getString(nameIdx)
                } else null
            }
        }.getOrNull() ?: uri.lastPathSegment
    }

    override fun onCleared() {
        super.onCleared()
        inspector.stopMonitoring()
        playerManager.release()
    }

    private data class HardwareBundle(
        val devices: List<OutputDeviceReport>,
        val active: OutputDeviceReport,
        val spatializer: SpatializerReport,
        val decoders: List<AudioDecoderInfo>,
        val display: DisplayCapabilitiesReport
    )

    private data class PlaybackBundle(
        val playing: Boolean,
        val state: Int,
        val pos: Long,
        val dur: Long,
        val decoderName: String?
    )

    private data class TrackBundle(
        val audio: SourceAudioTelemetry,
        val video: SourceVideoTelemetry,
        val tracks: List<AudioTrackOption>,
        val trackCfg: String?,
        val underruns: Int
    )

    private data class AlertsBundle(
        val err: String?,
        val banner: String?,
        val refs: List<MultichannelTestSynthesizer.GeneratedReferenceTrack>,
        val validations: List<PlaybackPathTestResult>,
        val pinged: SpeakerChannel?
    )
}
