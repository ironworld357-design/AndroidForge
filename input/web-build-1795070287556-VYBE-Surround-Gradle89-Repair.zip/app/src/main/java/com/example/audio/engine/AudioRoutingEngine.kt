package com.example.audio.engine

import com.example.audio.model.AudioCodecFormat
import com.example.audio.model.AudioDecoderInfo
import com.example.audio.model.AudioPathResolution
import com.example.audio.model.AudioStatusIndicator
import com.example.audio.model.ChannelLayout
import com.example.audio.model.OutputDeviceReport
import com.example.audio.model.OutputRouteType
import com.example.audio.model.RoutingModePreference
import com.example.audio.model.SourceAudioTelemetry
import com.example.audio.model.SpatializerReport
import com.example.audio.model.SpeakerActivity
import com.example.audio.model.SpeakerChannel
import com.example.audio.model.SpeakerNodeState

/**
 * Pure, deterministic routing engine that computes the genuine playback path from:
 * 1) Source stream metadata
 * 2) Actual connected output device capabilities
 * 3) Installed platform/OEM MediaCodec decoders
 * 4) Android Spatializer availability
 * 5) User routing preference
 *
 * Strictly enforces:
 * - Never claim active Dolby Atmos unless source is Atmos AND device/receiver confirms Atmos path
 * - Never claim Bluetooth carries native lossless 5.1/7.1 or Atmos bitstreams unless reported
 * - Never invent surround channels for a 2.0 stereo source
 */
object AudioRoutingEngine {

    fun resolveAudioPath(
        source: SourceAudioTelemetry,
        activeDevice: OutputDeviceReport,
        decoders: List<AudioDecoderInfo>,
        spatializer: SpatializerReport,
        preference: RoutingModePreference,
        activePlayerDecoderName: String? = null,
        underrunCount: Int = 0
    ): AudioPathResolution {
        val matchingDecoders = decoders.filter { decoder ->
            source.codec.mimeTypes.any { it.equals(decoder.mimeType, ignoreCase = true) } ||
                decoder.mimeType.equals(source.rawMimeType, ignoreCase = true)
        }
        val bestDecoder = matchingDecoders.maxByOrNull {
            (if (it.isHardwareAccelerated) 100 else 10) + it.maxChannelCount
        }
        val hasLocalDecoder = source.codec == AudioCodecFormat.PCM || bestDecoder != null

        // Check genuine compressed passthrough capability on the routed output device
        val deviceSupportsCodecBitstream = activeDevice.routeType.supportsNativeBitstream &&
            (source.codec in activeDevice.directPlaybackCodecs || source.codec in activeDevice.supportedFormats) &&
            source.codec != AudioCodecFormat.PCM

        // Bluetooth must NOT be advertised as carrying native lossless 5.1/7.1 or Atmos bitstreams
        // unless the AudioDeviceInfo explicitly reports direct playback for that format.
        val isBluetoothRoute = activeDevice.routeType == OutputRouteType.BLUETOOTH_A2DP ||
            activeDevice.routeType == OutputRouteType.BLUETOOTH_LE_AUDIO
        val bluetoothAllowsBitstream = isBluetoothRoute &&
            source.codec in activeDevice.directPlaybackCodecs &&
            source.codec != AudioCodecFormat.PCM

        val passthroughAvailable = if (isBluetoothRoute) {
            bluetoothAllowsBitstream
        } else {
            deviceSupportsCodecBitstream
        }

        val sourceChannels = source.channelCount.coerceAtLeast(1)
        val deviceMaxChannels = activeDevice.maxChannels.coerceAtLeast(2)

        // 1. Check for FORCE_STEREO preference
        if (preference == RoutingModePreference.FORCE_STEREO && sourceChannels > 2) {
            val downmixNote = buildDownmixDescription(source.channelLayout)
            return AudioPathResolution(
                status = AudioStatusIndicator.STEREO_DOWNMIX,
                activeOutputDeviceName = activeDevice.productName,
                activeRouteType = activeDevice.routeType,
                outputChannelLayout = ChannelLayout.STEREO,
                decoderSummary = formatDecoderSummary(bestDecoder, activePlayerDecoderName, source.codec),
                passthroughAvailable = passthroughAvailable,
                passthroughActive = false,
                atmosActive = false,
                spatializerActive = false,
                downmixApplied = true,
                downmixMatrixDescription = downmixNote,
                playbackModeSummary = "Forced 2.0 Stereo Downmix",
                fallbackReason = "User selected Stereo 2.0 Downmix mode",
                avSyncStatus = if (underrunCount == 0) "Locked (Low-Latency PCM)" else "Recovered ($underrunCount underruns)",
                underrunCount = underrunCount
            )
        }

        // 2. Check Bitstream Passthrough path (Auto Optimal or Prefer Passthrough)
        val shouldUsePassthrough = passthroughAvailable &&
            (preference == RoutingModePreference.AUTO_OPTIMAL || preference == RoutingModePreference.PREFER_PASSTHROUGH) &&
            source.codec != AudioCodecFormat.PCM

        if (shouldUsePassthrough) {
            val atmosConfirmed = source.codec.isAtmosCapable
            return AudioPathResolution(
                status = AudioStatusIndicator.ORIGINAL_BITSTREAM,
                activeOutputDeviceName = activeDevice.productName,
                activeRouteType = activeDevice.routeType,
                outputChannelLayout = source.channelLayout,
                decoderSummary = "External Hardware Pass-Through (${activeDevice.routeType.label})",
                passthroughAvailable = true,
                passthroughActive = true,
                atmosActive = atmosConfirmed,
                spatializerActive = false,
                downmixApplied = false,
                downmixMatrixDescription = null,
                playbackModeSummary = if (atmosConfirmed) {
                    "Original Bitstream • Dolby Atmos Passthrough"
                } else {
                    "Original Bitstream • ${source.codec.displayName}"
                },
                fallbackReason = null,
                avSyncStatus = if (underrunCount == 0) "Locked (IEC 61937 Bitstream)" else "Recovered ($underrunCount underruns)",
                underrunCount = underrunCount
            )
        }

        // 3. No local decoder AND no passthrough -> Honest Unsupported Format
        if (!hasLocalDecoder) {
            return AudioPathResolution(
                status = AudioStatusIndicator.UNSUPPORTED_FORMAT,
                activeOutputDeviceName = activeDevice.productName,
                activeRouteType = activeDevice.routeType,
                outputChannelLayout = ChannelLayout.STEREO,
                decoderSummary = "No licensed ${source.codec.displayName} decoder or passthrough sink",
                passthroughAvailable = false,
                passthroughActive = false,
                atmosActive = false,
                spatializerActive = false,
                downmixApplied = false,
                downmixMatrixDescription = null,
                playbackModeSummary = "Unsupported Format (${source.codec.displayName})",
                fallbackReason = "Device lacks ${source.codec.displayName} decoder and ${activeDevice.productName} does not accept bitstream.",
                avSyncStatus = "Halted (Codec Unavailable)",
                underrunCount = underrunCount
            )
        }

        // 4. Device-side Decoding Path (Dolby / DTS / AAC / FLAC / Opus / PCM)
        val decoderMaxChannels = if (source.codec == AudioCodecFormat.PCM) {
            sourceChannels
        } else {
            bestDecoder?.maxChannelCount ?: 2
        }
        val decodedChannels = minOf(sourceChannels, decoderMaxChannels)

        // Spatializer can virtualize multichannel (5.1 / 7.1) over stereo headsets/speakers when OS reports active
        val spatializerCanProcess = spatializer.isAvailable &&
            spatializer.isEnabled &&
            decodedChannels >= 4 &&
            (activeDevice.routeType == OutputRouteType.WIRED_HEADSET ||
                activeDevice.routeType == OutputRouteType.BLUETOOTH_A2DP ||
                activeDevice.routeType == OutputRouteType.BLUETOOTH_LE_AUDIO ||
                activeDevice.routeType == OutputRouteType.USB_DAC ||
                activeDevice.routeType == OutputRouteType.BUILTIN_SPEAKER)

        val atmosOnDeviceConfirmed = source.codec.isAtmosCapable &&
            (spatializer.canSpatializeAtmosJoc || (bestDecoder?.isHardwareAccelerated == true && source.codec == AudioCodecFormat.AC4))

        // Determine final output layout without ever inventing channels
        val effectiveOutputChannels = when {
            decodedChannels <= 2 -> decodedChannels
            deviceMaxChannels >= decodedChannels -> decodedChannels
            deviceMaxChannels >= 6 && decodedChannels == 7 -> 6 // 6.1 -> 5.1 preservation when 7ch sink unavailable
            deviceMaxChannels >= 6 && decodedChannels == 8 -> 6 // 7.1 -> 5.1 preservation on 5.1 AVR/DAC
            spatializerCanProcess -> decodedChannels // Spatializer consumes multichannel PCM directly
            else -> 2
        }

        val effectiveOutputLayout = ChannelLayout.fromChannelCount(
            count = effectiveOutputChannels,
            hasObjectMetadata = atmosOnDeviceConfirmed
        )

        val downmixApplied = sourceChannels > 2 && effectiveOutputChannels <= 2 && !spatializerCanProcess

        val status = when {
            downmixApplied -> AudioStatusIndicator.STEREO_DOWNMIX
            source.codec.isDolby -> AudioStatusIndicator.DOLBY_DECODED
            decodedChannels > 2 -> AudioStatusIndicator.MULTICHANNEL_PCM
            else -> AudioStatusIndicator.MULTICHANNEL_PCM.takeIf { sourceChannels > 2 }
                ?: if (source.codec == AudioCodecFormat.PCM) AudioStatusIndicator.MULTICHANNEL_PCM else AudioStatusIndicator.MULTICHANNEL_PCM
        }

        // Refine status strictly for 2.0 sources: PCM or decoded stereo is Multichannel/PCM Stereo (not Stereo Downmix!)
        val finalStatus = when {
            downmixApplied -> AudioStatusIndicator.STEREO_DOWNMIX
            source.codec.isDolby -> AudioStatusIndicator.DOLBY_DECODED
            else -> AudioStatusIndicator.MULTICHANNEL_PCM
        }

        val fallbackReason = when {
            source.codec.isAtmosCapable && !atmosOnDeviceConfirmed ->
                "Atmos object metadata unavailable on ${activeDevice.productName}; playing ${effectiveOutputLayout.label} bed."
            sourceChannels > effectiveOutputChannels ->
                "Source ${source.channelLayout.shortCode} adapted to ${effectiveOutputLayout.label} for ${activeDevice.productName}."
            preference == RoutingModePreference.PREFER_PASSTHROUGH && !passthroughAvailable ->
                "${activeDevice.productName} does not support ${source.codec.displayName} bitstream; using on-device decode."
            else -> null
        }

        val modeSummary = buildString {
            append(finalStatus.label)
            append(" • ")
            if (spatializerCanProcess && deviceMaxChannels <= 2) {
                append("${source.channelLayout.shortCode} → Spatializer Binaural")
            } else if (sourceChannels <= 2) {
                append("${source.channelLayout.label} (Native)")
            } else {
                append("${source.channelLayout.shortCode} → ${effectiveOutputLayout.label}")
            }
        }

        return AudioPathResolution(
            status = finalStatus,
            activeOutputDeviceName = activeDevice.productName,
            activeRouteType = activeDevice.routeType,
            outputChannelLayout = effectiveOutputLayout,
            decoderSummary = formatDecoderSummary(bestDecoder, activePlayerDecoderName, source.codec),
            passthroughAvailable = passthroughAvailable,
            passthroughActive = false,
            atmosActive = atmosOnDeviceConfirmed,
            spatializerActive = spatializerCanProcess,
            downmixApplied = downmixApplied,
            downmixMatrixDescription = if (downmixApplied) buildDownmixDescription(source.channelLayout) else null,
            playbackModeSummary = modeSummary,
            fallbackReason = fallbackReason,
            avSyncStatus = if (underrunCount == 0) "Locked (${source.sampleRateHz / 1000f} kHz Sync)" else "Recovered ($underrunCount underruns)",
            underrunCount = underrunCount
        )
    }

    fun buildSpeakerTopology(
        source: SourceAudioTelemetry,
        resolution: AudioPathResolution
    ): List<SpeakerNodeState> {
        val activeSourceChannels = channelsForLayout(source.channelLayout)
        val activeOutputChannels = channelsForLayout(resolution.outputChannelLayout)

        return SpeakerChannel.entries.map { channel ->
            val inSource = channel in activeSourceChannels ||
                (resolution.atmosActive && (channel == SpeakerChannel.TFL || channel == SpeakerChannel.TFR))
            val activity = when {
                !inSource -> SpeakerActivity.INACTIVE
                resolution.spatializerActive && resolution.activeOutputDeviceName.isNotBlank() &&
                    channel !in activeOutputChannels -> SpeakerActivity.SPATIALIZED_VIRTUAL
                resolution.downmixApplied && channel != SpeakerChannel.FL && channel != SpeakerChannel.FR ->
                    SpeakerActivity.DOWNMIXED_TO_STEREO
                channel in activeOutputChannels || (resolution.atmosActive && (channel == SpeakerChannel.TFL || channel == SpeakerChannel.TFR)) ->
                    SpeakerActivity.ACTIVE_DISCRETE
                resolution.spatializerActive -> SpeakerActivity.SPATIALIZED_VIRTUAL
                else -> SpeakerActivity.DOWNMIXED_TO_STEREO
            }
            SpeakerNodeState(channel = channel, activity = activity)
        }
    }

    fun channelsForLayout(layout: ChannelLayout): Set<SpeakerChannel> {
        return when (layout) {
            ChannelLayout.MONO -> setOf(SpeakerChannel.FC)
            ChannelLayout.STEREO -> setOf(SpeakerChannel.FL, SpeakerChannel.FR)
            ChannelLayout.SURROUND_2_1 -> setOf(SpeakerChannel.FL, SpeakerChannel.FR, SpeakerChannel.LFE)
            ChannelLayout.QUAD -> setOf(SpeakerChannel.FL, SpeakerChannel.FR, SpeakerChannel.SL, SpeakerChannel.SR)
            ChannelLayout.SURROUND_5_0 -> setOf(
                SpeakerChannel.FL, SpeakerChannel.FC, SpeakerChannel.FR,
                SpeakerChannel.SL, SpeakerChannel.SR
            )
            ChannelLayout.SURROUND_5_1 -> setOf(
                SpeakerChannel.FL, SpeakerChannel.FC, SpeakerChannel.FR,
                SpeakerChannel.LFE, SpeakerChannel.SL, SpeakerChannel.SR
            )
            ChannelLayout.SURROUND_6_1 -> setOf(
                SpeakerChannel.FL, SpeakerChannel.FC, SpeakerChannel.FR,
                SpeakerChannel.LFE, SpeakerChannel.SL, SpeakerChannel.SR, SpeakerChannel.BC
            )
            ChannelLayout.SURROUND_7_1 -> setOf(
                SpeakerChannel.FL, SpeakerChannel.FC, SpeakerChannel.FR,
                SpeakerChannel.LFE, SpeakerChannel.SL, SpeakerChannel.SR,
                SpeakerChannel.BL, SpeakerChannel.BR
            )
            ChannelLayout.ATMOS_7_1_4 -> setOf(
                SpeakerChannel.FL, SpeakerChannel.FC, SpeakerChannel.FR,
                SpeakerChannel.LFE, SpeakerChannel.SL, SpeakerChannel.SR,
                SpeakerChannel.BL, SpeakerChannel.BR, SpeakerChannel.TFL, SpeakerChannel.TFR
            )
        }
    }

    /**
     * ITU-R BS.775-3 coefficient downmix specification for accurate stereo folding without clipping.
     */
    fun buildDownmixDescription(layout: ChannelLayout): String {
        return when (layout) {
            ChannelLayout.SURROUND_2_1 -> "L' = L + 0.5×LFE, R' = R + 0.5×LFE (Normalized)"
            ChannelLayout.SURROUND_5_1 -> "L' = L + 0.707×C + 0.707×SL (ITU-R BS.775, LFE -6dB)"
            ChannelLayout.SURROUND_6_1 -> "L' = L + 0.707×C + 0.707×SL + 0.5×BC (ITU-R BS.775)"
            ChannelLayout.SURROUND_7_1, ChannelLayout.ATMOS_7_1_4 ->
                "L' = L + 0.707×C + 0.707×SL + 0.707×BL (7.1→2.0 Normalized)"
            else -> "Direct 2.0 Stereo Mapping (No Rear/Center Channels Invented)"
        }
    }

    private fun formatDecoderSummary(
        decoder: AudioDecoderInfo?,
        activePlayerDecoderName: String?,
        codec: AudioCodecFormat
    ): String {
        if (!activePlayerDecoderName.isNullOrBlank()) {
            return activePlayerDecoderName
        }
        if (codec == AudioCodecFormat.PCM) {
            return "Native Linear PCM Pipeline (Zero Decode Overhead)"
        }
        return if (decoder != null) {
            val accel = if (decoder.isHardwareAccelerated) "HW" else "SW"
            "${decoder.codecName} ($accel • up to ${decoder.maxChannelCount}ch)"
        } else {
            "Unavailable"
        }
    }
}
