package com.example.audio.engine

import android.content.Context
import android.media.AudioAttributes as PlatformAudioAttributes
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.example.audio.model.AudioCodecFormat
import com.example.audio.model.AudioTrackOption
import com.example.audio.model.ChannelLayout
import com.example.audio.model.HdrFormat
import com.example.audio.model.OutputDeviceReport
import com.example.audio.model.RoutingModePreference
import com.example.audio.model.SourceAudioTelemetry
import com.example.audio.model.SourceVideoTelemetry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Real Jetpack Media3 ExoPlayer engine with native audio capabilities inspection,
 * bitstream offload/passthrough negotiation, multichannel PCM preservation,
 * seamless frame rate control, HDR detection, and live AnalyticsListener telemetry.
 */
@OptIn(UnstableApi::class)
class VybePlayerManager(private val context: Context) {

    private var exoPlayer: ExoPlayer? = null
    private var trackSelector: DefaultTrackSelector? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackState = MutableStateFlow(Player.STATE_IDLE)
    val playbackState: StateFlow<Int> = _playbackState.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _sourceAudio = MutableStateFlow(SourceAudioTelemetry())
    val sourceAudio: StateFlow<SourceAudioTelemetry> = _sourceAudio.asStateFlow()

    private val _sourceVideo = MutableStateFlow(SourceVideoTelemetry())
    val sourceVideo: StateFlow<SourceVideoTelemetry> = _sourceVideo.asStateFlow()

    private val _audioTracks = MutableStateFlow<List<AudioTrackOption>>(emptyList())
    val audioTracks: StateFlow<List<AudioTrackOption>> = _audioTracks.asStateFlow()

    private val _activeDecoderName = MutableStateFlow<String?>(null)
    val activeDecoderName: StateFlow<String?> = _activeDecoderName.asStateFlow()

    private val _activeAudioTrackConfig = MutableStateFlow<String?>(null)
    val activeAudioTrackConfig: StateFlow<String?> = _activeAudioTrackConfig.asStateFlow()

    private val _underrunCount = MutableStateFlow(0)
    val underrunCount: StateFlow<Int> = _underrunCount.asStateFlow()

    private val _playerErrorMessage = MutableStateFlow<String?>(null)
    val playerErrorMessage: StateFlow<String?> = _playerErrorMessage.asStateFlow()

    private val _routeChangeBanner = MutableStateFlow<String?>(null)
    val routeChangeBanner: StateFlow<String?> = _routeChangeBanner.asStateFlow()

    private val mainHandler = Handler(Looper.getMainLooper())
    private val progressRunnable = object : Runnable {
        override fun run() {
            val p = exoPlayer
            if (p != null) {
                _positionMs.value = p.currentPosition.coerceAtLeast(0L)
                _durationMs.value = p.duration.coerceAtLeast(0L)
                if (p.isPlaying) {
                    mainHandler.postDelayed(this, 250L)
                }
            }
        }
    }

    private var currentTitle: String = "No Media Loaded"

    fun getOrCreatePlayer(): ExoPlayer {
        exoPlayer?.let { return it }

        val selector = DefaultTrackSelector(context)
        trackSelector = selector

        val renderersFactory = object : DefaultRenderersFactory(context) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(true)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .build()
            }
        }.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val player = ExoPlayer.Builder(context, renderersFactory)
            .setTrackSelector(selector)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS)
            .build()

        player.addListener(playerListener)
        player.addAnalyticsListener(analyticsListener)
        exoPlayer = player
        return player
    }

    fun playMediaUri(
        uri: Uri,
        title: String,
        fallbackChannelHint: ChannelLayout? = null,
        fallbackSampleRateHint: Int? = null,
        fallbackBitrateHint: Int? = null
    ) {
        val player = getOrCreatePlayer()
        currentTitle = title
        _playerErrorMessage.value = null
        _underrunCount.value = 0
        _activeDecoderName.value = null
        _activeAudioTrackConfig.value = null

        val item = MediaItem.Builder()
            .setUri(uri)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
            .build()

        // Initialize baseline telemetry before tracks resolve
        if (fallbackChannelHint != null) {
            _sourceAudio.value = SourceAudioTelemetry(
                title = title,
                codec = AudioCodecFormat.PCM,
                rawMimeType = "audio/raw",
                channelCount = fallbackChannelHint.channelCount,
                channelLayout = fallbackChannelHint,
                sampleRateHz = fallbackSampleRateHint ?: 48000,
                bitrateBps = fallbackBitrateHint ?: (48000 * fallbackChannelHint.channelCount * 16),
                hasMediaLoaded = true
            )
        } else {
            _sourceAudio.value = _sourceAudio.value.copy(title = title, hasMediaLoaded = true)
        }

        player.setMediaItem(item)
        player.prepare()
        player.play()
        mainHandler.removeCallbacks(progressRunnable)
        mainHandler.post(progressRunnable)
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_ENDED) {
                player.seekTo(0)
            }
            player.play()
        }
    }

    fun seekTo(positionMs: Long) {
        exoPlayer?.seekTo(positionMs.coerceAtLeast(0L))
        _positionMs.value = positionMs.coerceAtLeast(0L)
    }

    fun stop() {
        exoPlayer?.stop()
        _isPlaying.value = false
    }

    fun selectAudioTrack(option: AudioTrackOption) {
        val player = exoPlayer ?: return
        val groups = player.currentTracks.groups
        val targetGroup = groups.getOrNull(option.groupIndex) ?: return
        val params = player.trackSelectionParameters
            .buildUpon()
            .setOverrideForType(TrackSelectionOverride(targetGroup.mediaTrackGroup, option.trackIndex))
            .build()
        player.trackSelectionParameters = params
    }

    fun applyRoutingPreference(
        preference: RoutingModePreference,
        activeDevice: OutputDeviceReport,
        matchFrameRate: Boolean
    ) {
        val player = exoPlayer ?: return
        val offloadMode = when (preference) {
            RoutingModePreference.AUTO_OPTIMAL, RoutingModePreference.PREFER_PASSTHROUGH ->
                if (activeDevice.supportsPassthrough) {
                    TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_ENABLED
                } else {
                    TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_DISABLED
                }
            RoutingModePreference.FORCE_PCM, RoutingModePreference.FORCE_STEREO ->
                TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_DISABLED
        }

        val offloadPrefs = TrackSelectionParameters.AudioOffloadPreferences.Builder()
            .setAudioOffloadMode(offloadMode)
            .build()

        val maxChannels = when (preference) {
            RoutingModePreference.FORCE_STEREO -> 2
            else -> Int.MAX_VALUE
        }

        val constrainToDevice = preference != RoutingModePreference.FORCE_PCM

        val selector = trackSelector
        if (selector != null) {
            selector.parameters = selector.buildUponParameters()
                .setAudioOffloadPreferences(offloadPrefs)
                .setMaxAudioChannelCount(maxChannels)
                .setConstrainAudioChannelCountToDeviceCapabilities(constrainToDevice)
                .build()
        } else {
            val updated = player.trackSelectionParameters.buildUpon()
                .setAudioOffloadPreferences(offloadPrefs)
                .setMaxAudioChannelCount(maxChannels)
                .build()
            player.trackSelectionParameters = updated
        }
        player.videoChangeFrameRateStrategy = if (matchFrameRate) {
            C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS
        } else {
            C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF
        }
    }

    fun handleAudioRouteChanged(
        newDevice: OutputDeviceReport,
        wasExternalDisconnected: Boolean,
        preference: RoutingModePreference,
        matchFrameRate: Boolean
    ) {
        val player = exoPlayer
        if (wasExternalDisconnected && player?.isPlaying == true) {
            // Safe disconnect behavior: pause cleanly instead of blasting device speakers
            player.pause()
            _routeChangeBanner.value = "External output disconnected — playback paused safely on ${newDevice.productName}."
        } else if (wasExternalDisconnected) {
            _routeChangeBanner.value = "Output route switched to ${newDevice.productName}."
        } else {
            _routeChangeBanner.value = "Connected ${newDevice.productName} (${newDevice.routeType.label})."
        }
        applyRoutingPreference(preference, newDevice, matchFrameRate)
    }

    fun dismissRouteBanner() {
        _routeChangeBanner.value = null
    }

    fun release() {
        mainHandler.removeCallbacks(progressRunnable)
        exoPlayer?.let { player ->
            player.removeListener(playerListener)
            player.removeAnalyticsListener(analyticsListener)
            player.release()
        }
        exoPlayer = null
        trackSelector = null
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
            mainHandler.removeCallbacks(progressRunnable)
            if (isPlaying) {
                mainHandler.post(progressRunnable)
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            _playbackState.value = playbackState
            val player = exoPlayer ?: return
            _durationMs.value = player.duration.coerceAtLeast(0L)
            _positionMs.value = player.currentPosition.coerceAtLeast(0L)
        }

        override fun onTracksChanged(tracks: Tracks) {
            extractTrackTelemetry(tracks)
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                val ratio = (videoSize.width * videoSize.pixelWidthHeightRatio) / videoSize.height.toFloat()
                _sourceVideo.value = _sourceVideo.value.copy(
                    width = videoSize.width,
                    height = videoSize.height,
                    aspectRatio = ratio,
                    hasVideo = true
                )
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            _playerErrorMessage.value = when (error.errorCode) {
                PlaybackException.ERROR_CODE_DECODING_FAILED,
                PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
                PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ->
                    "Audio decoder/output rejected this stream: ${error.localizedMessage ?: error.errorCodeName}"
                else -> error.localizedMessage ?: "Playback error (${error.errorCodeName})"
            }
        }
    }

    private val analyticsListener = object : AnalyticsListener {
        override fun onAudioDecoderInitialized(
            eventTime: AnalyticsListener.EventTime,
            decoderName: String,
            initializedTimestampMs: Long,
            initializationDurationMs: Long
        ) {
            _activeDecoderName.value = decoderName
        }

        override fun onAudioTrackInitialized(
            eventTime: AnalyticsListener.EventTime,
            audioTrackConfig: AudioSink.AudioTrackConfig
        ) {
            val mode = if (audioTrackConfig.offload) "Offload/Bitstream" else "PCM Sink"
            _activeAudioTrackConfig.value =
                "$mode • ${audioTrackConfig.sampleRate} Hz • Enc=${audioTrackConfig.encoding}"
        }

        override fun onAudioUnderrun(
            eventTime: AnalyticsListener.EventTime,
            bufferSize: Int,
            bufferSizeMs: Long,
            elapsedSinceLastFeedMs: Long
        ) {
            _underrunCount.value += 1
        }

        override fun onDroppedVideoFrames(
            eventTime: AnalyticsListener.EventTime,
            droppedFrames: Int,
            elapsedMs: Long
        ) {
            _sourceVideo.value = _sourceVideo.value.copy(
                droppedFrames = _sourceVideo.value.droppedFrames + droppedFrames
            )
        }
    }

    private fun extractTrackTelemetry(tracks: Tracks) {
        val options = mutableListOf<AudioTrackOption>()
        var selectedAudioFormat: Format? = null
        var selectedTrackIdx = 0
        var selectedVideoFormat: Format? = null

        tracks.groups.forEachIndexed { groupIdx, group ->
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val fmt = group.getTrackFormat(i)
                    val codec = AudioCodecFormat.fromMimeType(fmt.sampleMimeType, fmt.codecs)
                    val channels = fmt.channelCount.takeIf { it > 0 } ?: 2
                    val layout = ChannelLayout.fromChannelCount(channels, codec.isAtmosCapable)
                    val isSelected = group.isTrackSelected(i)
                    if (isSelected) {
                        selectedAudioFormat = fmt
                        selectedTrackIdx = options.size + 1
                    }
                    val lang = fmt.language?.uppercase()?.takeIf { it != "UND" }
                    val label = buildString {
                        append(fmt.label ?: codec.displayName)
                        append(" (${layout.shortCode})")
                        if (lang != null) append(" • $lang")
                    }
                    options += AudioTrackOption(
                        groupIndex = groupIdx,
                        trackIndex = i,
                        label = label,
                        codec = codec,
                        channelLayout = layout,
                        sampleRateHz = fmt.sampleRate.takeIf { it > 0 } ?: 48000,
                        bitrateBps = fmt.bitrate.takeIf { it > 0 } ?: 0,
                        isSelected = isSelected,
                        isPlayableOnDevice = group.isTrackSupported(i)
                    )
                }
            } else if (group.type == C.TRACK_TYPE_VIDEO && group.isSelected) {
                for (i in 0 until group.length) {
                    if (group.isTrackSelected(i)) {
                        selectedVideoFormat = group.getTrackFormat(i)
                        break
                    }
                }
            }
        }

        _audioTracks.value = options

        selectedAudioFormat?.let { fmt ->
            val codec = AudioCodecFormat.fromMimeType(fmt.sampleMimeType, fmt.codecs)
            val ch = fmt.channelCount.takeIf { it > 0 } ?: _sourceAudio.value.channelCount
            val sr = fmt.sampleRate.takeIf { it > 0 } ?: _sourceAudio.value.sampleRateHz
            val br = fmt.bitrate.takeIf { it > 0 } ?: _sourceAudio.value.bitrateBps
            _sourceAudio.value = SourceAudioTelemetry(
                title = currentTitle,
                codec = codec,
                rawMimeType = fmt.sampleMimeType ?: "audio/unknown",
                codecsString = fmt.codecs,
                channelCount = ch,
                channelLayout = ChannelLayout.fromChannelCount(ch, codec.isAtmosCapable),
                sampleRateHz = sr,
                bitrateBps = br,
                trackIndex = selectedTrackIdx,
                totalAudioTracks = options.size,
                language = fmt.language,
                hasMediaLoaded = true
            )
        }

        val vFmt = selectedVideoFormat
        if (vFmt != null) {
            val hdr = detectHdrFormat(vFmt)
            val fps = vFmt.frameRate.takeIf { it > 0f } ?: 0f
            val w = vFmt.width.takeIf { it > 0 } ?: _sourceVideo.value.width
            val h = vFmt.height.takeIf { it > 0 } ?: _sourceVideo.value.height
            val ar = if (w > 0 && h > 0) (w * vFmt.pixelWidthHeightRatio) / h.toFloat() else _sourceVideo.value.aspectRatio
            _sourceVideo.value = _sourceVideo.value.copy(
                width = w,
                height = h,
                frameRate = fps,
                aspectRatio = ar,
                hdrFormat = hdr,
                hasVideo = true
            )
        } else if (tracks.groups.none { it.type == C.TRACK_TYPE_VIDEO }) {
            _sourceVideo.value = SourceVideoTelemetry(hasVideo = false)
        }
    }

    private fun detectHdrFormat(format: Format): HdrFormat {
        if (format.sampleMimeType.equals("video/dolby-vision", ignoreCase = true)) {
            return HdrFormat.DOLBY_VISION
        }
        val colorInfo = format.colorInfo ?: return HdrFormat.SDR
        return when (colorInfo.colorTransfer) {
            C.COLOR_TRANSFER_HLG -> HdrFormat.HLG
            C.COLOR_TRANSFER_ST2084 -> {
                if (colorInfo.hdrStaticInfo != null) HdrFormat.HDR10 else HdrFormat.HDR10
            }
            else -> HdrFormat.SDR
        }
    }
}
