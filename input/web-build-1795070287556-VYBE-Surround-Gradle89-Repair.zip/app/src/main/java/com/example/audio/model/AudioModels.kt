package com.example.audio.model

import android.media.AudioFormat

enum class AudioCodecFormat(
    val displayName: String,
    val mimeTypes: List<String>,
    val isDolby: Boolean = false,
    val isAtmosCapable: Boolean = false,
    val isDts: Boolean = false,
    val isLossless: Boolean = false,
    val androidEncodings: List<Int> = emptyList()
) {
    PCM(
        displayName = "Linear PCM",
        mimeTypes = listOf("audio/raw", "audio/pcm"),
        isLossless = true,
        androidEncodings = listOf(
            AudioFormat.ENCODING_PCM_16BIT,
            AudioFormat.ENCODING_PCM_24BIT_PACKED,
            AudioFormat.ENCODING_PCM_32BIT,
            AudioFormat.ENCODING_PCM_FLOAT
        )
    ),
    AC3(
        displayName = "Dolby Digital (AC-3)",
        mimeTypes = listOf("audio/ac3"),
        isDolby = true,
        androidEncodings = listOf(AudioFormat.ENCODING_AC3)
    ),
    E_AC3(
        displayName = "Dolby Digital Plus (E-AC-3)",
        mimeTypes = listOf("audio/eac3"),
        isDolby = true,
        androidEncodings = listOf(AudioFormat.ENCODING_E_AC3)
    ),
    E_AC3_JOC(
        displayName = "Dolby Atmos (E-AC-3 JOC)",
        mimeTypes = listOf("audio/eac3-joc"),
        isDolby = true,
        isAtmosCapable = true,
        androidEncodings = listOf(AudioFormat.ENCODING_E_AC3_JOC)
    ),
    AC4(
        displayName = "Dolby Atmos (AC-4)",
        mimeTypes = listOf("audio/ac4"),
        isDolby = true,
        isAtmosCapable = true,
        androidEncodings = listOf(AudioFormat.ENCODING_AC4)
    ),
    DOLBY_TRUEHD(
        displayName = "Dolby TrueHD",
        mimeTypes = listOf("audio/true-hd"),
        isDolby = true,
        isAtmosCapable = true,
        isLossless = true,
        androidEncodings = listOf(AudioFormat.ENCODING_DOLBY_TRUEHD, AudioFormat.ENCODING_DOLBY_MAT)
    ),
    DTS(
        displayName = "DTS Digital Surround",
        mimeTypes = listOf("audio/vnd.dts"),
        isDts = true,
        androidEncodings = listOf(AudioFormat.ENCODING_DTS)
    ),
    DTS_HD(
        displayName = "DTS-HD Master Audio",
        mimeTypes = listOf("audio/vnd.dts.hd"),
        isDts = true,
        isLossless = true,
        androidEncodings = listOf(AudioFormat.ENCODING_DTS_HD)
    ),
    DTS_X(
        displayName = "DTS:X",
        mimeTypes = listOf("audio/vnd.dts.uhd"),
        isDts = true,
        isLossless = true,
        androidEncodings = listOf(AudioFormat.ENCODING_DTS_UHD_P1)
    ),
    AAC(
        displayName = "AAC",
        mimeTypes = listOf("audio/mp4a-latm"),
        androidEncodings = listOf(AudioFormat.ENCODING_AAC_LC, AudioFormat.ENCODING_AAC_HE_V1, AudioFormat.ENCODING_AAC_HE_V2)
    ),
    FLAC(
        displayName = "FLAC Lossless",
        mimeTypes = listOf("audio/flac"),
        isLossless = true,
        androidEncodings = listOf(AudioFormat.ENCODING_PCM_16BIT, AudioFormat.ENCODING_PCM_24BIT_PACKED)
    ),
    OPUS(
        displayName = "Opus",
        mimeTypes = listOf("audio/opus"),
        androidEncodings = listOf(AudioFormat.ENCODING_OPUS)
    ),
    UNSUPPORTED(
        displayName = "Unsupported Codec",
        mimeTypes = emptyList()
    );

    companion object {
        fun fromMimeType(mimeType: String?, codecs: String? = null): AudioCodecFormat {
            if (mimeType.isNullOrBlank()) return UNSUPPORTED
            val normalized = mimeType.lowercase()
            val codecHint = codecs?.lowercase().orEmpty()
            return when {
                normalized == "audio/eac3-joc" || (normalized == "audio/eac3" && (codecHint.contains("ec+3") || codecHint.contains("joc"))) -> E_AC3_JOC
                normalized == "audio/ac4" -> AC4
                normalized == "audio/eac3" -> E_AC3
                normalized == "audio/ac3" -> AC3
                normalized == "audio/true-hd" || normalized == "audio/mlp" -> DOLBY_TRUEHD
                normalized == "audio/vnd.dts.uhd" -> DTS_X
                normalized == "audio/vnd.dts.hd" -> DTS_HD
                normalized == "audio/vnd.dts" -> DTS
                normalized == "audio/raw" || normalized == "audio/pcm" -> PCM
                normalized == "audio/mp4a-latm" -> AAC
                normalized == "audio/flac" -> FLAC
                normalized == "audio/opus" -> OPUS
                else -> UNSUPPORTED
            }
        }
    }
}

enum class ChannelLayout(
    val label: String,
    val shortCode: String,
    val channelCount: Int,
    val waveChannelMask: Int
) {
    MONO("1.0 Mono", "1.0", 1, 0x4),
    STEREO("2.0 Stereo", "2.0", 2, 0x3),
    SURROUND_2_1("2.1 Stereo + LFE", "2.1", 3, 0xB),
    QUAD("4.0 Quadraphonic", "4.0", 4, 0x33),
    SURROUND_5_0("5.0 Surround", "5.0", 5, 0x37),
    SURROUND_5_1("5.1 Surround", "5.1", 6, 0x3F),
    SURROUND_6_1("6.1 Surround", "6.1", 7, 0x13F),
    SURROUND_7_1("7.1 Surround", "7.1", 8, 0x63F),
    ATMOS_7_1_4("7.1.4 Spatial", "7.1.4", 12, 0x63F);

    companion object {
        fun fromChannelCount(count: Int, hasObjectMetadata: Boolean = false): ChannelLayout {
            return when {
                count <= 0 -> STEREO
                count == 1 -> MONO
                count == 2 -> STEREO
                count == 3 -> SURROUND_2_1
                count == 4 -> QUAD
                count == 5 -> SURROUND_5_0
                count == 6 -> SURROUND_5_1
                count == 7 -> SURROUND_6_1
                count == 8 -> SURROUND_7_1
                hasObjectMetadata && count >= 10 -> ATMOS_7_1_4
                else -> SURROUND_7_1
            }
        }
    }
}

enum class OutputRouteType(val label: String, val supportsNativeBitstream: Boolean) {
    BUILTIN_SPEAKER("Device Speakers", false),
    WIRED_HEADSET("Wired Headphones / Line-Out", false),
    USB_DAC("USB Audio / DAC", true),
    HDMI("HDMI / AV Receiver", true),
    HDMI_ARC("HDMI ARC", true),
    HDMI_EARC("HDMI eARC", true),
    BLUETOOTH_A2DP("Bluetooth Audio (A2DP)", false),
    BLUETOOTH_LE_AUDIO("Bluetooth LE Audio", false),
    OTHER("External Audio Output", false)
}

enum class AudioStatusIndicator(val label: String, val description: String) {
    ORIGINAL_BITSTREAM(
        label = "Original Bitstream",
        description = "Compressed audio bitstream passed untouched to external hardware decoder."
    ),
    DOLBY_DECODED(
        label = "Dolby Decoded",
        description = "Dolby audio stream decoded on-device via licensed platform/OEM Dolby pipeline."
    ),
    MULTICHANNEL_PCM(
        label = "Multichannel PCM",
        description = "Discrete multi-channel PCM preserved across output speakers or Spatializer."
    ),
    STEREO_DOWNMIX(
        label = "Stereo Downmix",
        description = "Multichannel source accurately coefficient-downmixed to 2.0 stereo output."
    ),
    UNSUPPORTED_FORMAT(
        label = "Unsupported Format",
        description = "No hardware passthrough or licensed decoder available for this audio track."
    )
}

enum class RoutingModePreference(val label: String, val summary: String) {
    AUTO_OPTIMAL("Auto Optimal", "Preserves bitstream passthrough when supported, else best decoded multichannel or clean downmix."),
    PREFER_PASSTHROUGH("Prefer Bitstream", "Prioritizes compressed passthrough over HDMI/eARC when receiver reports format support."),
    FORCE_PCM("Multichannel PCM", "Decodes compressed streams to discrete PCM on-device when decoder is available."),
    FORCE_STEREO("Stereo 2.0 Downmix", "Forces ITU-R BS.775 2.0 downmix for late-night or stereo-only listening.")
}

enum class CinemaAspectMode(val label: String, val shortLabel: String) {
    ORIGINAL("Original Aspect", "Original"),
    FIT("Fit Frame", "Fit"),
    FILL("Expanded Fill", "Fill"),
    CROP("Cinema Crop", "Crop")
}

enum class HdrFormat(val label: String) {
    SDR("SDR (Rec.709)"),
    HLG("HLG HDR"),
    HDR10("HDR10 (PQ)"),
    HDR10_PLUS("HDR10+"),
    DOLBY_VISION("Dolby Vision")
}

data class AudioDecoderInfo(
    val codecName: String,
    val mimeType: String,
    val isHardwareAccelerated: Boolean,
    val isSoftwareOnly: Boolean,
    val maxChannelCount: Int,
    val supportedSampleRates: IntRange
)

data class OutputDeviceReport(
    val id: Int,
    val productName: String,
    val routeType: OutputRouteType,
    val isActiveDefault: Boolean,
    val maxChannels: Int,
    val supportedSampleRates: List<Int>,
    val supportedEncodings: Set<Int>,
    val supportedFormats: Set<AudioCodecFormat>,
    val supportsPassthrough: Boolean,
    val directPlaybackCodecs: Set<AudioCodecFormat>,
    val bluetoothWarning: String? = null
)

data class SpatializerReport(
    val isAvailable: Boolean,
    val isEnabled: Boolean,
    val immersiveLevel: String,
    val isHeadTrackerAvailable: Boolean,
    val canSpatialize51Pcm: Boolean,
    val canSpatializeAtmosJoc: Boolean
)

data class DisplayCapabilitiesReport(
    val hdrSupported: Boolean,
    val supportedHdrTypes: List<HdrFormat>,
    val refreshRateHz: Float,
    val seamlessFrameRateSwitchSupported: Boolean
)

data class SourceAudioTelemetry(
    val title: String = "No Media Loaded",
    val codec: AudioCodecFormat = AudioCodecFormat.PCM,
    val rawMimeType: String = "audio/raw",
    val codecsString: String? = null,
    val channelCount: Int = 2,
    val channelLayout: ChannelLayout = ChannelLayout.STEREO,
    val sampleRateHz: Int = 48000,
    val bitrateBps: Int = 0,
    val trackIndex: Int = 0,
    val totalAudioTracks: Int = 0,
    val language: String? = null,
    val hasMediaLoaded: Boolean = false
)

data class SourceVideoTelemetry(
    val width: Int = 0,
    val height: Int = 0,
    val frameRate: Float = 0f,
    val aspectRatio: Float = 16f / 9f,
    val hdrFormat: HdrFormat = HdrFormat.SDR,
    val droppedFrames: Int = 0,
    val hasVideo: Boolean = false
)

data class AudioTrackOption(
    val groupIndex: Int,
    val trackIndex: Int,
    val label: String,
    val codec: AudioCodecFormat,
    val channelLayout: ChannelLayout,
    val sampleRateHz: Int,
    val bitrateBps: Int,
    val isSelected: Boolean,
    val isPlayableOnDevice: Boolean
)

data class AudioPathResolution(
    val status: AudioStatusIndicator,
    val activeOutputDeviceName: String,
    val activeRouteType: OutputRouteType,
    val outputChannelLayout: ChannelLayout,
    val decoderSummary: String,
    val passthroughAvailable: Boolean,
    val passthroughActive: Boolean,
    val atmosActive: Boolean,
    val spatializerActive: Boolean,
    val downmixApplied: Boolean,
    val downmixMatrixDescription: String?,
    val playbackModeSummary: String,
    val fallbackReason: String? = null,
    val avSyncStatus: String = "Locked (0 ms drift)",
    val underrunCount: Int = 0
)

enum class SpeakerChannel(val code: String, val fullName: String) {
    FL("FL", "Front Left"),
    FC("FC", "Center"),
    FR("FR", "Front Right"),
    LFE("LFE", "Subwoofer"),
    SL("SL", "Surround Left"),
    SR("SR", "Surround Right"),
    BC("BC", "Back Center"),
    BL("BL", "Rear Left"),
    BR("BR", "Rear Right"),
    TFL("TFL", "Top Front L"),
    TFR("TFR", "Top Front R")
}

enum class SpeakerActivity {
    ACTIVE_DISCRETE,
    DOWNMIXED_TO_STEREO,
    SPATIALIZED_VIRTUAL,
    INACTIVE
}

data class SpeakerNodeState(
    val channel: SpeakerChannel,
    val activity: SpeakerActivity
)

enum class PlaybackTestStatus {
    PENDING,
    VERIFIED_PASS,
    VERIFIED_FALLBACK,
    NOT_SUPPORTED_ON_HARDWARE,
    REQUIRES_EXTERNAL_RECEIVER
}

data class PlaybackPathTestResult(
    val id: Int,
    val title: String,
    val scenarioCode: String,
    val status: PlaybackTestStatus,
    val statusBadge: String,
    val hardwareProof: String,
    val resolutionSummary: String
)
